﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.txtIdIntegracao = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnIncluirBoleto = New System.Windows.Forms.Button()
        Me.btnConsultarBoleto = New System.Windows.Forms.Button()
        Me.btnConsultarUpload = New System.Windows.Forms.Button()
        Me.cmdUploadRet = New System.Windows.Forms.Button()
        Me.btnGerarRemessa = New System.Windows.Forms.Button()
        Me.txtRetorno = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtTx2 = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.BackgroundWorker1 = New System.ComponentModel.BackgroundWorker()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rdProducao = New System.Windows.Forms.RadioButton()
        Me.rdHomologacao = New System.Windows.Forms.RadioButton()
        Me.BackgroundWorker2 = New System.ComponentModel.BackgroundWorker()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.btnConfigurarComponente = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtCnpjCedente = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtTokenSoftwareHouse = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtCNPJSoftwareHouse = New System.Windows.Forms.TextBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.cmdDescartarBoletos = New System.Windows.Forms.Button()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.cmdSalvarPDFLote = New System.Windows.Forms.Button()
        Me.cmdImprimirLote = New System.Windows.Forms.Button()
        Me.txtProtocoloRetornoImpressaoLote = New System.Windows.Forms.TextBox()
        Me.cmdSolicitarImpressaoLote = New System.Windows.Forms.Button()
        Me.cbbTipoImpressao = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.txtProtocoloRetProc = New System.Windows.Forms.TextBox()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.cbbTipoRemessaAlteracao = New System.Windows.Forms.ComboBox()
        Me.txtProtocoloRemessaBaixada = New System.Windows.Forms.TextBox()
        Me.txtProtocoloRetornoRemessaAlteracao = New System.Windows.Forms.TextBox()
        Me.cmdConsultarRemessaBaixada = New System.Windows.Forms.Button()
        Me.cmdGerarBaixa = New System.Windows.Forms.Button()
        Me.cmdConsultarProtocoloRemessaAlteracao = New System.Windows.Forms.Button()
        Me.cmdGerarRemessaAlteracao = New System.Windows.Forms.Button()
        Me.dlgOpen = New System.Windows.Forms.OpenFileDialog()
        Me.FileSystemWatcher1 = New System.IO.FileSystemWatcher()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.txtProtocoloEnvioEmail = New System.Windows.Forms.TextBox()
        Me.btnConsultaEmailLote = New System.Windows.Forms.Button()
        Me.btnEnviarEmailLote = New System.Windows.Forms.Button()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.btnCadastrarCedente = New System.Windows.Forms.Button()
        Me.btnCadastrarConta = New System.Windows.Forms.Button()
        Me.btnCadastrarConvenio = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        CType(Me.FileSystemWatcher1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox7.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtIdIntegracao
        '
        Me.txtIdIntegracao.Location = New System.Drawing.Point(9, 117)
        Me.txtIdIntegracao.Name = "txtIdIntegracao"
        Me.txtIdIntegracao.Size = New System.Drawing.Size(279, 20)
        Me.txtIdIntegracao.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(518, 457)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(45, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Retorno"
        '
        'btnIncluirBoleto
        '
        Me.btnIncluirBoleto.Location = New System.Drawing.Point(6, 24)
        Me.btnIncluirBoleto.Name = "btnIncluirBoleto"
        Me.btnIncluirBoleto.Size = New System.Drawing.Size(139, 25)
        Me.btnIncluirBoleto.TabIndex = 3
        Me.btnIncluirBoleto.Text = "Incluir Boleto"
        Me.btnIncluirBoleto.UseVisualStyleBackColor = True
        '
        'btnConsultarBoleto
        '
        Me.btnConsultarBoleto.Location = New System.Drawing.Point(149, 24)
        Me.btnConsultarBoleto.Name = "btnConsultarBoleto"
        Me.btnConsultarBoleto.Size = New System.Drawing.Size(139, 25)
        Me.btnConsultarBoleto.TabIndex = 4
        Me.btnConsultarBoleto.Text = "Consultar Boleto"
        Me.btnConsultarBoleto.UseVisualStyleBackColor = True
        '
        'btnConsultarUpload
        '
        Me.btnConsultarUpload.Location = New System.Drawing.Point(166, 70)
        Me.btnConsultarUpload.Name = "btnConsultarUpload"
        Me.btnConsultarUpload.Size = New System.Drawing.Size(125, 35)
        Me.btnConsultarUpload.TabIndex = 9
        Me.btnConsultarUpload.Text = "Consultar Retorno Processamento"
        Me.btnConsultarUpload.UseVisualStyleBackColor = True
        '
        'cmdUploadRet
        '
        Me.cmdUploadRet.Location = New System.Drawing.Point(166, 24)
        Me.cmdUploadRet.Name = "cmdUploadRet"
        Me.cmdUploadRet.Size = New System.Drawing.Size(125, 23)
        Me.cmdUploadRet.TabIndex = 8
        Me.cmdUploadRet.Text = "Upload do retorno"
        Me.cmdUploadRet.UseVisualStyleBackColor = True
        '
        'btnGerarRemessa
        '
        Me.btnGerarRemessa.Location = New System.Drawing.Point(6, 24)
        Me.btnGerarRemessa.Name = "btnGerarRemessa"
        Me.btnGerarRemessa.Size = New System.Drawing.Size(130, 23)
        Me.btnGerarRemessa.TabIndex = 7
        Me.btnGerarRemessa.Text = "Gerar Remessa"
        Me.btnGerarRemessa.UseVisualStyleBackColor = True
        '
        'txtRetorno
        '
        Me.txtRetorno.Location = New System.Drawing.Point(521, 473)
        Me.txtRetorno.Multiline = True
        Me.txtRetorno.Name = "txtRetorno"
        Me.txtRetorno.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtRetorno.Size = New System.Drawing.Size(465, 223)
        Me.txtRetorno.TabIndex = 10
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 101)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(73, 13)
        Me.Label2.TabIndex = 11
        Me.Label2.Text = "Id Integracão:"
        '
        'txtTx2
        '
        Me.txtTx2.Location = New System.Drawing.Point(12, 473)
        Me.txtTx2.Multiline = True
        Me.txtTx2.Name = "txtTx2"
        Me.txtTx2.Size = New System.Drawing.Size(465, 223)
        Me.txtTx2.TabIndex = 18
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(9, 457)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(98, 13)
        Me.Label6.TabIndex = 19
        Me.Label6.Text = "Arquivo de Entrada"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rdProducao)
        Me.GroupBox1.Controls.Add(Me.rdHomologacao)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(297, 49)
        Me.GroupBox1.TabIndex = 20
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = " Ambiente do Envio "
        '
        'rdProducao
        '
        Me.rdProducao.AutoSize = True
        Me.rdProducao.Location = New System.Drawing.Point(217, 19)
        Me.rdProducao.Name = "rdProducao"
        Me.rdProducao.Size = New System.Drawing.Size(71, 17)
        Me.rdProducao.TabIndex = 1
        Me.rdProducao.TabStop = True
        Me.rdProducao.Text = "Produção"
        Me.rdProducao.UseVisualStyleBackColor = True
        '
        'rdHomologacao
        '
        Me.rdHomologacao.AutoSize = True
        Me.rdHomologacao.Location = New System.Drawing.Point(13, 21)
        Me.rdHomologacao.Name = "rdHomologacao"
        Me.rdHomologacao.Size = New System.Drawing.Size(132, 17)
        Me.rdHomologacao.TabIndex = 0
        Me.rdHomologacao.TabStop = True
        Me.rdHomologacao.Text = "Homologação (Testes)"
        Me.rdHomologacao.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.btnConfigurarComponente)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.txtCnpjCedente)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.txtTokenSoftwareHouse)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.txtCNPJSoftwareHouse)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 154)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(297, 117)
        Me.GroupBox2.TabIndex = 21
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = " Configurações "
        '
        'btnConfigurarComponente
        '
        Me.btnConfigurarComponente.Location = New System.Drawing.Point(149, 82)
        Me.btnConfigurarComponente.Name = "btnConfigurarComponente"
        Me.btnConfigurarComponente.Size = New System.Drawing.Size(139, 25)
        Me.btnConfigurarComponente.TabIndex = 24
        Me.btnConfigurarComponente.Text = "Carregar Configurações"
        Me.btnConfigurarComponente.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(6, 66)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(92, 13)
        Me.Label5.TabIndex = 23
        Me.Label5.Text = "CNPJ do Cedente"
        '
        'txtCnpjCedente
        '
        Me.txtCnpjCedente.Location = New System.Drawing.Point(9, 82)
        Me.txtCnpjCedente.Name = "txtCnpjCedente"
        Me.txtCnpjCedente.Size = New System.Drawing.Size(117, 20)
        Me.txtCnpjCedente.TabIndex = 22
        Me.txtCnpjCedente.Text = "01001001000113"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(146, 16)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(132, 13)
        Me.Label4.TabIndex = 21
        Me.Label4.Text = "Token da Software House"
        '
        'txtTokenSoftwareHouse
        '
        Me.txtTokenSoftwareHouse.Location = New System.Drawing.Point(149, 32)
        Me.txtTokenSoftwareHouse.Name = "txtTokenSoftwareHouse"
        Me.txtTokenSoftwareHouse.Size = New System.Drawing.Size(139, 20)
        Me.txtTokenSoftwareHouse.TabIndex = 20
        Me.txtTokenSoftwareHouse.Text = "f22b97c0c9a3d41ac0a3875aba69e5aa"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 16)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(113, 13)
        Me.Label3.TabIndex = 19
        Me.Label3.Text = "CNPJ Software House"
        '
        'txtCNPJSoftwareHouse
        '
        Me.txtCNPJSoftwareHouse.Location = New System.Drawing.Point(9, 32)
        Me.txtCNPJSoftwareHouse.Name = "txtCNPJSoftwareHouse"
        Me.txtCNPJSoftwareHouse.Size = New System.Drawing.Size(117, 20)
        Me.txtCNPJSoftwareHouse.TabIndex = 18
        Me.txtCNPJSoftwareHouse.Text = "01001001000113"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.cmdDescartarBoletos)
        Me.GroupBox3.Controls.Add(Me.btnIncluirBoleto)
        Me.GroupBox3.Controls.Add(Me.btnConsultarBoleto)
        Me.GroupBox3.Controls.Add(Me.txtIdIntegracao)
        Me.GroupBox3.Controls.Add(Me.Label2)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 282)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(297, 150)
        Me.GroupBox3.TabIndex = 22
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = " Incluir e Consultar Boletos "
        '
        'cmdDescartarBoletos
        '
        Me.cmdDescartarBoletos.Location = New System.Drawing.Point(6, 60)
        Me.cmdDescartarBoletos.Name = "cmdDescartarBoletos"
        Me.cmdDescartarBoletos.Size = New System.Drawing.Size(139, 25)
        Me.cmdDescartarBoletos.TabIndex = 7
        Me.cmdDescartarBoletos.Text = "Descartar Boletos"
        Me.cmdDescartarBoletos.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Label7)
        Me.GroupBox4.Controls.Add(Me.ComboBox1)
        Me.GroupBox4.Controls.Add(Me.cmdSalvarPDFLote)
        Me.GroupBox4.Controls.Add(Me.cmdImprimirLote)
        Me.GroupBox4.Controls.Add(Me.txtProtocoloRetornoImpressaoLote)
        Me.GroupBox4.Controls.Add(Me.cmdSolicitarImpressaoLote)
        Me.GroupBox4.Controls.Add(Me.cbbTipoImpressao)
        Me.GroupBox4.Controls.Add(Me.Label9)
        Me.GroupBox4.Location = New System.Drawing.Point(336, 9)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(329, 251)
        Me.GroupBox4.TabIndex = 23
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = " Impressão "
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(6, 21)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(58, 13)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "Impressora"
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(9, 37)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(306, 21)
        Me.ComboBox1.TabIndex = 12
        '
        'cmdSalvarPDFLote
        '
        Me.cmdSalvarPDFLote.Location = New System.Drawing.Point(168, 213)
        Me.cmdSalvarPDFLote.Name = "cmdSalvarPDFLote"
        Me.cmdSalvarPDFLote.Size = New System.Drawing.Size(147, 23)
        Me.cmdSalvarPDFLote.TabIndex = 11
        Me.cmdSalvarPDFLote.Text = "Salvar PDF"
        Me.cmdSalvarPDFLote.UseVisualStyleBackColor = True
        '
        'cmdImprimirLote
        '
        Me.cmdImprimirLote.Location = New System.Drawing.Point(9, 213)
        Me.cmdImprimirLote.Name = "cmdImprimirLote"
        Me.cmdImprimirLote.Size = New System.Drawing.Size(147, 23)
        Me.cmdImprimirLote.TabIndex = 10
        Me.cmdImprimirLote.Text = "Imprimir Lote"
        Me.cmdImprimirLote.UseVisualStyleBackColor = True
        '
        'txtProtocoloRetornoImpressaoLote
        '
        Me.txtProtocoloRetornoImpressaoLote.Location = New System.Drawing.Point(9, 166)
        Me.txtProtocoloRetornoImpressaoLote.Name = "txtProtocoloRetornoImpressaoLote"
        Me.txtProtocoloRetornoImpressaoLote.Size = New System.Drawing.Size(147, 20)
        Me.txtProtocoloRetornoImpressaoLote.TabIndex = 9
        Me.txtProtocoloRetornoImpressaoLote.Text = "Protocolo de Impressão"
        '
        'cmdSolicitarImpressaoLote
        '
        Me.cmdSolicitarImpressaoLote.Location = New System.Drawing.Point(168, 150)
        Me.cmdSolicitarImpressaoLote.Name = "cmdSolicitarImpressaoLote"
        Me.cmdSolicitarImpressaoLote.Size = New System.Drawing.Size(147, 36)
        Me.cmdSolicitarImpressaoLote.TabIndex = 7
        Me.cmdSolicitarImpressaoLote.Text = " Solicitar Impressão em Lote"
        Me.cmdSolicitarImpressaoLote.UseVisualStyleBackColor = True
        '
        'cbbTipoImpressao
        '
        Me.cbbTipoImpressao.FormattingEnabled = True
        Me.cbbTipoImpressao.Items.AddRange(New Object() {"Normal", "Carnê", "Carnê Triplo", "Normal Duplo", "Personalizada"})
        Me.cbbTipoImpressao.Location = New System.Drawing.Point(9, 97)
        Me.cbbTipoImpressao.Name = "cbbTipoImpressao"
        Me.cbbTipoImpressao.Size = New System.Drawing.Size(147, 21)
        Me.cbbTipoImpressao.TabIndex = 6
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(6, 81)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(97, 13)
        Me.Label9.TabIndex = 5
        Me.Label9.Text = "Tipo de Impressão:"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.txtProtocoloRetProc)
        Me.GroupBox5.Controls.Add(Me.btnGerarRemessa)
        Me.GroupBox5.Controls.Add(Me.cmdUploadRet)
        Me.GroupBox5.Controls.Add(Me.btnConsultarUpload)
        Me.GroupBox5.Location = New System.Drawing.Point(689, 14)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(297, 113)
        Me.GroupBox5.TabIndex = 24
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = " Remessa e Retorno "
        '
        'txtProtocoloRetProc
        '
        Me.txtProtocoloRetProc.Location = New System.Drawing.Point(9, 73)
        Me.txtProtocoloRetProc.Name = "txtProtocoloRetProc"
        Me.txtProtocoloRetProc.Size = New System.Drawing.Size(127, 20)
        Me.txtProtocoloRetProc.TabIndex = 10
        Me.txtProtocoloRetProc.Text = "Protocolo Upload Retorno"
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.Label8)
        Me.GroupBox6.Controls.Add(Me.cbbTipoRemessaAlteracao)
        Me.GroupBox6.Controls.Add(Me.txtProtocoloRemessaBaixada)
        Me.GroupBox6.Controls.Add(Me.txtProtocoloRetornoRemessaAlteracao)
        Me.GroupBox6.Controls.Add(Me.cmdConsultarRemessaBaixada)
        Me.GroupBox6.Controls.Add(Me.cmdGerarBaixa)
        Me.GroupBox6.Controls.Add(Me.cmdConsultarProtocoloRemessaAlteracao)
        Me.GroupBox6.Controls.Add(Me.cmdGerarRemessaAlteracao)
        Me.GroupBox6.Location = New System.Drawing.Point(689, 141)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(298, 291)
        Me.GroupBox6.TabIndex = 25
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = " Remessa de Alteração e Baixa"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(163, 48)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(98, 13)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "Remessa de Baixa:"
        '
        'cbbTipoRemessaAlteracao
        '
        Me.cbbTipoRemessaAlteracao.FormattingEnabled = True
        Me.cbbTipoRemessaAlteracao.Items.AddRange(New Object() {"0 - Alteração de Vencimento", "1 - Alteração de Valor"})
        Me.cbbTipoRemessaAlteracao.Location = New System.Drawing.Point(9, 45)
        Me.cbbTipoRemessaAlteracao.Name = "cbbTipoRemessaAlteracao"
        Me.cbbTipoRemessaAlteracao.Size = New System.Drawing.Size(127, 21)
        Me.cbbTipoRemessaAlteracao.TabIndex = 6
        Me.cbbTipoRemessaAlteracao.Text = "Tipo de Remessa"
        '
        'txtProtocoloRemessaBaixada
        '
        Me.txtProtocoloRemessaBaixada.Location = New System.Drawing.Point(166, 168)
        Me.txtProtocoloRemessaBaixada.Name = "txtProtocoloRemessaBaixada"
        Me.txtProtocoloRemessaBaixada.Size = New System.Drawing.Size(125, 20)
        Me.txtProtocoloRemessaBaixada.TabIndex = 5
        Me.txtProtocoloRemessaBaixada.Text = "Protocolo de Baixa"
        '
        'txtProtocoloRetornoRemessaAlteracao
        '
        Me.txtProtocoloRetornoRemessaAlteracao.Location = New System.Drawing.Point(9, 168)
        Me.txtProtocoloRetornoRemessaAlteracao.Name = "txtProtocoloRetornoRemessaAlteracao"
        Me.txtProtocoloRetornoRemessaAlteracao.Size = New System.Drawing.Size(127, 20)
        Me.txtProtocoloRetornoRemessaAlteracao.TabIndex = 4
        Me.txtProtocoloRetornoRemessaAlteracao.Text = "Protocolo de Alteração"
        '
        'cmdConsultarRemessaBaixada
        '
        Me.cmdConsultarRemessaBaixada.Location = New System.Drawing.Point(166, 222)
        Me.cmdConsultarRemessaBaixada.Name = "cmdConsultarRemessaBaixada"
        Me.cmdConsultarRemessaBaixada.Size = New System.Drawing.Size(125, 39)
        Me.cmdConsultarRemessaBaixada.TabIndex = 3
        Me.cmdConsultarRemessaBaixada.Text = "Consultar Remessa Baixada"
        Me.cmdConsultarRemessaBaixada.UseVisualStyleBackColor = True
        '
        'cmdGerarBaixa
        '
        Me.cmdGerarBaixa.Location = New System.Drawing.Point(166, 91)
        Me.cmdGerarBaixa.Name = "cmdGerarBaixa"
        Me.cmdGerarBaixa.Size = New System.Drawing.Size(125, 39)
        Me.cmdGerarBaixa.TabIndex = 2
        Me.cmdGerarBaixa.Text = "Gerar Baixa"
        Me.cmdGerarBaixa.UseVisualStyleBackColor = True
        '
        'cmdConsultarProtocoloRemessaAlteracao
        '
        Me.cmdConsultarProtocoloRemessaAlteracao.Location = New System.Drawing.Point(9, 222)
        Me.cmdConsultarProtocoloRemessaAlteracao.Name = "cmdConsultarProtocoloRemessaAlteracao"
        Me.cmdConsultarProtocoloRemessaAlteracao.Size = New System.Drawing.Size(127, 39)
        Me.cmdConsultarProtocoloRemessaAlteracao.TabIndex = 1
        Me.cmdConsultarProtocoloRemessaAlteracao.Text = "Consultar Remessa de Alteração"
        Me.cmdConsultarProtocoloRemessaAlteracao.UseVisualStyleBackColor = True
        '
        'cmdGerarRemessaAlteracao
        '
        Me.cmdGerarRemessaAlteracao.Location = New System.Drawing.Point(9, 91)
        Me.cmdGerarRemessaAlteracao.Name = "cmdGerarRemessaAlteracao"
        Me.cmdGerarRemessaAlteracao.Size = New System.Drawing.Size(127, 39)
        Me.cmdGerarRemessaAlteracao.TabIndex = 0
        Me.cmdGerarRemessaAlteracao.Text = " Gerar Remessa de Alteração"
        Me.cmdGerarRemessaAlteracao.UseVisualStyleBackColor = True
        '
        'dlgOpen
        '
        Me.dlgOpen.FileName = "OpenFileDialog1"
        '
        'FileSystemWatcher1
        '
        Me.FileSystemWatcher1.EnableRaisingEvents = True
        Me.FileSystemWatcher1.SynchronizingObject = Me
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.txtProtocoloEnvioEmail)
        Me.GroupBox7.Controls.Add(Me.btnConsultaEmailLote)
        Me.GroupBox7.Controls.Add(Me.btnEnviarEmailLote)
        Me.GroupBox7.Location = New System.Drawing.Point(336, 282)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(329, 150)
        Me.GroupBox7.TabIndex = 26
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "E-mail"
        '
        'txtProtocoloEnvioEmail
        '
        Me.txtProtocoloEnvioEmail.Location = New System.Drawing.Point(168, 30)
        Me.txtProtocoloEnvioEmail.Multiline = True
        Me.txtProtocoloEnvioEmail.Name = "txtProtocoloEnvioEmail"
        Me.txtProtocoloEnvioEmail.Size = New System.Drawing.Size(147, 22)
        Me.txtProtocoloEnvioEmail.TabIndex = 8
        Me.txtProtocoloEnvioEmail.Text = "Protocolo E-mail"
        '
        'btnConsultaEmailLote
        '
        Me.btnConsultaEmailLote.Location = New System.Drawing.Point(9, 98)
        Me.btnConsultaEmailLote.Name = "btnConsultaEmailLote"
        Me.btnConsultaEmailLote.Size = New System.Drawing.Size(147, 22)
        Me.btnConsultaEmailLote.TabIndex = 7
        Me.btnConsultaEmailLote.Text = "Consultar Envio Lote"
        Me.btnConsultaEmailLote.UseVisualStyleBackColor = True
        '
        'btnEnviarEmailLote
        '
        Me.btnEnviarEmailLote.Location = New System.Drawing.Point(9, 30)
        Me.btnEnviarEmailLote.Name = "btnEnviarEmailLote"
        Me.btnEnviarEmailLote.Size = New System.Drawing.Size(147, 22)
        Me.btnEnviarEmailLote.TabIndex = 6
        Me.btnEnviarEmailLote.Text = "Enviar E-mail Lote"
        Me.btnEnviarEmailLote.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(12, 68)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(144, 13)
        Me.Label10.TabIndex = 27
        Me.Label10.Text = "Cadastrar Dados do Cedente"
        '
        'btnCadastrarCedente
        '
        Me.btnCadastrarCedente.Location = New System.Drawing.Point(12, 90)
        Me.btnCadastrarCedente.Name = "btnCadastrarCedente"
        Me.btnCadastrarCedente.Size = New System.Drawing.Size(137, 23)
        Me.btnCadastrarCedente.TabIndex = 28
        Me.btnCadastrarCedente.Text = "Cadastrar Cedente"
        Me.btnCadastrarCedente.UseVisualStyleBackColor = True
        '
        'btnCadastrarConta
        '
        Me.btnCadastrarConta.Location = New System.Drawing.Point(163, 90)
        Me.btnCadastrarConta.Name = "btnCadastrarConta"
        Me.btnCadastrarConta.Size = New System.Drawing.Size(137, 23)
        Me.btnCadastrarConta.TabIndex = 29
        Me.btnCadastrarConta.Text = "Cadastrar Conta"
        Me.btnCadastrarConta.UseVisualStyleBackColor = True
        '
        'btnCadastrarConvenio
        '
        Me.btnCadastrarConvenio.Location = New System.Drawing.Point(12, 125)
        Me.btnCadastrarConvenio.Name = "btnCadastrarConvenio"
        Me.btnCadastrarConvenio.Size = New System.Drawing.Size(137, 23)
        Me.btnCadastrarConvenio.TabIndex = 30
        Me.btnCadastrarConvenio.Text = "Cadastrar Convênio"
        Me.btnCadastrarConvenio.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(999, 708)
        Me.Controls.Add(Me.btnCadastrarConvenio)
        Me.Controls.Add(Me.btnCadastrarConta)
        Me.Controls.Add(Me.btnCadastrarCedente)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.GroupBox7)
        Me.Controls.Add(Me.GroupBox6)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtTx2)
        Me.Controls.Add(Me.txtRetorno)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        CType(Me.FileSystemWatcher1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtIdIntegracao As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents btnIncluirBoleto As Button
    Friend WithEvents btnConsultarBoleto As Button
    Friend WithEvents btnConsultarUpload As Button
    Friend WithEvents cmdUploadRet As Button
    Friend WithEvents btnGerarRemessa As Button
    Friend WithEvents txtRetorno As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtTx2 As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents rdProducao As RadioButton
    Friend WithEvents rdHomologacao As RadioButton
    Friend WithEvents BackgroundWorker2 As System.ComponentModel.BackgroundWorker
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents btnConfigurarComponente As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents txtCnpjCedente As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtTokenSoftwareHouse As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtCNPJSoftwareHouse As TextBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents cmdDescartarBoletos As Button
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents cmdSalvarPDFLote As Button
    Friend WithEvents cmdImprimirLote As Button
    Friend WithEvents txtProtocoloRetornoImpressaoLote As TextBox
    Friend WithEvents cmdSolicitarImpressaoLote As Button
    Friend WithEvents cbbTipoImpressao As ComboBox
    Friend WithEvents Label9 As Label
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents txtProtocoloRetProc As TextBox
    Friend WithEvents GroupBox6 As GroupBox
    Friend WithEvents dlgOpen As OpenFileDialog
    Friend WithEvents txtProtocoloRemessaBaixada As TextBox
    Friend WithEvents txtProtocoloRetornoRemessaAlteracao As TextBox
    Friend WithEvents cmdConsultarRemessaBaixada As Button
    Friend WithEvents cmdGerarBaixa As Button
    Friend WithEvents cmdConsultarProtocoloRemessaAlteracao As Button
    Friend WithEvents cmdGerarRemessaAlteracao As Button
    Friend WithEvents Label7 As Label
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents FileSystemWatcher1 As IO.FileSystemWatcher
    Friend WithEvents GroupBox7 As GroupBox
    Friend WithEvents btnEnviarEmailLote As Button
    Friend WithEvents btnConsultaEmailLote As Button
    Friend WithEvents txtProtocoloEnvioEmail As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents cbbTipoRemessaAlteracao As ComboBox
    Friend WithEvents btnCadastrarCedente As Button
    Friend WithEvents Label10 As Label
    Friend WithEvents btnCadastrarConvenio As Button
    Friend WithEvents btnCadastrarConta As Button
End Class
