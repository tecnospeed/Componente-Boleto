﻿Imports System.IO

Public Class Form1
    Public spdBoleto As BoletoX.spdBoletoX

    Private Sub btnConfigurarComponente_Click(sender As Object, e As EventArgs) Handles btnConfigurarComponente.Click

        spdBoleto.Config.URL = "http://homologacao.cobrancabancaria.tecnospeed.com.br:8080"


        If rdHomologacao.Checked = True Then
            spdBoleto.Config.URL = "http://homologacao.cobrancabancaria.tecnospeed.com.br:8080"
            txtRetorno.Text = "Selecionado o ambiente de Homologação"
        Else
            spdBoleto.Config.URL = "http://cobrancabancaria.tecnospeed.com.br"
            txtRetorno.Text = "Selecionado o ambiente de Produção"
        End If

        spdBoleto.ConfigurarSoftwareHouse(txtCNPJSoftwareHouse.Text, txtTokenSoftwareHouse.Text)

        spdBoleto.Config.CedenteCpfCnpj = txtCnpjCedente.Text


    End Sub

    Private Sub btnIncluirBoleto_Click(sender As Object, e As EventArgs) Handles btnIncluirBoleto.Click
    Dim _BoletoLista As BoletoX.IspdRetIncluirLista

        txtIdIntegracao.Clear()

        _BoletoLista = spdBoleto.Incluir(txtTx2.Text)

        txtRetorno.Clear()
        txtRetorno.Text += "### INCLUIR BOLETO ###" + Environment.NewLine
        txtRetorno.Text += "Mensagem de retorno: " + _BoletoLista.Mensagem + Environment.NewLine
        txtRetorno.Text += "Status do retorno: " + _BoletoLista.Status + Environment.NewLine

        For i As Integer = 0 To _BoletoLista.Count() - 1
            txtRetorno.Text += "Item: " + (i + 1).ToString() + Environment.NewLine
            txtRetorno.Text += "NumeroDocumento: " + _BoletoLista.Item(i).NumeroDocumento + Environment.NewLine
            txtRetorno.Text += "IdIntegracao do boleto: " + _BoletoLista.Item(i).IdIntegracao + Environment.NewLine
            txtIdIntegracao.Text += _BoletoLista.Item(i).IdIntegracao
            txtRetorno.Text += "Situacao do boleto: " + _BoletoLista.Item(i).Situacao + Environment.NewLine
            txtRetorno.Text += "NossoNumero do boleto: " + _BoletoLista.Item(i).NossoNumero + Environment.NewLine
            txtRetorno.Text += "ERRO: " + _BoletoLista.Item(i).Erro + Environment.NewLine
            txtRetorno.Text += Environment.NewLine
        Next

    End Sub

    Private Sub btnConsultarBoleto_Click(sender As Object, e As EventArgs) Handles btnConsultarBoleto.Click
        Dim _ConsultarList As BoletoX.IspdRetConsultarLista
        Dim _ConsultarItem As BoletoX.IspdRetConsultarTituloItem

        _ConsultarList = spdBoleto.Consultar(txtIdIntegracao.Text)

        txtRetorno.Clear()
        txtRetorno.Text += "### CONSULTAR TITULO ###" + Environment.NewLine
        txtRetorno.Text += "Mensagem: " + _ConsultarList.Mensagem + Environment.NewLine
        txtRetorno.Text += "Status: " + _ConsultarList.Status + Environment.NewLine

        For i As Integer = 0 To _ConsultarList.Count() - 1
            _ConsultarItem = _ConsultarList.Item(i)
            txtRetorno.Text += "ITEM: " + (i + 1).ToString() + Environment.NewLine
            txtRetorno.Text += "  IdIntegracao: " + _ConsultarItem.IdIntegracao + Environment.NewLine
            txtRetorno.Text += "  Situacao: " + _ConsultarItem.Situacao + Environment.NewLine
            txtRetorno.Text += "  Motivo: " + _ConsultarItem.Motivo + Environment.NewLine
            txtRetorno.Text += Environment.NewLine
            txtRetorno.Text += "CEDENTE:" + Environment.NewLine
            txtRetorno.Text += "  Agencia: " + _ConsultarItem.CedenteAgencia + Environment.NewLine
            txtRetorno.Text += "  AgenciaDV: " + _ConsultarItem.CedenteAgenciaDV + Environment.NewLine
            txtRetorno.Text += "  Código Banco: " + _ConsultarItem.CedenteCodigoBanco + Environment.NewLine
            txtRetorno.Text += "  Carteira: " + _ConsultarItem.CedenteCarteira + Environment.NewLine
            txtRetorno.Text += "  Conta: " + _ConsultarItem.CedenteCarteira + Environment.NewLine
            txtRetorno.Text += "  Numero Convênio: " + _ConsultarItem.CedenteNumeroConvenio + Environment.NewLine
            txtRetorno.Text += Environment.NewLine
            txtRetorno.Text += "SACADO:" + Environment.NewLine
            txtRetorno.Text += "  CPFCNPJ: " + _ConsultarItem.SacadoCPFCNPJ + Environment.NewLine
            txtRetorno.Text += "  Nome: " + _ConsultarItem.SacadoNome + Environment.NewLine
            txtRetorno.Text += "  Telefone: " + _ConsultarItem.SacadoTelefone + Environment.NewLine
            txtRetorno.Text += "  Email: " + _ConsultarItem.SacadoEmail + Environment.NewLine
            txtRetorno.Text += "  Endereço Número: " + _ConsultarItem.SacadoEnderecoNumero + Environment.NewLine
            txtRetorno.Text += "  Endereço Bairro: " + _ConsultarItem.SacadoEnderecoBairro + Environment.NewLine
            txtRetorno.Text += "  Endereço CEP: " + _ConsultarItem.SacadoEnderecoCEP + Environment.NewLine
            txtRetorno.Text += "  Endereço Cidade: " + _ConsultarItem.SacadoEnderecoCidade + Environment.NewLine
            txtRetorno.Text += "  Endereço Complemento: " + _ConsultarItem.SacadoEnderecoComplemento + Environment.NewLine
            txtRetorno.Text += "  Endereço Logradouro: " + _ConsultarItem.SacadoEnderecoLogradouro + Environment.NewLine
            txtRetorno.Text += "  Endereço País: " + _ConsultarItem.SacadoEnderecoPais + Environment.NewLine
            txtRetorno.Text += "  Endereço UF: " + _ConsultarItem.SacadoEnderecoUF + Environment.NewLine
            txtRetorno.Text += Environment.NewLine
            txtRetorno.Text += "TÍTULO:" + Environment.NewLine
            txtRetorno.Text += "  Número Documento: " + _ConsultarItem.TituloNumeroDocumento + Environment.NewLine
            txtRetorno.Text += "  Origem Documento: " + _ConsultarItem.TituloOrigemDocumento + Environment.NewLine
            txtRetorno.Text += "  Nosso Número: " + _ConsultarItem.TituloNossoNumero + Environment.NewLine
            txtRetorno.Text += "  Data Emissão: " + _ConsultarItem.TituloDataEmissao + Environment.NewLine
            txtRetorno.Text += "  Data Vencimento: " + _ConsultarItem.TituloDataVencimento + Environment.NewLine
            txtRetorno.Text += "  Data Desconto: " + _ConsultarItem.TituloDataDesconto + Environment.NewLine
            txtRetorno.Text += "  Valor Desconto: " + _ConsultarItem.TituloValorDesconto.ToString() + Environment.NewLine
            txtRetorno.Text += "  Valor Juros: " + _ConsultarItem.TituloValorJuros.ToString() + Environment.NewLine
            txtRetorno.Text += "  Prazo Protesto: " + _ConsultarItem.TituloPrazoProtesto + Environment.NewLine
            txtRetorno.Text += "  Mensagem 1: " + _ConsultarItem.TituloMensagem01 + Environment.NewLine
            txtRetorno.Text += "  Mensagem 2: " + _ConsultarItem.TituloMensagem02 + Environment.NewLine
            txtRetorno.Text += "  Mensagem 3: " + _ConsultarItem.TituloMensagem03 + Environment.NewLine
            txtRetorno.Text += "  Valor: " + _ConsultarItem.TituloValor.ToString() + Environment.NewLine
            txtRetorno.Text += "  Data Crédito: " + _ConsultarItem.PagamentoDataCredito + Environment.NewLine
            txtRetorno.Text += "  Título Pago: " + _ConsultarItem.PagamentoRealizado.ToString() + Environment.NewLine
            txtRetorno.Text += "  Valor Crédito: " + _ConsultarItem.PagamentoValorCredito.ToString() + Environment.NewLine
            txtRetorno.Text += "  Valor Outros Acréscimos: " + _ConsultarItem.TituloValorOutrosAcrescimos.ToString() + Environment.NewLine
            txtRetorno.Text += "  Valor Pago: " + _ConsultarItem.PagamentoValorPago.ToString() + Environment.NewLine
            txtRetorno.Text += "  Valor Taxa Cobrança: " + _ConsultarItem.PagamentoValorTaxaCobranca.ToString() + Environment.NewLine
            txtRetorno.Text += "  Valor Abatimento: " + _ConsultarItem.TituloValorAbatimento.ToString() + Environment.NewLine
            txtRetorno.Text += "  Valor Outras Despesas: " + _ConsultarItem.PagamentoValorOutrasDespesas.ToString() + Environment.NewLine
            txtRetorno.Text += "  Valor IOF: " + _ConsultarItem.PagamentoValorIOF.ToString() + Environment.NewLine
            txtRetorno.Text += "  Data Pagamento: " + _ConsultarItem.PagamentoData + Environment.NewLine
            txtRetorno.Text += "  Valor Outros Créditos: " + _ConsultarItem.PagamentoValorOutrosCreditos.ToString() + Environment.NewLine
            txtRetorno.Text += "  Pagamento Valor Desconto: " + _ConsultarItem.PagamentoValorDesconto.ToString() + Environment.NewLine
            txtRetorno.Text += "  Pagamento Valor Acréscimos: " + _ConsultarItem.PagamentoValorAcrescimos.ToString() + Environment.NewLine
            txtRetorno.Text += "  Pagamento Valor Abatimento: " + _ConsultarItem.PagamentoValorAbatimento.ToString() + Environment.NewLine
            txtRetorno.Text += "  Impressão Visualizada: " + _ConsultarItem.ImpressaoVisualizada.ToString() + Environment.NewLine

            If _ConsultarItem.TituloOcorrencias.Count > 0 Then
                txtRetorno.Text = txtRetorno.Text & "OCORRÊNCIAS:" + Environment.NewLine

                For j = 0 To _ConsultarItem.TituloOcorrencias.Count - 1
                    txtRetorno.Text = txtRetorno.Text & "  Código: " & _ConsultarItem.TituloOcorrencias.Item(j).Codigo 'Código da ocorrência
                    txtRetorno.Text = txtRetorno.Text & " - " & _ConsultarItem.TituloOcorrencias.Item(j).Mensagem & vbNewLine  'Mensagem de ocorrência
                Next j

                txtRetorno.Text = txtRetorno.Text & vbNewLine

            End If

            For k = 0 To _ConsultarItem.CountTituloMovimentos - 1
                txtRetorno.Text = txtRetorno.Text & "  - Movimentos: " & vbNewLine
                txtRetorno.Text = txtRetorno.Text & "    Movimento Código: " & _ConsultarItem.TituloMovimentos(k).Codigo & vbNewLine     'Código de Movimento
                txtRetorno.Text = txtRetorno.Text & "    Movimento Mensagem: " & _ConsultarItem.TituloMovimentos(k).Mensagem & vbNewLine  'Mensagem do Movimento

                For l = 0 To _ConsultarItem.TituloMovimentos(k).CountOcorrencias - 1
                    txtRetorno.Text = txtRetorno.Text & "    - Ocorrências: " & vbNewLine
                    txtRetorno.Text = txtRetorno.Text & "      Ocorrências Código: " & _ConsultarItem.TituloMovimentos(k).Ocorrencias(l).Codigo & vbNewLine 'Código da ocorrência viculada vinculada ao movimento
                    txtRetorno.Text = txtRetorno.Text & "      Ocorrências Mensagem: " & _ConsultarItem.TituloMovimentos(k).Ocorrencias(l).Mensagem & vbNewLine  'Mensagem da ocorrência viculada vinculada ao movimento
                Next l

                txtRetorno.Text = txtRetorno.Text & vbNewLine

            Next k

        Next

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        spdBoleto = New BoletoX.spdBoletoX

        rdHomologacao.Checked = True
        rdProducao.Checked = False

    End Sub

    Private Sub btnGerarPDF_Click(sender As Object, e As EventArgs)

        Dim _SalvarPDF As BoletoX.IspdRetSalvarPDF

        _SalvarPDF = spdBoleto.SalvarPDF(txtIdIntegracao.Text, AppDomain.CurrentDomain.BaseDirectory + "\PDF\" + txtIdIntegracao.Text.Trim() + ".pdf")

        txtRetorno.Clear()
        txtRetorno.Text += "### SALVAR PDF ###" + Environment.NewLine
        txtRetorno.Text += "Mensagem: " + _SalvarPDF.Mensagem + Environment.NewLine
        txtRetorno.Text += "Status: " + _SalvarPDF.Status + Environment.NewLine
        txtRetorno.Text += "Gerado em: " & AppDomain.CurrentDomain.BaseDirectory + "PDF\" + txtIdIntegracao.Text.Trim() + ".pdf"
        txtRetorno.Text += Environment.NewLine

    End Sub

    Private Sub btnEnviarEmailLote_Click(sender As Object, e As EventArgs) Handles btnEnviarEmailLote.Click

        Dim _EnviarEmailLoteResposta As BoletoX.IspdRetEnvioEmailLote

        _EnviarEmailLoteResposta = spdBoleto.EnviarEmailLote(txtTx2.Text)

        txtRetorno.Clear()
        txtRetorno.Text += "### Enviar Email Lote ###" + Environment.NewLine
        txtRetorno.Text += "Mensagem: " + _EnviarEmailLoteResposta.Mensagem + Environment.NewLine
        txtRetorno.Text += "Status: " + _EnviarEmailLoteResposta.Status + Environment.NewLine
        txtRetorno.Text += "Protocolo: " + _EnviarEmailLoteResposta.Protocolo + Environment.NewLine
        txtRetorno.Text += Environment.NewLine

        txtProtocoloEnvioEmail.Text = _EnviarEmailLoteResposta.Protocolo


    End Sub

    Private Async Sub btnGerarRemessa_Click(sender As Object, e As EventArgs) Handles btnGerarRemessa.Click

        Dim _RemessaList As BoletoX.IspdRetGerarRemessaLista
        Dim _RemessaItem As BoletoX.IspdRetGerarRemessaItem

        _RemessaList = spdBoleto.GerarRemessa(txtIdIntegracao.Text)

        txtRetorno.Clear()
        txtRetorno.Text += "### GERAR REMESSA ###" + Environment.NewLine
        txtRetorno.Text += "Mensagem " + _RemessaList.Mensagem + Environment.NewLine
        txtRetorno.Text += "Status: " + _RemessaList.Status + Environment.NewLine

        For i As Integer = 0 To _RemessaList.Count - 1
            txtRetorno.Text += Environment.NewLine
            _RemessaItem = _RemessaList.Item(i)
            txtRetorno.Text += "Item: " + (i + 1).ToString() + Environment.NewLine
            Using writer As StreamWriter = File.CreateText(AppDomain.CurrentDomain.BaseDirectory + "\Remessas\" + _RemessaItem.Conta + ".txt")  'Exemplo mostrando como salvar a remessa em arquivo.
                Await writer.WriteLineAsync(_RemessaItem.Remessa)
            End Using

            txtRetorno.Text += "Mensagem: " + _RemessaItem.Mensagem + Environment.NewLine
            txtRetorno.Text += "Remessa: " + _RemessaItem.Remessa + Environment.NewLine
            txtRetorno.Text += "Banco: " + _RemessaItem.Banco + Environment.NewLine
            txtRetorno.Text += "Conta: " + _RemessaItem.Conta + Environment.NewLine
            txtRetorno.Text += "Convenio: " + _RemessaItem.Convenio + Environment.NewLine
            txtRetorno.Text += "Número Atual da Remessa: " + _RemessaItem.NumeroAtualRemessa.ToString + Environment.NewLine
            txtRetorno.Text += "Transmissão automática?: " + _RemessaItem.TransmissaoAutomatica.ToString + Environment.NewLine
            txtRetorno.Text += "Erro: " + _RemessaItem.Erro + Environment.NewLine
        Next

    End Sub

    Private Sub btnUploadRetorno_Click(sender As Object, e As EventArgs) Handles cmdUploadRet.Click
        Dim ProcessarRetornoList As BoletoX.spdRetProcessarRetorno

        dlgOpen.InitialDirectory = Application.StartupPath             'Abre a pasta para selecionar o retorno

        If dlgOpen.ShowDialog() = DialogResult.OK Then
            txtTx2.Text = System.IO.File.ReadAllText(dlgOpen.FileName)
        End If

        ProcessarRetornoList = spdBoleto.ProcessarRetorno(txtTx2.Text)  'Envia o retorno

        txtRetorno.Text = "### UPLOAD RETORNO ###" + Environment.NewLine
        txtRetorno.Text = "Mensagem: " + ProcessarRetornoList.Mensagem + Environment.NewLine
        txtRetorno.Text = "Status: " + ProcessarRetornoList.Status + Environment.NewLine
        txtRetorno.Text = "Protocolo: " + ProcessarRetornoList.Protocolo + Environment.NewLine

        txtProtocoloRetProc.Text = ProcessarRetornoList.Protocolo

    End Sub

    Private Sub btnConsultarUpload_Click(sender As Object, e As EventArgs) Handles btnConsultarUpload.Click

        Dim _RetornoConsultarProcessamento As BoletoX.IspdRetConsultarRetornoProcessamento
        Dim _RetornoConsultarProcessamentoItem As BoletoX.IspdRetConsultarRetornoProcessamentoItem

        _RetornoConsultarProcessamento = spdBoleto.ConsultaRetornoProcessamento(txtProtocoloRetProc.Text)

        txtRetorno.Clear()
        txtRetorno.Text += "### CONSULTA RETORNO PROCESSAMENTO ###" + Environment.NewLine
        txtRetorno.Text += "Mensagem: " + _RetornoConsultarProcessamento.Mensagem + Environment.NewLine
        txtRetorno.Text += "Status: " + _RetornoConsultarProcessamento.Status + Environment.NewLine
        txtRetorno.Text += "Situação: " + _RetornoConsultarProcessamento.Situacao + Environment.NewLine

        For i As Integer = 0 To _RetornoConsultarProcessamento.Count() - 1
            _RetornoConsultarProcessamentoItem = _RetornoConsultarProcessamento.Titulos(i)
            txtRetorno.Text += "TITULO: " + (i + 1).ToString() + Environment.NewLine
            txtRetorno.Text += "idIntegracao: " + _RetornoConsultarProcessamentoItem.IdIntegracao + Environment.NewLine
            txtIdIntegracao.Text = _RetornoConsultarProcessamentoItem.IdIntegracao + Environment.NewLine
        Next

    End Sub

    Private Sub GroupBox2_Enter(sender As Object, e As EventArgs) Handles GroupBox2.Enter

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub

    Private Sub txtTokenSH_TextChanged(sender As Object, e As EventArgs) Handles txtTokenSoftwareHouse.TextChanged

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub txtIdIntegracao_TextChanged(sender As Object, e As EventArgs) Handles txtIdIntegracao.TextChanged

    End Sub

    Private Sub cmdImprimir_Click(sender As Object, e As EventArgs)
        Dim retorno As BoletoX.spdRetImprimir

        retorno = spdBoleto.Imprimir(txtIdIntegracao.Text, "")

        txtRetorno.Text = "### IMPRIMIR BOLETO ###" + Environment.NewLine
        txtRetorno.Text = "Mensagem : " + retorno.Mensagem + Environment.NewLine
        txtRetorno.Text = "Status : " + retorno.Status + Environment.NewLine
        txtRetorno.Text += Environment.NewLine

    End Sub

    Private Sub cmdSolicitarImpressaoLote_Click(sender As Object, e As EventArgs) Handles cmdSolicitarImpressaoLote.Click

        Dim ImprimirLoteList As BoletoX.spdRetImprimirLote
        Dim TipoImpressao As Integer

        If (cbbTipoImpressao.SelectedIndex = 0) Then
            TipoImpressao = "0"    'Impressão modo Normal
        ElseIf cbbTipoImpressao.SelectedIndex = 1 Then
            TipoImpressao = "1"  ' Impressão em modo Carne
        ElseIf cbbTipoImpressao.SelectedIndex = 2 Then
            TipoImpressao = "2"    ' Impressão em modo Carne triplo
        ElseIf cbbTipoImpressao.SelectedIndex = 2 Then
            TipoImpressao = "3"    ' Impressão em modo Normal-Duplo
        ElseIf cbbTipoImpressao.SelectedIndex = 3 Then
            TipoImpressao = "99"   ' Impressão Personalizada
        End If

        ImprimirLoteList = spdBoleto.ImprimirLote(txtIdIntegracao.Text, TipoImpressao)

        If (ImprimirLoteList.Protocolo <> "") Then

            txtProtocoloRetornoImpressaoLote.Text = ImprimirLoteList.Protocolo

        End If

        txtRetorno.Text = ".:: Impressão em Lote::." + Environment.NewLine
        txtRetorno.Text = txtRetorno.Text + "Mensagem : " + ImprimirLoteList.Mensagem + Environment.NewLine
        txtRetorno.Text = txtRetorno.Text + "Status : " + ImprimirLoteList.Status + Environment.NewLine
        txtRetorno.Text = txtRetorno.Text + "Protocolo : " + ImprimirLoteList.Protocolo + Environment.NewLine


        If (ImprimirLoteList.Status = "ERRO") Then
            txtRetorno.Text = "ErroClasse : " + ImprimirLoteList.ErroClasse.ToString() + Environment.NewLine
        End If

        txtRetorno.Text += Environment.NewLine
    End Sub

    Private Sub cmdImprimirLote_Click(sender As Object, e As EventArgs) Handles cmdImprimirLote.Click
        Dim Impressao As BoletoX.spdRetConsultarLoteImpressao

        Impressao = spdBoleto.ConsultarLoteImpressao(txtProtocoloRetornoImpressaoLote.Text, "")

        txtRetorno.Text = ".:: Impressão em Lote::." + Environment.NewLine
        txtRetorno.Text = txtRetorno.Text + "Mensagem : " + Impressao.Mensagem + Environment.NewLine
        txtRetorno.Text = txtRetorno.Text + "Status : " + Impressao.Status + Environment.NewLine

        If (Impressao.Status = "ERRO") Then
            txtRetorno.Text = "ErroClasse: " + Impressao.ErroClasse.ToString() + Environment.NewLine
        End If

        txtRetorno.Text += Environment.NewLine
    End Sub

    Private Sub cmdSalvarPDFLote_Click(sender As Object, e As EventArgs) Handles cmdSalvarPDFLote.Click
        Dim SalvarPDFLote As BoletoX.spdRetSalvarLoteImpressaoPDF

        SalvarPDFLote = spdBoleto.SalvarLoteImpressaoPDF(txtProtocoloRetornoImpressaoLote.Text, AppDomain.CurrentDomain.BaseDirectory + "\PDF\" + txtIdIntegracao.Text.Trim() + ".pdf")

        txtRetorno.Text = ".:: Consultar Protocolo Lote Impressão::." + Environment.NewLine
        txtRetorno.Text = txtRetorno.Text + "Mensagem : " + SalvarPDFLote.Mensagem + Environment.NewLine
        txtRetorno.Text = txtRetorno.Text + "Status : " + SalvarPDFLote.Status + Environment.NewLine
        txtRetorno.Text = txtRetorno.Text + "Gerado em: " + AppDomain.CurrentDomain.BaseDirectory + "PDF\" + txtIdIntegracao.Text.Trim() + ".pdf" + Environment.NewLine

        If (SalvarPDFLote.Status = "ERRO") Then
            txtRetorno.Text = "ErroClasse: " & SalvarPDFLote.ErroClasse.ToString()
        End If

        txtRetorno.Text += Environment.NewLine
    End Sub

    Private Sub DateTimePicker1_ValueChanged(sender As Object, e As EventArgs)

    End Sub



    Private Sub cmdGerarRemessaAlteracao_Click(sender As Object, e As EventArgs) Handles cmdGerarRemessaAlteracao.Click
        Dim GerarResposta As BoletoX.spdRetGerarRemessaAlteracao

        GerarResposta = spdBoleto.GerarRemessaAlteracao("0", txtTx2.Text)

        If (cbbTipoRemessaAlteracao.SelectedIndex = 0) Then
            GerarResposta = spdBoleto.GerarRemessaAlteracao("0", txtTx2.Text)   ' Alteração de Vencimento'
        ElseIf cbbTipoRemessaAlteracao.SelectedIndex = 1 Then
            GerarResposta = spdBoleto.GerarRemessaAlteracao("1", txtTx2.Text)    ' Alteração de Valor '
        End If

        txtRetorno.Text = ".:: Gerar Alteração::." + Environment.NewLine
        txtRetorno.Text = txtRetorno.Text + "Mensagem : " + GerarResposta.Mensagem + Environment.NewLine
        txtRetorno.Text = txtRetorno.Text + "Status : " + GerarResposta.Status + Environment.NewLine
        txtRetorno.Text = txtRetorno.Text + "Protocolo: " + GerarResposta.Protocolo + Environment.NewLine

        If (GerarResposta.Status = "ERRO") Then
            txtRetorno.Text = "ErroClasse: " + GerarResposta.ErroClasse.ToString()
        End If

        txtProtocoloRetornoRemessaAlteracao.Text = GerarResposta.Protocolo

    End Sub

    Private Sub cmdConsultarProtocoloRemessaAlteracao_Click(sender As Object, e As EventArgs) Handles cmdConsultarProtocoloRemessaAlteracao.Click
        Dim RetornoConsultarAlteracao As BoletoX.spdRetConsultarRemessaAlteracaoLista
        Dim RetornoConsultarAlteracaoItem As BoletoX.spdRetConsultarRemessaAlteracaoItem

        RetornoConsultarAlteracao = spdBoleto.ConsultarRemessaAlteracao(txtProtocoloRetornoRemessaAlteracao.Text)

        txtRetorno.Text = ".:: Consultar Alteração ::." + Environment.NewLine
        txtRetorno.Text = txtRetorno.Text + "Mensagem : " + RetornoConsultarAlteracao.Mensagem + Environment.NewLine
        txtRetorno.Text = txtRetorno.Text + "Status : " + RetornoConsultarAlteracao.Status + Environment.NewLine
        txtRetorno.Text = txtRetorno.Text + "Situação : " + RetornoConsultarAlteracao.Situacao + Environment.NewLine

        If (RetornoConsultarAlteracao.Status = "ERRO") Then
            txtRetorno.Text = "ErroClasse : " + RetornoConsultarAlteracao.ErroClasse.ToString()
        End If

        txtRetorno.Text += Environment.NewLine


        For i = 0 To RetornoConsultarAlteracao.Count - 1
            RetornoConsultarAlteracaoItem = RetornoConsultarAlteracao.Item(i)
            txtRetorno.Text = txtRetorno.Text + "Item : " + CStr(i + 1) + Environment.NewLine
            txtRetorno.Text = txtRetorno.Text + "Mensagem: " + RetornoConsultarAlteracaoItem.Mensagem + Environment.NewLine
            txtRetorno.Text = txtRetorno.Text + "Remessa : " + RetornoConsultarAlteracaoItem.Remessa + Environment.NewLine
            txtRetorno.Text = txtRetorno.Text + "Banco : " + RetornoConsultarAlteracaoItem.Banco + Environment.NewLine
            txtRetorno.Text = txtRetorno.Text + "Conta : " + RetornoConsultarAlteracaoItem.Conta + Environment.NewLine
            txtRetorno.Text = txtRetorno.Text + "Número Atual da Remessa: " + RetornoConsultarAlteracaoItem.NumeroAtualRemessa.ToString + Environment.NewLine
            txtRetorno.Text = txtRetorno.Text + "Transmissão automática?: " + RetornoConsultarAlteracaoItem.TransmissaoAutomatica.ToString + Environment.NewLine
            txtRetorno.Text = txtRetorno.Text + "Erro : " + RetornoConsultarAlteracaoItem.Erro + Environment.NewLine
            txtRetorno.Text = txtRetorno.Text + "ErroClasse : " + RetornoConsultarAlteracaoItem.ErroClasse.ToString() + Environment.NewLine

            For j = 0 To RetornoConsultarAlteracaoItem.Titulos.Count - 1
                txtRetorno.Text = txtRetorno.Text + "Id Integração : " + CStr(j + 1) + " - " + RetornoConsultarAlteracaoItem.Titulos.Item(j) + Environment.NewLine
            Next j

        Next i
    End Sub

    Private Sub cmdGerarBaixa_Click(sender As Object, e As EventArgs) Handles cmdGerarBaixa.Click
        Dim GerarResposta As BoletoX.spdRetGerarRemessaBaixa

        GerarResposta = spdBoleto.GerarRemessaBaixa(txtIdIntegracao.Text)

        If (GerarResposta.Protocolo <> "") Then
            txtProtocoloRemessaBaixada.Text = GerarResposta.Protocolo
        End If

        txtRetorno.Text = ".:: Gerar Baixa::." + Environment.NewLine
        txtRetorno.Text += Environment.NewLine
        txtRetorno.Text = txtRetorno.Text + "Mensagem : " + GerarResposta.Mensagem + Environment.NewLine
        txtRetorno.Text = txtRetorno.Text + "Status : " + GerarResposta.Status + Environment.NewLine
        txtRetorno.Text = txtRetorno.Text + "Protocolo: " + GerarResposta.Protocolo + Environment.NewLine

        If (GerarResposta.Status = "ERRO") Then
            txtRetorno.Text = txtRetorno.Text + "ErroClasse: " + GerarResposta.ErroClasse.ToString() + Environment.NewLine
        End If

        txtProtocoloRemessaBaixada.Text = GerarResposta.Protocolo

    End Sub

    Private Sub cmdConsultarRemessaBaixada_Click(sender As Object, e As EventArgs) Handles cmdConsultarRemessaBaixada.Click
        Dim RetornoConsultarBaixa As BoletoX.spdRetConsultarRemessaBaixaLista
        Dim RetornoConsultarRemessaBaixaItem As BoletoX.spdRetConsultarRemessaBaixaItem

        RetornoConsultarBaixa = spdBoleto.ConsultarRemessaBaixa(txtProtocoloRemessaBaixada.Text)

        txtRetorno.Text = ""

        txtRetorno.Text = ".:: Consultar Baixa ::." + Environment.NewLine
        txtRetorno.Text = txtRetorno.Text + "Mensagem : " + RetornoConsultarBaixa.Mensagem + Environment.NewLine
        txtRetorno.Text = txtRetorno.Text + "Status : " + RetornoConsultarBaixa.Status + Environment.NewLine
        txtRetorno.Text = txtRetorno.Text + "Situação : " + RetornoConsultarBaixa.Situacao + Environment.NewLine

        If (RetornoConsultarBaixa.ErroConexao <> "") Then
            txtRetorno.Text = txtRetorno.Text + "ErroConexão" + RetornoConsultarBaixa.ErroConexao + Environment.NewLine
        End If

        If (RetornoConsultarBaixa.Status = "ERRO") Then
            txtRetorno.Text = "ErroClasse : " + RetornoConsultarBaixa.ErroClasse.ToString() + Environment.NewLine
        End If

        txtRetorno.Text += Environment.NewLine


        For i = 0 To RetornoConsultarBaixa.Count - 1
            RetornoConsultarRemessaBaixaItem = RetornoConsultarBaixa.Item(i)
            txtRetorno.Text = txtRetorno.Text + "Item : " + CStr(i + 1) + Environment.NewLine
            txtRetorno.Text = txtRetorno.Text + "Mensagem: " + RetornoConsultarRemessaBaixaItem.Mensagem + Environment.NewLine
            txtRetorno.Text = txtRetorno.Text + "Remessa : " + RetornoConsultarRemessaBaixaItem.Remessa + Environment.NewLine
            txtRetorno.Text = txtRetorno.Text + "Banco : " + RetornoConsultarRemessaBaixaItem.Banco + Environment.NewLine
            txtRetorno.Text = txtRetorno.Text + "Conta : " + RetornoConsultarRemessaBaixaItem.Conta + Environment.NewLine
            txtRetorno.Text = txtRetorno.Text + "Número Atual da Remessa: " + RetornoConsultarRemessaBaixaItem.NumeroAtualRemessa.ToString + Environment.NewLine
            txtRetorno.Text = txtRetorno.Text + "Transmissão automática?: " + RetornoConsultarRemessaBaixaItem.TransmissaoAutomatica.ToString + Environment.NewLine
            txtRetorno.Text = txtRetorno.Text + "Erro : " + RetornoConsultarRemessaBaixaItem.Erro + Environment.NewLine
            txtRetorno.Text = txtRetorno.Text + "ErroClasse : " + RetornoConsultarRemessaBaixaItem.ErroClasse.ToString() + Environment.NewLine

            For j = 0 To RetornoConsultarRemessaBaixaItem.Titulos.Count - 1
                txtRetorno.Text = txtRetorno.Text + "Id Integração : " + CStr(j + 1) + " - " + RetornoConsultarRemessaBaixaItem.Titulos.Item(j) + Environment.NewLine
            Next j

        Next i
    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles Label6.Click

    End Sub

    Private Sub btnConsultaEmailLote_Click(sender As Object, e As EventArgs) Handles btnConsultaEmailLote.Click
        Dim _RespostaEmailLote As BoletoX.IspdRetConsultarEmailLote

        _RespostaEmailLote = spdBoleto.ConsultarEmailLote(txtProtocoloEnvioEmail.Text)

        txtRetorno.Text = txtRetorno.Text + Environment.NewLine

        txtRetorno.Text = ".:: Consulta de E-mails em Lote ::." + Environment.NewLine
        txtRetorno.Text = txtRetorno.Text + "Mensagem : " + _RespostaEmailLote.Mensagem + Environment.NewLine
        txtRetorno.Text = txtRetorno.Text + "Status : " + _RespostaEmailLote.Status + Environment.NewLine
        txtRetorno.Text = txtRetorno.Text + "Situação : " + _RespostaEmailLote.Situacao + Environment.NewLine

        If (_RespostaEmailLote.ErroConexao <> "") Then
            txtRetorno.Text = "Erro Conexão: " + _RespostaEmailLote.ErroConexao.ToString()

        End If

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles txtProtocoloEnvioEmail.TextChanged

    End Sub

    Private Sub cmdDescartarBoletos_Click(sender As Object, e As EventArgs) Handles cmdDescartarBoletos.Click
        Dim _Descartelist As BoletoX.IspdRetDescartarLista
        Dim _DescarteItem As BoletoX.IspdRetDescartarTituloItem

        txtRetorno.Clear()
        txtTx2.Clear()

        _Descartelist = spdBoleto.Descartar(txtIdIntegracao.Text)

        txtRetorno.Text = ".:: Descartar Boletos ::." + Environment.NewLine
        txtRetorno.Text = txtRetorno.Text + "Mensagem: " + _Descartelist.Mensagem + Environment.NewLine
        txtRetorno.Text = txtRetorno.Text + "Status: " + _Descartelist.Status + Environment.NewLine

        If (_Descartelist.Status = "ERRO") Then

            txtRetorno.Text += "ErroClasse" + _Descartelist.ErroClasse.ToString()

            txtRetorno.Text += Environment.NewLine

        End If
        For i As Integer = 0 To _Descartelist.Count - 1

            _DescarteItem = _Descartelist.Item(i)

            txtRetorno.Text = txtRetorno.Text + " Item: " & (i + 1) + +Environment.NewLine
            txtRetorno.Text = txtRetorno.Text + "IdIntegracao: " + _DescarteItem.IdIntegracao + Environment.NewLine
            txtRetorno.Text = txtRetorno.Text + " Erro: " + _DescarteItem.Erro + Environment.NewLine
            txtRetorno.Text = txtRetorno.Text + " ErroClasse: " + _DescarteItem.ErroClasse.ToString() + Environment.NewLine
        Next
    End Sub

    Private Sub Label9_Click(sender As Object, e As EventArgs) Handles Label9.Click

    End Sub

    Private Sub btnCadastrarCedente_Click(sender As Object, e As EventArgs) Handles btnCadastrarCedente.Click
        Dim _CadastrarCedente As BoletoX.IspdRetCadastrarCedente

        txtRetorno.Clear()

        _CadastrarCedente = spdBoleto.CadastrarCedente(txtTx2.Text)

        txtRetorno.Text += " .:: Cadastrar Cedente ::. " + Environment.NewLine
        txtRetorno.Text += " Mensagem: " + _CadastrarCedente.Mensagem + Environment.NewLine
        txtRetorno.Text += " Status: " + _CadastrarCedente.Status + Environment.NewLine
        txtRetorno.Text += " Erro de Conexão : " + _CadastrarCedente.ErroConexao + Environment.NewLine
        txtRetorno.Text += Environment.NewLine

        If (_CadastrarCedente.Status = "SUCESSO") Then
            txtRetorno.Text += " Id Cedente " + _CadastrarCedente.IdCedente + Environment.NewLine
            txtRetorno.Text += " Situação : " + _CadastrarCedente.Situacao + Environment.NewLine
            txtRetorno.Text += " Token : " + _CadastrarCedente.Token + Environment.NewLine
            txtRetorno.Text += " CPF/CNPJ : " + _CadastrarCedente.CpfCnpj + Environment.NewLine
            txtRetorno.Text += " Razão Social : " + _CadastrarCedente.RazaoSocial + Environment.NewLine
            txtRetorno.Text += " Nome Fantasia : " + _CadastrarCedente.NomeFantasia + Environment.NewLine
            txtRetorno.Text += Environment.NewLine
        End If




    End Sub

    Private Sub btnCadastrarConta_Click(sender As Object, e As EventArgs) Handles btnCadastrarConta.Click
        Dim _CadastrarConta As BoletoX.IspdRetCadastrarConta

        txtRetorno.Clear()

        _CadastrarConta = spdBoleto.CadastrarConta(txtTx2.Text)

        txtRetorno.Text += " .:: CADASTRAR CONTA ::. " + Environment.NewLine
        txtRetorno.Text += " Mensagem: " + _CadastrarConta.Mensagem + Environment.NewLine
        txtRetorno.Text += " Status: " + _CadastrarConta.Status + Environment.NewLine
        txtRetorno.Text += " Erro de Conexão : " + _CadastrarConta.ErroConexao + Environment.NewLine
        txtRetorno.Text += Environment.NewLine

        If (_CadastrarConta.Status = "SUCESSO") Then
            txtRetorno.Text += " Id Conta: " + _CadastrarConta.IdConta + Environment.NewLine
            txtRetorno.Text += " Código Banco: " + _CadastrarConta.CodigoBanco + Environment.NewLine
            txtRetorno.Text += " Agência: " + _CadastrarConta.Agencia + Environment.NewLine
            txtRetorno.Text += " AgênciaDV: " + _CadastrarConta.AgenciaDV + Environment.NewLine
            txtRetorno.Text += " Conta: " + _CadastrarConta.Conta + Environment.NewLine
            txtRetorno.Text += " Conta DV: " + _CadastrarConta.ContaDV + Environment.NewLine
            txtRetorno.Text += " Tipo Conta: " + _CadastrarConta.TipoConta + Environment.NewLine
            txtRetorno.Text += " Código Beneficiário: " + _CadastrarConta.CodigoBeneficiario + Environment.NewLine
            txtRetorno.Text += " Código Empresa: " + _CadastrarConta.CodigoEmpresa + Environment.NewLine
            txtRetorno.Text += Environment.NewLine
        End If


    End Sub

    Private Sub btnCadastrarConvenio_Click(sender As Object, e As EventArgs) Handles btnCadastrarConvenio.Click
        Dim _CadastrarConvenio As BoletoX.IspdRetCadastrarConvenio

        txtRetorno.Clear()

        _CadastrarConvenio = spdBoleto.CadastrarConvenio(txtTx2.Text)

        txtRetorno.Text += " .:: CADASTRAR CONVÊNIO ::. " + Environment.NewLine
        txtRetorno.Text += " Mensagem: " + _CadastrarConvenio.Mensagem + Environment.NewLine
        txtRetorno.Text += " Status: " + _CadastrarConvenio.Status + Environment.NewLine
        txtRetorno.Text += " Erro de Conexão : " + _CadastrarConvenio.ErroConexao + Environment.NewLine
        txtRetorno.Text += Environment.NewLine

        If (_CadastrarConvenio.Status = "SUCESSO") Then
            txtRetorno.Text += " Id Convênio: " + _CadastrarConvenio.IdConvenio + Environment.NewLine
            txtRetorno.Text += " Número Convênio: " + _CadastrarConvenio.NumeroConvenio + Environment.NewLine
            txtRetorno.Text += " Descrição: " + _CadastrarConvenio.DescricaoConvenio + Environment.NewLine
            txtRetorno.Text += " Carteira: " + _CadastrarConvenio.Carteira + Environment.NewLine
            txtRetorno.Text += " Espécie: " + _CadastrarConvenio.Especie + Environment.NewLine
            txtRetorno.Text += " Padrão CNAB: " + _CadastrarConvenio.PadraoCNAB + Environment.NewLine
            txtRetorno.Text += " Utiliza VAN: " + _CadastrarConvenio.UtilizaVan.ToString() + Environment.NewLine
            txtRetorno.Text += " Número Remessa: " + _CadastrarConvenio.NumeroRemessa + Environment.NewLine
            txtRetorno.Text += " Reiniciar Número Remessa: " + _CadastrarConvenio.ReiniciarDiariamente.ToString() + Environment.NewLine
            txtRetorno.Text += Environment.NewLine
        End If
    End Sub

    Private Sub GroupBox3_Enter(sender As Object, e As EventArgs) Handles GroupBox3.Enter

    End Sub

    Private Sub rdHomologacao_CheckedChanged(sender As Object, e As EventArgs) Handles rdHomologacao.CheckedChanged

    End Sub
End Class
