﻿Imports System.IO
Imports RestSharp
Imports System.Net
Imports System.Text
Imports Newtonsoft.Json

Public Class Form1
    'Variáveris para Configurar Header
    Dim CnpjSoftwareHouse As String
    Dim TokenSoftwareHouse As String
    Dim CnpjCedente As String
    Dim Url As String

    Private Sub btnLoadConfig_Click(sender As Object, e As EventArgs) Handles btnLoadConfig.Click
        CnpjSoftwareHouse = tBoxCNPJSoftwareHouse.Text
        TokenSoftwareHouse = tBoxTokenSoftwareHouse.Text
        CnpjCedente = tBoxCNPJCedente.Text
        Url = "http://homologacao.cobrancabancaria.tecnospeed.com.br:8080"
    End Sub

    Private Sub btnIncluir_Click(sender As Object, e As EventArgs) Handles btnIncluir.Click
        Dim objCamposBoleto As New Dictionary(Of String, String) From {
                                                                        {"CedenteContaNumero", "54354"},
                                                                        {"CedenteContaNumeroDV", "0"},
                                                                        {"CedenteConvenioNumero", "321"},
                                                                        {"CedenteContaCodigoBanco", "001"},
                                                                        {"SacadoCPFCNPJ", "28436161661"},
                                                                        {"SacadoEmail", "email@sacado.com"},
                                                                        {"SacadoEnderecoNumero", "987"},
                                                                        {"SacadoEnderecoBairro", "Centro"},
                                                                        {"SacadoEnderecoCEP", "87098765"},
                                                                        {"SacadoEnderecoCidade", "Maringá"},
                                                                        {"SacadoEnderecoComplemento", "Fundos"},
                                                                        {"SacadoEnderecoLogradouro", "Rua teste, 987"},
                                                                        {"SacadoEnderecoPais", "Brasil"},
                                                                        {"SacadoEnderecoUF", "PR"},
                                                                        {"SacadoNome", "Teste de Souza"},
                                                                        {"SacadoTelefone", "4499999999"},
                                                                        {"SacadoCelular", "44999999999"},
                                                                        {"TituloDataDesconto", "05/01/2020"},
                                                                        {"TituloValorDesconto", "0,01"},
                                                                        {"TituloDataEmissao", "01/01/2020"},
                                                                        {"TituloDataVencimento", "01/01/2020"},
                                                                        {"TituloValorJuros", "0,01"},
                                                                        {"TituloPrazoProtesto", "30"},
                                                                        {"TituloMensagem01", "Juros de 0,01 ao dia"},
                                                                        {"TituloMensagem02", "Nao receber apos 30 dias de atraso"},
                                                                        {"TituloMensagem03", "Titulo sujeito a protesto apos 30 dias"},
                                                                        {"TituloNossoNumero", "6"},
                                                                        {"TituloNumeroDocumento", "01012020"},
                                                                        {"TituloValor", "0,02"},
                                                                        {"TituloLocalPagamento", "Pagável em qualquer banco até o vencimento."}
        }
        Dim Json As String = "[" + JsonConvert.SerializeObject(objCamposBoleto, Formatting.Indented) + "]"
        'Dim JsonBytes As Byte() = Encoding.UTF8.GetBytes(Json)

        Dim client = New RestClient(Url + "/api/v1/boletos/lote")
        Dim request = New RestRequest(Method.POST)
        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("content-type", "application/json")
        request.AddHeader("token-sh", TokenSoftwareHouse)
        request.AddHeader("cnpj-sh", CnpjSoftwareHouse)
        request.AddHeader("cnpj-cedente", CnpjCedente)
        request.AddParameter("application/json", Json, ParameterType.RequestBody)

        Dim ObjBoleto As Object = JsonConvert.DeserializeObject(client.Execute(request).Content)
        rtResposta.Text = JsonConvert.SerializeObject(ObjBoleto, Formatting.Indented)
    End Sub

    Private Sub button4_Click(sender As Object, e As EventArgs) Handles button4.Click
        Dim objCadCedente As New Dictionary(Of String, String) From {
                                                                        {"CedenteRazaoSocial", "Empresa Ltda"},                                                                        {"CedenteNomeFantasia", "Empresa"},                                                                        {"CedenteCPFCNPJ", "62487142000182"},                                                                        {"CedenteEnderecoLogradouro", "Av. Analista Jucá de Souza"},                                                                        {"CedenteEnderecoNumero", "123"},                                                                        {"CedenteEnderecoComplemento", "sala 987"},                                                                        {"CedenteEnderecoBairro", "Centro"},                                                                        {"CedenteEnderecoCEP", "87012345"},                                                                        {"CedenteEnderecoCidadeIBGE", "4115200"},                                                                        {"CedenteTelefone", "(44) 3033-1234"},                                                                        {"CedenteEmail", "cobranca@boleto.com.br"}
        }
        Dim Json As String = JsonConvert.SerializeObject(objCadCedente, Formatting.Indented)

        Dim client = New RestClient(Url + "/api/v1/cedentes")
        Dim request = New RestRequest(Method.POST)
        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("content-type", "application/json")
        request.AddHeader("token-sh", TokenSoftwareHouse)
        request.AddHeader("cnpj-sh", CnpjSoftwareHouse)
        request.AddHeader("cnpj-cedente", CnpjCedente)
        request.AddParameter("application/json", Json, ParameterType.RequestBody)

        Dim ObjBoleto As Object = JsonConvert.DeserializeObject(client.Execute(request).Content)
        rtResposta.Text = JsonConvert.SerializeObject(ObjBoleto, Formatting.Indented)
    End Sub

    Private Sub button5_Click(sender As Object, e As EventArgs) Handles button5.Click
        Dim objCampoConta As New Dictionary(Of String, String) From {
                                                                        {"ContaCodigoBanco", "001"},
                                                                        {"ContaAgencia", "12345"},
                                                                        {"ContaAgenciaDV", "1"},
                                                                        {"ContaNumero", "596989"},
                                                                        {"ContaNumeroDV", "9"},
                                                                        {"ContaTipo", "CORRENTE"},
                                                                        {"ContaCodigoBeneficiario", "596989"}
        }
        Dim Json As String = JsonConvert.SerializeObject(objCampoConta, Formatting.Indented)
        Dim JsonBytes As Byte() = Encoding.UTF8.GetBytes(Json)

        Dim client = New RestClient(Url + "/api/v1/cedentes/contas")
        Dim request = New RestRequest(Method.POST)
        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("content-type", "application/json")
        request.AddHeader("token-sh", TokenSoftwareHouse)
        request.AddHeader("cnpj-sh", CnpjSoftwareHouse)
        request.AddHeader("cnpj-cedente", CnpjCedente)
        request.AddParameter("application/json", Json, ParameterType.RequestBody)

        Dim ObjBoleto As Object = JsonConvert.DeserializeObject(client.Execute(request).Content)
        rtResposta.Text = JsonConvert.SerializeObject(ObjBoleto, Formatting.Indented)
    End Sub

    Private Sub button6_Click(sender As Object, e As EventArgs) Handles button6.Click
        Dim objCampoConvenio As New Dictionary(Of String, String) From {
                                                                        {"ConvenioNumero", "7889604745"},
                                                                        {"ConvenioDescricao", "Convenio da tecnospeed"},
                                                                        {"ConvenioCarteira", "109"},
                                                                        {"ConvenioEspecie", "Boleto"},
                                                                        {"ConvenioPadraoCNAB", "400"},
                                                                        {"ConvenioNumeroRemessa", "1"},
                                                                        {"Conta", "967"}
        }
        Dim Json As String = JsonConvert.SerializeObject(objCampoConvenio, Formatting.Indented)
        Dim JsonBytes As Byte() = Encoding.UTF8.GetBytes(Json)

        Dim client = New RestClient(Url + "/api/v1/cedentes/contas/convenios")
        Dim request = New RestRequest(Method.POST)
        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("content-type", "application/json")
        request.AddHeader("token-sh", TokenSoftwareHouse)
        request.AddHeader("cnpj-sh", CnpjSoftwareHouse)
        request.AddHeader("cnpj-cedente", CnpjCedente)
        request.AddParameter("application/json", Json, ParameterType.RequestBody)

        Dim ObjBoleto As Object = JsonConvert.DeserializeObject(client.Execute(request).Content)
        rtResposta.Text = JsonConvert.SerializeObject(ObjBoleto, Formatting.Indented)
    End Sub

    Private Sub btnDescartarBoletos_Click(sender As Object, e As EventArgs) Handles btnDescartarBoletos.Click
        Dim Json As String = tBoxIdIntegracao.Text
        Json = "[" + JsonConvert.SerializeObject(Json, Formatting.Indented) + "]"
        Dim JsonBytes As Byte() = Encoding.UTF8.GetBytes(Json)

        Dim client = New RestClient(Url + "/api/v1/boletos/descarta/lote")
        Dim request = New RestRequest(Method.POST)
        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("content-type", "application/json")
        request.AddHeader("token-sh", TokenSoftwareHouse)
        request.AddHeader("cnpj-sh", CnpjSoftwareHouse)
        request.AddHeader("cnpj-cedente", CnpjCedente)
        request.AddParameter("application/json", Json, ParameterType.RequestBody)

        Dim ObjBoleto As Object = JsonConvert.DeserializeObject(client.Execute(request).Content)
        rtResposta.Text = JsonConvert.SerializeObject(ObjBoleto, Formatting.Indented)
    End Sub

    Private Sub btnConsultar_Click(sender As Object, e As EventArgs) Handles btnConsultar.Click
        Dim client = New RestClient(Url + "/api/v1/boletos?idintegracao=" + tBoxIdIntegracao.Text)
        Dim request = New RestRequest(Method.GET)
        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("content-type", "application/json")
        request.AddHeader("token-sh", TokenSoftwareHouse)
        request.AddHeader("cnpj-sh", CnpjSoftwareHouse)
        request.AddHeader("cnpj-cedente", CnpjCedente)

        Dim ObjBoleto As Object = JsonConvert.DeserializeObject(client.Execute(request).Content)
        rtResposta.Text = JsonConvert.SerializeObject(ObjBoleto, Formatting.Indented)
    End Sub

    Private Sub btnSolicitarImpressao_Click(sender As Object, e As EventArgs) Handles btnSolicitarImpressao.Click
        Dim tipoimpressão As String
        If cbbTipoImpressao.SelectedIndex = "0" Then
            tipoimpressão = "0"
        ElseIf cbbTipoImpressao.SelectedIndex = "1" Then
            tipoimpressão = "1"
        ElseIf cbbTipoImpressao.SelectedIndex = "2" Then
            tipoimpressão = "2"
        Else
            tipoimpressão = "99"
        End If
        Dim Json As String = "{""tipoImpressao"" :  " + tipoimpressão + ",""boletos"" : [""" + tBoxIdIntegracao.Text + """]}"
        Dim JsonBytes As Byte() = Encoding.UTF8.GetBytes(Json)

        Dim client = New RestClient(Url + "/api/v1/boletos/impressao/lote")
        Dim request = New RestRequest(Method.POST)
        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("content-type", "application/json")
        request.AddHeader("token-sh", TokenSoftwareHouse)
        request.AddHeader("cnpj-sh", CnpjSoftwareHouse)
        request.AddHeader("cnpj-cedente", CnpjCedente)
        request.AddParameter("application/json", Json, ParameterType.RequestBody)

        Dim ObjBoleto As Object = JsonConvert.DeserializeObject(client.Execute(request).Content)
        rtResposta.Text = JsonConvert.SerializeObject(ObjBoleto, Formatting.Indented)
    End Sub

    Private Sub button2_Click(sender As Object, e As EventArgs) Handles button2.Click
        Dim client = New RestClient(Url + "/api/v1/boletos/impressao/lote/" + txtProtocoloImpressao.Text)
        Dim request = New RestRequest(Method.GET)
        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("content-type", "application/json")
        request.AddHeader("token-sh", TokenSoftwareHouse)
        request.AddHeader("cnpj-sh", CnpjSoftwareHouse)
        request.AddHeader("cnpj-cedente", CnpjCedente)

        Dim PdfBytes As Byte() = client.DownloadData(request)
        My.Computer.FileSystem.WriteAllBytes("C:\Temp\TesteVb.pdf", PdfBytes, False)

        rtResposta.Text = "Boleto Salvo em 'C:\Temp\TesteVb.pdf'"
    End Sub

    Private Sub btnEmail_Click(sender As Object, e As EventArgs) Handles btnEmail.Click
        Dim objEmailLote As New Dictionary(Of String, String) From {
                                                                        {"IdIntegracao", "HylLwtVkm"},                                                                        {"EmailNomeRemetente", "Empresa Exemplo"},                                                                        {"EmailRemetente", "exemplo@remetente.com.br"},                                                                        {"EmailAssunto", "Boleto para pagamento"},                                                                        {"EmailMensagem", "Segue o link do boleto:| ${linkBoleto}|Considere não imprimir este email."},                                                                        {"EmailDestinatario", "luiz.bengozi@tecnospeed.com.br"},
                                                                        {"TipoImpressao", "2"},
                                                                        {"EmailAnexarBoleto", "true"}
        }
        Dim Json As String = JsonConvert.SerializeObject(objEmailLote, Formatting.Indented)

        Dim client = New RestClient(Url + "/api/v1/email/lote")
        Dim request = New RestRequest(Method.POST)
        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("content-type", "application/json")
        request.AddHeader("token-sh", TokenSoftwareHouse)
        request.AddHeader("cnpj-sh", CnpjSoftwareHouse)
        request.AddHeader("cnpj-cedente", CnpjCedente)
        request.AddParameter("application/json", Json, ParameterType.RequestBody)

        Dim ObjBoleto As Object = JsonConvert.DeserializeObject(client.Execute(request).Content)
        rtResposta.Text = JsonConvert.SerializeObject(ObjBoleto, Formatting.Indented)
    End Sub

    Private Sub button3_Click(sender As Object, e As EventArgs) Handles button3.Click
        Dim client = New RestClient(Url + "/api/v1/email/lote/" + txtProtocoloEmail.Text)
        Dim request = New RestRequest(Method.GET)
        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("content-type", "application/json")
        request.AddHeader("token-sh", TokenSoftwareHouse)
        request.AddHeader("cnpj-sh", CnpjSoftwareHouse)
        request.AddHeader("cnpj-cedente", CnpjCedente)

        Dim ObjBoleto As Object = JsonConvert.DeserializeObject(client.Execute(request).Content)
        rtResposta.Text = JsonConvert.SerializeObject(ObjBoleto, Formatting.Indented)
    End Sub

    Private Sub btnGerarRemessa_Click(sender As Object, e As EventArgs) Handles btnGerarRemessa.Click
        Dim Json As String = "[""" + tBoxIdIntegracao.Text + """]"
        Dim JsonBytes As Byte() = Encoding.UTF8.GetBytes(Json)

        Dim client = New RestClient(Url + "/api/v1/remessas/lote")
        Dim request = New RestRequest(Method.POST)
        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("content-type", "application/json")
        request.AddHeader("token-sh", TokenSoftwareHouse)
        request.AddHeader("cnpj-sh", CnpjSoftwareHouse)
        request.AddHeader("cnpj-cedente", CnpjCedente)
        request.AddParameter("application/json", Json, ParameterType.RequestBody)

        Dim ObjBoleto As Object = JsonConvert.DeserializeObject(client.Execute(request).Content)
        rtResposta.Text = JsonConvert.SerializeObject(ObjBoleto, Formatting.Indented)
    End Sub

    Private Sub btnUploadRetorno_Click(sender As Object, e As EventArgs) Handles btnUploadRetorno.Click
        Dim retorno As String = Convert.ToBase64String(Encoding.UTF8.GetBytes(rtResposta.Text))
        Dim Json As String = "{""arquivo"":""" + retorno + """}"
        Dim JsonBytes As Byte() = Encoding.UTF8.GetBytes(Json)

        Dim client = New RestClient(Url + "/api/v1/retornos")
        Dim request = New RestRequest(Method.POST)
        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("content-type", "application/json")
        request.AddHeader("token-sh", TokenSoftwareHouse)
        request.AddHeader("cnpj-sh", CnpjSoftwareHouse)
        request.AddHeader("cnpj-cedente", CnpjCedente)
        request.AddParameter("application/json", Json, ParameterType.RequestBody)

        Dim ObjBoleto As Object = JsonConvert.DeserializeObject(client.Execute(request).Content)
        rtResposta.Text = JsonConvert.SerializeObject(ObjBoleto, Formatting.Indented)
    End Sub

    Private Sub btnConsultaProtRetorno_Click(sender As Object, e As EventArgs) Handles btnConsultaProtRetorno.Click
        Dim client = New RestClient(Url + "/api/v1/retornos/" + tbProtocoloUploadRetorno.Text)
        Dim request = New RestRequest(Method.GET)
        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("content-type", "application/json")
        request.AddHeader("token-sh", TokenSoftwareHouse)
        request.AddHeader("cnpj-sh", CnpjSoftwareHouse)
        request.AddHeader("cnpj-cedente", CnpjCedente)

        Dim ObjBoleto As Object = JsonConvert.DeserializeObject(client.Execute(request).Content)
        rtResposta.Text = JsonConvert.SerializeObject(ObjBoleto, Formatting.Indented)
    End Sub

    Private Sub btnSolicitarRemessaAlteracao_Click(sender As Object, e As EventArgs) Handles btnSolicitarRemessaAlteracao.Click
        Dim tipoAlteracao As String
        If cbbTipoRemessaAlteracao.SelectedIndex = "0" Then
            tipoAlteracao = "0"
        ElseIf cbbTipoRemessaAlteracao.SelectedIndex = "1" Then
            tipoAlteracao = "1"
        End If

        Dim objAltera As New Dictionary(Of String, String) From {
                                                                        {"IdIntegracao", "HylLwtVkm"},                                                                        {"TituloValor", "1,50"}
        }

        Dim Json As String = "{""tipo"" : """ + tipoAlteracao + """,""boletos"" : [" + JsonConvert.SerializeObject(objAltera, Formatting.Indented) + "]}"

        Dim client = New RestClient(Url + "/api/v1/boletos/altera/lote")
        Dim request = New RestRequest(Method.POST)
        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("content-type", "application/json")
        request.AddHeader("token-sh", TokenSoftwareHouse)
        request.AddHeader("cnpj-sh", CnpjSoftwareHouse)
        request.AddHeader("cnpj-cedente", CnpjCedente)
        request.AddParameter("application/json", Json, ParameterType.RequestBody)

        Dim ObjBoleto As Object = JsonConvert.DeserializeObject(client.Execute(request).Content)
        rtResposta.Text = JsonConvert.SerializeObject(ObjBoleto, Formatting.Indented)

    End Sub

    Private Sub btnConsultaProtRemAlteracao_Click(sender As Object, e As EventArgs) Handles btnConsultaProtRemAlteracao.Click
        Dim client = New RestClient(Url + "/api/v1/boletos/altera/lote/" + txtProtocoloRemessaAlteracao.Text)
        Dim request = New RestRequest(Method.GET)
        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("content-type", "application/json")
        request.AddHeader("token-sh", TokenSoftwareHouse)
        request.AddHeader("cnpj-sh", CnpjSoftwareHouse)
        request.AddHeader("cnpj-cedente", CnpjCedente)

        Dim ObjBoleto As Object = JsonConvert.DeserializeObject(client.Execute(request).Content)
        rtResposta.Text = JsonConvert.SerializeObject(ObjBoleto, Formatting.Indented)
    End Sub

    Private Sub btnSolicitarBaixa_Click(sender As Object, e As EventArgs) Handles btnSolicitarBaixa.Click
        Dim Json As String = "[""" + tBoxIdIntegracao.Text + """]"

        Dim client = New RestClient(Url + "/api/v1/boletos/baixa/lote")
        Dim request = New RestRequest(Method.POST)
        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("content-type", "application/json")
        request.AddHeader("token-sh", TokenSoftwareHouse)
        request.AddHeader("cnpj-sh", CnpjSoftwareHouse)
        request.AddHeader("cnpj-cedente", CnpjCedente)
        request.AddParameter("application/json", Json, ParameterType.RequestBody)

        Dim ObjBoleto As Object = JsonConvert.DeserializeObject(client.Execute(request).Content)
        rtResposta.Text = JsonConvert.SerializeObject(ObjBoleto, Formatting.Indented)
    End Sub

    Private Sub btnConsultarProtBaixa_Click(sender As Object, e As EventArgs) Handles btnConsultarProtBaixa.Click
        Dim client = New RestClient(Url + "/api/v1/boletos/baixa/lote/" + txtProtocoloBaixa.Text)
        Dim request = New RestRequest(Method.GET)
        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("content-type", "application/json")
        request.AddHeader("token-sh", TokenSoftwareHouse)
        request.AddHeader("cnpj-sh", CnpjSoftwareHouse)
        request.AddHeader("cnpj-cedente", CnpjCedente)

        Dim ObjBoleto As Object = JsonConvert.DeserializeObject(client.Execute(request).Content)
        rtResposta.Text = JsonConvert.SerializeObject(ObjBoleto, Formatting.Indented)
    End Sub
End Class
