﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.button3 = New System.Windows.Forms.Button()
        Me.groupBox8 = New System.Windows.Forms.GroupBox()
        Me.button6 = New System.Windows.Forms.Button()
        Me.button5 = New System.Windows.Forms.Button()
        Me.button4 = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.contextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.button2 = New System.Windows.Forms.Button()
        Me.groupBox4 = New System.Windows.Forms.GroupBox()
        Me.btnConsultarProtBaixa = New System.Windows.Forms.Button()
        Me.txtProtocoloBaixa = New System.Windows.Forms.TextBox()
        Me.btnSolicitarBaixa = New System.Windows.Forms.Button()
        Me.label12 = New System.Windows.Forms.Label()
        Me.label11 = New System.Windows.Forms.Label()
        Me.cbbTipoRemessaAlteracao = New System.Windows.Forms.ComboBox()
        Me.btnConsultaProtRemAlteracao = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtProtocoloRemessaAlteracao = New System.Windows.Forms.TextBox()
        Me.btnSolicitarRemessaAlteracao = New System.Windows.Forms.Button()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.btnGerarRemessa = New System.Windows.Forms.Button()
        Me.groupBox3 = New System.Windows.Forms.GroupBox()
        Me.label9 = New System.Windows.Forms.Label()
        Me.cbbTipoImpressao = New System.Windows.Forms.ComboBox()
        Me.label5 = New System.Windows.Forms.Label()
        Me.txtProtocoloImpressao = New System.Windows.Forms.TextBox()
        Me.btnSolicitarImpressao = New System.Windows.Forms.Button()
        Me.tbProtocoloUploadRetorno = New System.Windows.Forms.TextBox()
        Me.groupBox6 = New System.Windows.Forms.GroupBox()
        Me.btnUploadRetorno = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnConsultaProtRetorno = New System.Windows.Forms.Button()
        Me.txtProtocoloEmail = New System.Windows.Forms.TextBox()
        Me.groupBox5 = New System.Windows.Forms.GroupBox()
        Me.btnLoadConfig = New System.Windows.Forms.Button()
        Me.tBoxCNPJCedente = New System.Windows.Forms.TextBox()
        Me.tBoxTokenSoftwareHouse = New System.Windows.Forms.TextBox()
        Me.tBoxCNPJSoftwareHouse = New System.Windows.Forms.TextBox()
        Me.label3 = New System.Windows.Forms.Label()
        Me.label2 = New System.Windows.Forms.Label()
        Me.label1 = New System.Windows.Forms.Label()
        Me.groupBox2 = New System.Windows.Forms.GroupBox()
        Me.btnDescartarBoletos = New System.Windows.Forms.Button()
        Me.tBoxIdIntegracao = New System.Windows.Forms.TextBox()
        Me.label6 = New System.Windows.Forms.Label()
        Me.btnConsultar = New System.Windows.Forms.Button()
        Me.btnIncluir = New System.Windows.Forms.Button()
        Me.rtResposta = New System.Windows.Forms.RichTextBox()
        Me.groupBox7 = New System.Windows.Forms.GroupBox()
        Me.btnEmail = New System.Windows.Forms.Button()
        Me.groupBox8.SuspendLayout()
        Me.groupBox4.SuspendLayout()
        Me.groupBox3.SuspendLayout()
        Me.groupBox6.SuspendLayout()
        Me.groupBox5.SuspendLayout()
        Me.groupBox2.SuspendLayout()
        Me.groupBox7.SuspendLayout()
        Me.SuspendLayout()
        '
        'button3
        '
        Me.button3.Location = New System.Drawing.Point(9, 67)
        Me.button3.Name = "button3"
        Me.button3.Size = New System.Drawing.Size(137, 23)
        Me.button3.TabIndex = 3
        Me.button3.Text = "Consultar E-mail"
        Me.button3.UseVisualStyleBackColor = True
        '
        'groupBox8
        '
        Me.groupBox8.Controls.Add(Me.button6)
        Me.groupBox8.Controls.Add(Me.button5)
        Me.groupBox8.Controls.Add(Me.button4)
        Me.groupBox8.Location = New System.Drawing.Point(12, 142)
        Me.groupBox8.Name = "groupBox8"
        Me.groupBox8.Size = New System.Drawing.Size(352, 145)
        Me.groupBox8.TabIndex = 84
        Me.groupBox8.TabStop = False
        Me.groupBox8.Text = "Cadastro de cedente "
        '
        'button6
        '
        Me.button6.Location = New System.Drawing.Point(102, 99)
        Me.button6.Name = "button6"
        Me.button6.Size = New System.Drawing.Size(153, 23)
        Me.button6.TabIndex = 2
        Me.button6.Text = "Cadastrar Convênio"
        Me.button6.UseVisualStyleBackColor = True
        '
        'button5
        '
        Me.button5.Location = New System.Drawing.Point(102, 60)
        Me.button5.Name = "button5"
        Me.button5.Size = New System.Drawing.Size(153, 23)
        Me.button5.TabIndex = 1
        Me.button5.Text = "Cadastrar Conta"
        Me.button5.UseVisualStyleBackColor = True
        '
        'button4
        '
        Me.button4.Location = New System.Drawing.Point(102, 19)
        Me.button4.Name = "button4"
        Me.button4.Size = New System.Drawing.Size(153, 23)
        Me.button4.TabIndex = 0
        Me.button4.Text = "Cadastrar Cedente"
        Me.button4.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(27, 393)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(48, 13)
        Me.Label7.TabIndex = 86
        Me.Label7.Text = "Retorno:"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'contextMenuStrip1
        '
        Me.contextMenuStrip1.Name = "contextMenuStrip1"
        Me.contextMenuStrip1.Size = New System.Drawing.Size(61, 4)
        '
        'button2
        '
        Me.button2.Location = New System.Drawing.Point(157, 87)
        Me.button2.Name = "button2"
        Me.button2.Size = New System.Drawing.Size(137, 23)
        Me.button2.TabIndex = 46
        Me.button2.Text = "4 - Consultar Protocolo"
        Me.button2.UseVisualStyleBackColor = True
        '
        'groupBox4
        '
        Me.groupBox4.Controls.Add(Me.btnConsultarProtBaixa)
        Me.groupBox4.Controls.Add(Me.txtProtocoloBaixa)
        Me.groupBox4.Controls.Add(Me.btnSolicitarBaixa)
        Me.groupBox4.Controls.Add(Me.label12)
        Me.groupBox4.Controls.Add(Me.label11)
        Me.groupBox4.Controls.Add(Me.cbbTipoRemessaAlteracao)
        Me.groupBox4.Controls.Add(Me.btnConsultaProtRemAlteracao)
        Me.groupBox4.Controls.Add(Me.Label8)
        Me.groupBox4.Controls.Add(Me.txtProtocoloRemessaAlteracao)
        Me.groupBox4.Controls.Add(Me.btnSolicitarRemessaAlteracao)
        Me.groupBox4.Controls.Add(Me.Label10)
        Me.groupBox4.Location = New System.Drawing.Point(680, 142)
        Me.groupBox4.Name = "groupBox4"
        Me.groupBox4.Size = New System.Drawing.Size(300, 233)
        Me.groupBox4.TabIndex = 88
        Me.groupBox4.TabStop = False
        Me.groupBox4.Text = "Remessa:  Alteração e Baixa"
        '
        'btnConsultarProtBaixa
        '
        Me.btnConsultarProtBaixa.Location = New System.Drawing.Point(6, 180)
        Me.btnConsultarProtBaixa.Name = "btnConsultarProtBaixa"
        Me.btnConsultarProtBaixa.Size = New System.Drawing.Size(137, 23)
        Me.btnConsultarProtBaixa.TabIndex = 62
        Me.btnConsultarProtBaixa.Text = "Cons. Prot. Baixa"
        Me.btnConsultarProtBaixa.UseVisualStyleBackColor = True
        '
        'txtProtocoloBaixa
        '
        Me.txtProtocoloBaixa.Location = New System.Drawing.Point(159, 142)
        Me.txtProtocoloBaixa.Name = "txtProtocoloBaixa"
        Me.txtProtocoloBaixa.Size = New System.Drawing.Size(135, 20)
        Me.txtProtocoloBaixa.TabIndex = 61
        '
        'btnSolicitarBaixa
        '
        Me.btnSolicitarBaixa.Location = New System.Drawing.Point(6, 141)
        Me.btnSolicitarBaixa.Name = "btnSolicitarBaixa"
        Me.btnSolicitarBaixa.Size = New System.Drawing.Size(137, 23)
        Me.btnSolicitarBaixa.TabIndex = 60
        Me.btnSolicitarBaixa.Text = "Solicitar Baixa"
        Me.btnSolicitarBaixa.UseVisualStyleBackColor = True
        '
        'label12
        '
        Me.label12.AutoSize = True
        Me.label12.Location = New System.Drawing.Point(3, 125)
        Me.label12.Name = "label12"
        Me.label12.Size = New System.Drawing.Size(98, 13)
        Me.label12.TabIndex = 59
        Me.label12.Text = "Remessa de Baixa:"
        '
        'label11
        '
        Me.label11.AutoSize = True
        Me.label11.Location = New System.Drawing.Point(4, 16)
        Me.label11.Name = "label11"
        Me.label11.Size = New System.Drawing.Size(117, 13)
        Me.label11.TabIndex = 50
        Me.label11.Text = "Remessa de Alteração:"
        '
        'cbbTipoRemessaAlteracao
        '
        Me.cbbTipoRemessaAlteracao.FormattingEnabled = True
        Me.cbbTipoRemessaAlteracao.Items.AddRange(New Object() {"0 - Vencimento", "1 - Valor"})
        Me.cbbTipoRemessaAlteracao.Location = New System.Drawing.Point(7, 45)
        Me.cbbTipoRemessaAlteracao.Name = "cbbTipoRemessaAlteracao"
        Me.cbbTipoRemessaAlteracao.Size = New System.Drawing.Size(137, 21)
        Me.cbbTipoRemessaAlteracao.TabIndex = 54
        '
        'btnConsultaProtRemAlteracao
        '
        Me.btnConsultaProtRemAlteracao.Location = New System.Drawing.Point(150, 79)
        Me.btnConsultaProtRemAlteracao.Name = "btnConsultaProtRemAlteracao"
        Me.btnConsultaProtRemAlteracao.Size = New System.Drawing.Size(137, 42)
        Me.btnConsultaProtRemAlteracao.TabIndex = 58
        Me.btnConsultaProtRemAlteracao.Text = "8.1 - Consultar Protocolo Alteração"
        Me.btnConsultaProtRemAlteracao.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(3, 29)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(94, 13)
        Me.Label8.TabIndex = 53
        Me.Label8.Text = "Tipo da Alteração:"
        '
        'txtProtocoloRemessaAlteracao
        '
        Me.txtProtocoloRemessaAlteracao.Location = New System.Drawing.Point(7, 98)
        Me.txtProtocoloRemessaAlteracao.Name = "txtProtocoloRemessaAlteracao"
        Me.txtProtocoloRemessaAlteracao.Size = New System.Drawing.Size(137, 20)
        Me.txtProtocoloRemessaAlteracao.TabIndex = 57
        '
        'btnSolicitarRemessaAlteracao
        '
        Me.btnSolicitarRemessaAlteracao.Location = New System.Drawing.Point(150, 45)
        Me.btnSolicitarRemessaAlteracao.Name = "btnSolicitarRemessaAlteracao"
        Me.btnSolicitarRemessaAlteracao.Size = New System.Drawing.Size(137, 23)
        Me.btnSolicitarRemessaAlteracao.TabIndex = 55
        Me.btnSolicitarRemessaAlteracao.Text = "8 - Solicitar Alteração"
        Me.btnSolicitarRemessaAlteracao.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(3, 79)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(118, 13)
        Me.Label10.TabIndex = 56
        Me.Label10.Text = "Protocolo da Alteração:"
        '
        'btnGerarRemessa
        '
        Me.btnGerarRemessa.Location = New System.Drawing.Point(13, 28)
        Me.btnGerarRemessa.Name = "btnGerarRemessa"
        Me.btnGerarRemessa.Size = New System.Drawing.Size(137, 23)
        Me.btnGerarRemessa.TabIndex = 53
        Me.btnGerarRemessa.Text = "5 - Gerar Remessa"
        Me.btnGerarRemessa.UseVisualStyleBackColor = True
        '
        'groupBox3
        '
        Me.groupBox3.Controls.Add(Me.label9)
        Me.groupBox3.Controls.Add(Me.cbbTipoImpressao)
        Me.groupBox3.Controls.Add(Me.label5)
        Me.groupBox3.Controls.Add(Me.txtProtocoloImpressao)
        Me.groupBox3.Controls.Add(Me.btnSolicitarImpressao)
        Me.groupBox3.Controls.Add(Me.button2)
        Me.groupBox3.Location = New System.Drawing.Point(367, 12)
        Me.groupBox3.Name = "groupBox3"
        Me.groupBox3.Size = New System.Drawing.Size(308, 123)
        Me.groupBox3.TabIndex = 87
        Me.groupBox3.TabStop = False
        Me.groupBox3.Text = " Impressão:"
        '
        'label9
        '
        Me.label9.AutoSize = True
        Me.label9.Location = New System.Drawing.Point(6, 16)
        Me.label9.Name = "label9"
        Me.label9.Size = New System.Drawing.Size(94, 13)
        Me.label9.TabIndex = 42
        Me.label9.Text = "Tipo de Impressão"
        '
        'cbbTipoImpressao
        '
        Me.cbbTipoImpressao.FormattingEnabled = True
        Me.cbbTipoImpressao.Items.AddRange(New Object() {"Normal", "Carnê", "Carnê Triplo", "Personalizada"})
        Me.cbbTipoImpressao.Location = New System.Drawing.Point(9, 32)
        Me.cbbTipoImpressao.Name = "cbbTipoImpressao"
        Me.cbbTipoImpressao.Size = New System.Drawing.Size(134, 21)
        Me.cbbTipoImpressao.TabIndex = 43
        '
        'label5
        '
        Me.label5.AutoSize = True
        Me.label5.Location = New System.Drawing.Point(6, 71)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(118, 13)
        Me.label5.TabIndex = 47
        Me.label5.Text = "Protocolo de Impressão"
        '
        'txtProtocoloImpressao
        '
        Me.txtProtocoloImpressao.Location = New System.Drawing.Point(9, 87)
        Me.txtProtocoloImpressao.Name = "txtProtocoloImpressao"
        Me.txtProtocoloImpressao.Size = New System.Drawing.Size(134, 20)
        Me.txtProtocoloImpressao.TabIndex = 45
        '
        'btnSolicitarImpressao
        '
        Me.btnSolicitarImpressao.Location = New System.Drawing.Point(157, 32)
        Me.btnSolicitarImpressao.Name = "btnSolicitarImpressao"
        Me.btnSolicitarImpressao.Size = New System.Drawing.Size(137, 23)
        Me.btnSolicitarImpressao.TabIndex = 41
        Me.btnSolicitarImpressao.Text = "3 - Solicitar Impressão"
        Me.btnSolicitarImpressao.UseVisualStyleBackColor = True
        '
        'tbProtocoloUploadRetorno
        '
        Me.tbProtocoloUploadRetorno.Location = New System.Drawing.Point(156, 82)
        Me.tbProtocoloUploadRetorno.Name = "tbProtocoloUploadRetorno"
        Me.tbProtocoloUploadRetorno.Size = New System.Drawing.Size(137, 20)
        Me.tbProtocoloUploadRetorno.TabIndex = 50
        '
        'groupBox6
        '
        Me.groupBox6.Controls.Add(Me.btnGerarRemessa)
        Me.groupBox6.Controls.Add(Me.btnUploadRetorno)
        Me.groupBox6.Controls.Add(Me.tbProtocoloUploadRetorno)
        Me.groupBox6.Controls.Add(Me.Label4)
        Me.groupBox6.Controls.Add(Me.btnConsultaProtRetorno)
        Me.groupBox6.Location = New System.Drawing.Point(680, 14)
        Me.groupBox6.Name = "groupBox6"
        Me.groupBox6.Size = New System.Drawing.Size(300, 121)
        Me.groupBox6.TabIndex = 89
        Me.groupBox6.TabStop = False
        Me.groupBox6.Text = "Remessa / Retorno"
        '
        'btnUploadRetorno
        '
        Me.btnUploadRetorno.Location = New System.Drawing.Point(156, 28)
        Me.btnUploadRetorno.Name = "btnUploadRetorno"
        Me.btnUploadRetorno.Size = New System.Drawing.Size(137, 23)
        Me.btnUploadRetorno.TabIndex = 49
        Me.btnUploadRetorno.Text = "6 - Upload do Retorno"
        Me.btnUploadRetorno.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(153, 66)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(96, 13)
        Me.Label4.TabIndex = 51
        Me.Label4.Text = "Protocolo Retorno:"
        '
        'btnConsultaProtRetorno
        '
        Me.btnConsultaProtRetorno.Location = New System.Drawing.Point(13, 82)
        Me.btnConsultaProtRetorno.Name = "btnConsultaProtRetorno"
        Me.btnConsultaProtRetorno.Size = New System.Drawing.Size(137, 23)
        Me.btnConsultaProtRetorno.TabIndex = 52
        Me.btnConsultaProtRetorno.Text = "7 - Consulta Prot. Retorno"
        Me.btnConsultaProtRetorno.UseVisualStyleBackColor = True
        '
        'txtProtocoloEmail
        '
        Me.txtProtocoloEmail.Location = New System.Drawing.Point(157, 30)
        Me.txtProtocoloEmail.Name = "txtProtocoloEmail"
        Me.txtProtocoloEmail.Size = New System.Drawing.Size(137, 20)
        Me.txtProtocoloEmail.TabIndex = 2
        '
        'groupBox5
        '
        Me.groupBox5.Controls.Add(Me.btnLoadConfig)
        Me.groupBox5.Controls.Add(Me.tBoxCNPJCedente)
        Me.groupBox5.Controls.Add(Me.tBoxTokenSoftwareHouse)
        Me.groupBox5.Controls.Add(Me.tBoxCNPJSoftwareHouse)
        Me.groupBox5.Controls.Add(Me.label3)
        Me.groupBox5.Controls.Add(Me.label2)
        Me.groupBox5.Controls.Add(Me.label1)
        Me.groupBox5.Location = New System.Drawing.Point(12, 12)
        Me.groupBox5.Name = "groupBox5"
        Me.groupBox5.Size = New System.Drawing.Size(352, 123)
        Me.groupBox5.TabIndex = 83
        Me.groupBox5.TabStop = False
        Me.groupBox5.Text = " Configurações "
        '
        'btnLoadConfig
        '
        Me.btnLoadConfig.Location = New System.Drawing.Point(141, 78)
        Me.btnLoadConfig.Name = "btnLoadConfig"
        Me.btnLoadConfig.Size = New System.Drawing.Size(200, 23)
        Me.btnLoadConfig.TabIndex = 14
        Me.btnLoadConfig.Text = "Carregar Configurações"
        Me.btnLoadConfig.UseVisualStyleBackColor = True
        '
        'tBoxCNPJCedente
        '
        Me.tBoxCNPJCedente.Location = New System.Drawing.Point(5, 80)
        Me.tBoxCNPJCedente.Name = "tBoxCNPJCedente"
        Me.tBoxCNPJCedente.Size = New System.Drawing.Size(114, 20)
        Me.tBoxCNPJCedente.TabIndex = 13
        Me.tBoxCNPJCedente.Text = "01001001000113"
        '
        'tBoxTokenSoftwareHouse
        '
        Me.tBoxTokenSoftwareHouse.Location = New System.Drawing.Point(141, 35)
        Me.tBoxTokenSoftwareHouse.Name = "tBoxTokenSoftwareHouse"
        Me.tBoxTokenSoftwareHouse.Size = New System.Drawing.Size(202, 20)
        Me.tBoxTokenSoftwareHouse.TabIndex = 12
        Me.tBoxTokenSoftwareHouse.Text = "f22b97c0c9a3d41ac0a3875aba69e5aa"
        '
        'tBoxCNPJSoftwareHouse
        '
        Me.tBoxCNPJSoftwareHouse.Location = New System.Drawing.Point(5, 35)
        Me.tBoxCNPJSoftwareHouse.Name = "tBoxCNPJSoftwareHouse"
        Me.tBoxCNPJSoftwareHouse.Size = New System.Drawing.Size(114, 20)
        Me.tBoxCNPJSoftwareHouse.TabIndex = 11
        Me.tBoxCNPJSoftwareHouse.Text = "01001001000113"
        '
        'label3
        '
        Me.label3.AutoSize = True
        Me.label3.Location = New System.Drawing.Point(4, 62)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(92, 13)
        Me.label3.TabIndex = 10
        Me.label3.Text = "CNPJ do Cedente"
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Location = New System.Drawing.Point(138, 19)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(117, 13)
        Me.label2.TabIndex = 9
        Me.label2.Text = "Token Software House"
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Location = New System.Drawing.Point(4, 19)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(113, 13)
        Me.label1.TabIndex = 8
        Me.label1.Text = "CNPJ Software House"
        '
        'groupBox2
        '
        Me.groupBox2.Controls.Add(Me.btnDescartarBoletos)
        Me.groupBox2.Controls.Add(Me.tBoxIdIntegracao)
        Me.groupBox2.Controls.Add(Me.label6)
        Me.groupBox2.Controls.Add(Me.btnConsultar)
        Me.groupBox2.Controls.Add(Me.btnIncluir)
        Me.groupBox2.Location = New System.Drawing.Point(12, 293)
        Me.groupBox2.Name = "groupBox2"
        Me.groupBox2.Size = New System.Drawing.Size(352, 99)
        Me.groupBox2.TabIndex = 82
        Me.groupBox2.TabStop = False
        Me.groupBox2.Text = " Incluir e Consultar Boletos "
        '
        'btnDescartarBoletos
        '
        Me.btnDescartarBoletos.Location = New System.Drawing.Point(235, 56)
        Me.btnDescartarBoletos.Name = "btnDescartarBoletos"
        Me.btnDescartarBoletos.Size = New System.Drawing.Size(108, 22)
        Me.btnDescartarBoletos.TabIndex = 6
        Me.btnDescartarBoletos.Text = "Descartar Boletos"
        Me.btnDescartarBoletos.UseVisualStyleBackColor = True
        '
        'tBoxIdIntegracao
        '
        Me.tBoxIdIntegracao.Location = New System.Drawing.Point(6, 58)
        Me.tBoxIdIntegracao.Name = "tBoxIdIntegracao"
        Me.tBoxIdIntegracao.Size = New System.Drawing.Size(201, 20)
        Me.tBoxIdIntegracao.TabIndex = 4
        '
        'label6
        '
        Me.label6.AutoSize = True
        Me.label6.Location = New System.Drawing.Point(6, 42)
        Me.label6.Name = "label6"
        Me.label6.Size = New System.Drawing.Size(67, 13)
        Me.label6.TabIndex = 3
        Me.label6.Text = "IdIntegracao"
        '
        'btnConsultar
        '
        Me.btnConsultar.Location = New System.Drawing.Point(235, 27)
        Me.btnConsultar.Name = "btnConsultar"
        Me.btnConsultar.Size = New System.Drawing.Size(108, 23)
        Me.btnConsultar.TabIndex = 2
        Me.btnConsultar.Text = "Consultar Boleto"
        Me.btnConsultar.UseVisualStyleBackColor = True
        '
        'btnIncluir
        '
        Me.btnIncluir.Location = New System.Drawing.Point(120, 27)
        Me.btnIncluir.Name = "btnIncluir"
        Me.btnIncluir.Size = New System.Drawing.Size(108, 23)
        Me.btnIncluir.TabIndex = 1
        Me.btnIncluir.Text = "Incluir Boleto"
        Me.btnIncluir.UseVisualStyleBackColor = True
        '
        'rtResposta
        '
        Me.rtResposta.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rtResposta.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.rtResposta.Location = New System.Drawing.Point(12, 409)
        Me.rtResposta.Name = "rtResposta"
        Me.rtResposta.Size = New System.Drawing.Size(967, 283)
        Me.rtResposta.TabIndex = 85
        Me.rtResposta.Text = ""
        '
        'groupBox7
        '
        Me.groupBox7.Controls.Add(Me.button3)
        Me.groupBox7.Controls.Add(Me.txtProtocoloEmail)
        Me.groupBox7.Controls.Add(Me.btnEmail)
        Me.groupBox7.Location = New System.Drawing.Point(367, 142)
        Me.groupBox7.Name = "groupBox7"
        Me.groupBox7.Size = New System.Drawing.Size(308, 110)
        Me.groupBox7.TabIndex = 90
        Me.groupBox7.TabStop = False
        Me.groupBox7.Text = "Email Lote"
        '
        'btnEmail
        '
        Me.btnEmail.Location = New System.Drawing.Point(9, 30)
        Me.btnEmail.Name = "btnEmail"
        Me.btnEmail.Size = New System.Drawing.Size(137, 23)
        Me.btnEmail.TabIndex = 1
        Me.btnEmail.Text = "Email"
        Me.btnEmail.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(987, 700)
        Me.Controls.Add(Me.groupBox8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.groupBox4)
        Me.Controls.Add(Me.groupBox3)
        Me.Controls.Add(Me.groupBox6)
        Me.Controls.Add(Me.groupBox5)
        Me.Controls.Add(Me.groupBox2)
        Me.Controls.Add(Me.rtResposta)
        Me.Controls.Add(Me.groupBox7)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.groupBox8.ResumeLayout(False)
        Me.groupBox4.ResumeLayout(False)
        Me.groupBox4.PerformLayout()
        Me.groupBox3.ResumeLayout(False)
        Me.groupBox3.PerformLayout()
        Me.groupBox6.ResumeLayout(False)
        Me.groupBox6.PerformLayout()
        Me.groupBox5.ResumeLayout(False)
        Me.groupBox5.PerformLayout()
        Me.groupBox2.ResumeLayout(False)
        Me.groupBox2.PerformLayout()
        Me.groupBox7.ResumeLayout(False)
        Me.groupBox7.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Private WithEvents button3 As Button
    Private WithEvents groupBox8 As GroupBox
    Private WithEvents button6 As Button
    Private WithEvents button5 As Button
    Private WithEvents button4 As Button
    Private WithEvents Label7 As Label
    Private WithEvents contextMenuStrip1 As ContextMenuStrip
    Private WithEvents button2 As Button
    Private WithEvents groupBox4 As GroupBox
    Private WithEvents btnConsultarProtBaixa As Button
    Private WithEvents txtProtocoloBaixa As TextBox
    Private WithEvents btnSolicitarBaixa As Button
    Private WithEvents label12 As Label
    Private WithEvents label11 As Label
    Private WithEvents cbbTipoRemessaAlteracao As ComboBox
    Private WithEvents btnConsultaProtRemAlteracao As Button
    Private WithEvents Label8 As Label
    Private WithEvents txtProtocoloRemessaAlteracao As TextBox
    Private WithEvents btnSolicitarRemessaAlteracao As Button
    Private WithEvents Label10 As Label
    Private WithEvents btnGerarRemessa As Button
    Private WithEvents groupBox3 As GroupBox
    Private WithEvents label9 As Label
    Private WithEvents cbbTipoImpressao As ComboBox
    Private WithEvents label5 As Label
    Private WithEvents txtProtocoloImpressao As TextBox
    Private WithEvents btnSolicitarImpressao As Button
    Private WithEvents tbProtocoloUploadRetorno As TextBox
    Private WithEvents groupBox6 As GroupBox
    Private WithEvents btnUploadRetorno As Button
    Private WithEvents Label4 As Label
    Private WithEvents btnConsultaProtRetorno As Button
    Private WithEvents txtProtocoloEmail As TextBox
    Private WithEvents groupBox5 As GroupBox
    Private WithEvents btnLoadConfig As Button
    Private WithEvents tBoxCNPJCedente As TextBox
    Private WithEvents tBoxTokenSoftwareHouse As TextBox
    Private WithEvents tBoxCNPJSoftwareHouse As TextBox
    Private WithEvents label3 As Label
    Private WithEvents label2 As Label
    Private WithEvents label1 As Label
    Private WithEvents groupBox2 As GroupBox
    Private WithEvents btnDescartarBoletos As Button
    Private WithEvents tBoxIdIntegracao As TextBox
    Private WithEvents label6 As Label
    Private WithEvents btnConsultar As Button
    Private WithEvents btnIncluir As Button
    Private WithEvents rtResposta As RichTextBox
    Private WithEvents groupBox7 As GroupBox
    Private WithEvents btnEmail As Button
End Class
