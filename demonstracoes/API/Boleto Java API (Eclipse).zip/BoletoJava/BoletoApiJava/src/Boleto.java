import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.wb.swt.Configuracao;
import org.eclipse.wb.swt.InterfaceAPI;
import org.eclipse.wb.swt.SWTResourceManager;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import models.IncluirBoleto;
import models.Retorno;
import models.SolicitarPDF;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Boleto {

	protected Shell shlBoletoapi;
	private Text txtBanco;
	private Text txtConta;
	private Text txtDv;
	private Text txtConvenio;
	private Text txtNossonumero;
	private Text txtNumerodocumento;
	private Text txtValor;
	private Text txtIdintegracao;
	private Text txtProtocoloimpressao;
	private Text txtSituacaoimpressao;
	private Text txtRemessa;
	private Text txtRetorno;
	private Text txtProtocolo;
	private Text txtRespostaApi;
	private Text txtStatus;
	private Text txtSituacao;
	private Text txtErro;
	private Text txtMensagem;

	/**
	 * Launch the application.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			Boleto window = new Boleto();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shlBoletoapi.open();
		shlBoletoapi.layout();
		while (!shlBoletoapi.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shlBoletoapi = new Shell();
		shlBoletoapi.setSize(740, 626);
		shlBoletoapi.setText("BoletoApi");

		Group grpIncluirBoleto = new Group(shlBoletoapi, SWT.NONE);
		grpIncluirBoleto.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		grpIncluirBoleto.setText("Incluir Boleto");
		grpIncluirBoleto.setBounds(11, 149, 222, 242);

		Label lblBanco = new Label(grpIncluirBoleto, SWT.NONE);
		lblBanco.setBounds(18, 46, 43, 15);
		lblBanco.setText("Banco");

		Label lblConta = new Label(grpIncluirBoleto, SWT.NONE);
		lblConta.setBounds(67, 46, 43, 15);
		lblConta.setText("Conta");

		Label lblDv = new Label(grpIncluirBoleto, SWT.NONE);
		lblDv.setBounds(118, 46, 21, 15);
		lblDv.setText("DV");

		Label lblConvenio = new Label(grpIncluirBoleto, SWT.NONE);
		lblConvenio.setBounds(151, 46, 55, 15);
		lblConvenio.setText("Convenio");

		txtBanco = new Text(grpIncluirBoleto, SWT.BORDER);
		txtBanco.setText("341");
		txtBanco.setBounds(18, 67, 36, 21);

		txtConta = new Text(grpIncluirBoleto, SWT.BORDER);
		txtConta.setText("12124");
		txtConta.setBounds(66, 67, 44, 21);

		txtDv = new Text(grpIncluirBoleto, SWT.BORDER);
		txtDv.setText("1");
		txtDv.setBounds(118, 67, 21, 21);

		txtConvenio = new Text(grpIncluirBoleto, SWT.BORDER);
		txtConvenio.setText("12121");
		txtConvenio.setBounds(151, 67, 55, 21);

		Label lblContaConvenio = new Label(grpIncluirBoleto, SWT.NONE);
		lblContaConvenio.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		lblContaConvenio.setBounds(10, 21, 121, 15);
		lblContaConvenio.setText("Conta / Convenio");

		Label lblTitulo = new Label(grpIncluirBoleto, SWT.NONE);
		lblTitulo.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		lblTitulo.setBounds(10, 103, 55, 15);
		lblTitulo.setText("Titulo");

		Label lblNossoNumero = new Label(grpIncluirBoleto, SWT.NONE);
		lblNossoNumero.setBounds(18, 124, 68, 15);
		lblNossoNumero.setText("Nosso Num");

		Label lblNumeroDoc = new Label(grpIncluirBoleto, SWT.NONE);
		lblNumeroDoc.setBounds(92, 124, 68, 15);
		lblNumeroDoc.setText("Numero Doc");

		Label lblValor = new Label(grpIncluirBoleto, SWT.NONE);
		lblValor.setBounds(166, 124, 40, 15);
		lblValor.setText("Valor");

		txtNossonumero = new Text(grpIncluirBoleto, SWT.BORDER);
		txtNossonumero.setBounds(18, 145, 68, 21);

		txtNumerodocumento = new Text(grpIncluirBoleto, SWT.BORDER);
		txtNumerodocumento.setBounds(92, 145, 68, 21);

		txtValor = new Text(grpIncluirBoleto, SWT.BORDER);
		txtValor.setBounds(166, 145, 40, 21);

		Label lblIdintegracao = new Label(grpIncluirBoleto, SWT.NONE);
		lblIdintegracao.setBounds(18, 189, 68, 15);
		lblIdintegracao.setText("IDintegracao");

		txtIdintegracao = new Text(grpIncluirBoleto, SWT.BORDER);
		txtIdintegracao.setBounds(18, 210, 68, 21);

		Button btnIncluir = new Button(grpIncluirBoleto, SWT.NONE);
		btnIncluir.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

				try {

					txtMensagem.setText("");
					txtRespostaApi.setText("");
					txtErro.setText("");

					IncluirBoleto boleto = new IncluirBoleto(txtConta.getText(), txtDv.getText(), txtConvenio.getText(),
							txtBanco.getText(), "01001001000113", "luiz.bengozi@tecnospeed.com.br", "45", "Centro",
							"86890000", "Cambira", "Casa", "Rua Venezuela", "Brasil", "PR", "Sacado Teste",
							"4334343434", "43999999999", "22/04/2019", "22/04/2020", "Mensagem 01", "Mensagem 02",
							"Mensagem 03", txtNossonumero.getText(), txtNumerodocumento.getText(), txtValor.getText(),
							"Pag�vel at� o vencimento");
					ArrayList<IncluirBoleto> list = new ArrayList<>();

					list.add(boleto);

					InterfaceAPI interfaceBoleto = Configuracao.createService(InterfaceAPI.class);

					Call<JsonObject> call = interfaceBoleto.Incluir(list);

					call.enqueue(new Callback<JsonObject>() {

						@Override
						public void onFailure(Call<JsonObject> arg0, Throwable response) {
							Display.getDefault().syncExec(new Runnable() {
								public void run() {
									txtRespostaApi.setText(txtRespostaApi.getText() + "\nFalha:");
									txtRespostaApi.setText(
											txtRespostaApi.getText() + "\nResposta:\n" + response.getMessage());
								}
							});
						}

						@Override
						public void onResponse(Call<JsonObject> arg0, Response<JsonObject> response) {

							Display.getDefault().syncExec(new Runnable() {
								public void run() {
									if (response.isSuccessful()) {
										txtStatus.setText(response.body().get("_status").toString());
										txtRespostaApi.setText(response.body().toString());

										JsonObject JsonDados = new JsonObject();
										JsonDados = (JsonObject) response.body().get("_dados");

										if (JsonDados.isJsonNull()) {
											txtRespostaApi.setText("Erro ao preencher dados");
										} else {
											JsonArray jArraySucesso = (JsonArray) JsonDados.get("_sucesso");
											JsonArray jArrayFalha = (JsonArray) JsonDados.get("_falha");

											for (int i = 0; i < jArrayFalha.size(); i++) {
												JsonObject Obj = new JsonObject();
												Obj = (JsonObject) jArrayFalha.get(i);

												JsonObject Erro = new JsonObject();
												Erro = (JsonObject) Obj.get("_erro");

												txtErro.setText(Erro.get("erros").getAsString());
												txtMensagem.setText("Erro ao emitir Boleto");
											}

											for (int i = 0; i < jArraySucesso.size(); i++) {
												JsonObject Obj = new JsonObject();
												Obj = (JsonObject) jArraySucesso.get(i);

												List<String> lista = new ArrayList<String>();
												lista.add(Obj.get("idintegracao").getAsString());

												System.out.println(lista);

											}

										}

									} else {
										try {
											String errorBody = response.errorBody().string();
											txtRespostaApi
													.setText(txtRespostaApi.getText() + "\nErroBody:\n" + errorBody);
										} catch (Exception e) {
											txtRespostaApi
													.setText(txtRespostaApi.getText() + "\nErro:\n" + e.toString());
										}
									}
								}
							});

						}

					});

				} catch (Exception e2) {
					// TODO: handle exception

					MessageDialog.openError(shlBoletoapi, "Ero", e2.toString());
					return;
				}

			}
		});
		btnIncluir.setBounds(92, 208, 55, 25);
		btnIncluir.setText("Incluir");

		Button btnConsultar = new Button(grpIncluirBoleto, SWT.NONE);
		btnConsultar.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				try {

					txtMensagem.setText("");
					txtRespostaApi.setText("");
					txtErro.setText("");
					
					String idintegracao = txtIdintegracao.getText();
					
					InterfaceAPI interfaceBoleto = Configuracao.createService(InterfaceAPI.class);

					Call<JsonObject> call = interfaceBoleto.Consultar(idintegracao);
					
					call.enqueue(new Callback<JsonObject>() {

						@Override
						public void onResponse(Call<JsonObject> arg0, Response<JsonObject> response) {
							// TODO Auto-generated method stub
							Display.getDefault().syncExec(new Runnable() {

								@Override
								public void run() {
									if (response.isSuccessful()) {
										txtStatus.setText(response.body().get("_status").toString());
										txtRespostaApi.setText(response.body().toString());	
									};
									
								}
								
							});
							
						}
						
						@Override
						public void onFailure(Call<JsonObject> arg0, Throwable response) {
							Display.getDefault().syncExec(new Runnable() {
								public void run() {
									txtRespostaApi.setText(txtRespostaApi.getText() + "\nFalha:");
									txtRespostaApi.setText(
									txtRespostaApi.getText() + "\nResposta:\n" + response.getMessage());
								}
							});
							
						}

					});
					
					

					

				} catch (Exception e2) {
					// TODO: handle exception

					MessageDialog.openError(shlBoletoapi, "Ero", e2.toString());
					return;
				}
			}
		});
		btnConsultar.setText("Consultar");
		btnConsultar.setBounds(149, 208, 57, 25);

		Group grpImpressao = new Group(shlBoletoapi, SWT.NONE);
		grpImpressao.setFont(SWTResourceManager.getFont("Segoe UI", 9, SWT.BOLD));
		grpImpressao.setText("Impressao");
		grpImpressao.setBounds(11, 394, 222, 189);

		Combo comboImpressao = new Combo(grpImpressao, SWT.NONE);
		comboImpressao.setItems(new String[] { "Normal - Simples", "Canet - Duplo", "Carnet - Triplo", "Normal - Dupla",
				"Marca D' \u00C1gua", "Personalizada" });
		comboImpressao.setBounds(10, 42, 202, 23);
		comboImpressao.select(0);

		Label lblTipoDeImpressao = new Label(grpImpressao, SWT.NONE);
		lblTipoDeImpressao.setBounds(10, 21, 111, 15);
		lblTipoDeImpressao.setText("Tipo de Impressao");

		Button btnSolicitarImpressao = new Button(grpImpressao, SWT.NONE);
		btnSolicitarImpressao.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				try {

					txtMensagem.setText("");
					txtRespostaApi.setText("");
					txtErro.setText("");
					
					Integer TipoImpressao = comboImpressao.getSelectionIndex();
					
					if (TipoImpressao == 5) {
						TipoImpressao = 99;
					}
					
					List<String> boletos = new ArrayList<String>();
					
					boletos.add(txtIdintegracao.getText());
					
					SolicitarPDF JsonPdf = new SolicitarPDF(TipoImpressao.toString(), boletos);
					
					InterfaceAPI interfaceBoleto = Configuracao.createService(InterfaceAPI.class);

					Call<JsonObject> call = interfaceBoleto.SolicitarImpressao(JsonPdf);
					
					call.enqueue(new Callback<JsonObject>() {

						@Override
						public void onResponse(Call<JsonObject> arg0, Response<JsonObject> response) {
							Display.getDefault().syncExec(new Runnable() {

								@Override
								public void run() {
									if (response.isSuccessful()) {
										txtStatus.setText(response.body().get("_status").toString());
										txtRespostaApi.setText(response.body().toString());	
										
										JsonObject JsonDados = new JsonObject();
										JsonDados = (JsonObject) response.body().get("_dados");
										
										System.out.println(JsonDados.toString());
										
										txtProtocoloimpressao.setText(JsonDados.get("protocolo").toString());
									};
									
								}
								
							});
						}
						
						@Override
						public void onFailure(Call<JsonObject> arg0, Throwable response) {
							Display.getDefault().syncExec(new Runnable() {
								public void run() {
									txtRespostaApi.setText(txtRespostaApi.getText() + "\nFalha:");
									txtRespostaApi.setText(
									txtRespostaApi.getText() + "\nResposta:\n" + response.getMessage());
								}
							});
						}

					});
					
					

				} catch (Exception e2) {
					// TODO: handle exception

					MessageDialog.openError(shlBoletoapi, "Ero", e2.toString());
					return;
				}
			}
		});
		btnSolicitarImpressao.setBounds(10, 95, 120, 25);
		btnSolicitarImpressao.setText("Solicitar Impressao");

		Button btnConsultarImpressao = new Button(grpImpressao, SWT.NONE);
		btnConsultarImpressao.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				try {

					txtMensagem.setText("");
					txtRespostaApi.setText("");
					txtErro.setText("");
					
					String protocolo = txtProtocoloimpressao.getText();
					System.out.println(protocolo);

					
					InterfaceAPI interfaceBoleto = Configuracao.createService(InterfaceAPI.class);
					
					
					Call<JsonObject> call = interfaceBoleto.ConsultarImpressao(protocolo);
					
					call.enqueue(new Callback<JsonObject>() {

						@Override
						public void onResponse(Call<JsonObject> arg0, Response<JsonObject> response) {
							// TODO Auto-generated method stub
							Display.getDefault().syncExec(new Runnable() {

								@Override
								public void run() {
									if (response.isSuccessful()) {
										txtStatus.setText(response.body().get("_status").toString());
										txtRespostaApi.setText(response.body().toString());	
									};
									
								}
								
							});
							
						}
						
						@Override
						public void onFailure(Call<JsonObject> arg0, Throwable response) {
							Display.getDefault().syncExec(new Runnable() {
								public void run() {
									txtRespostaApi.setText(txtRespostaApi.getText() + "\nFalha:");
									txtRespostaApi.setText(
									txtRespostaApi.getText() + "\nResposta:\n" + response.getMessage());
								}
							});
							
						}

					});
					
					

					

				} catch (Exception e2) {
					// TODO: handle exception

					MessageDialog.openError(shlBoletoapi, "Ero", e2.toString());
					return;
				}
				
			}
		});
		btnConsultarImpressao.setBounds(10, 142, 120, 25);
		btnConsultarImpressao.setText("Consultar Impressao");

		Label lblProtocolo = new Label(grpImpressao, SWT.NONE);
		lblProtocolo.setBounds(136, 79, 55, 15);
		lblProtocolo.setText("Protocolo");

		txtProtocoloimpressao = new Text(grpImpressao, SWT.BORDER);
		txtProtocoloimpressao.setBounds(136, 97, 76, 21);

		Label lblSituacao = new Label(grpImpressao, SWT.NONE);
		lblSituacao.setBounds(136, 125, 55, 15);
		lblSituacao.setText("Situacao");

		txtSituacaoimpressao = new Text(grpImpressao, SWT.BORDER);
		txtSituacaoimpressao.setBounds(136, 144, 76, 21);

		Group grpRemessa = new Group(shlBoletoapi, SWT.NONE);
		grpRemessa.setText("Remessa");
		grpRemessa.setBounds(248, 10, 472, 133);

		Button btnGerarRemessa = new Button(grpRemessa, SWT.NONE);
		btnGerarRemessa.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				try {

					txtMensagem.setText("");
					txtRespostaApi.setText("");
					txtErro.setText("");
					
					InterfaceAPI interfaceBoleto = Configuracao.createService(InterfaceAPI.class);
					
					List<String> boletos = new ArrayList<String>();
										
					boletos.add(txtIdintegracao.getText());
					
					System.out.println(boletos);
					
					Call<JsonObject> call = interfaceBoleto.GerarRemessa(boletos);
					
					call.enqueue(new Callback<JsonObject>() {

						@Override
						public void onResponse(Call<JsonObject> arg0, Response<JsonObject> response) {
							// TODO Auto-generated method stub
							Display.getDefault().syncExec(new Runnable() {

								@Override
								public void run() {
									if (response.isSuccessful()) {
										txtStatus.setText(response.body().get("_status").toString());
										txtRespostaApi.setText(response.body().toString());	
										
										JsonObject JsonDados = new JsonObject();
										JsonDados = (JsonObject) response.body().get("_dados");
										
										JsonArray jArraySucesso = (JsonArray) JsonDados.get("_sucesso");
										JsonArray jArrayFalha = (JsonArray) JsonDados.get("_falha");
										
										System.out.println(jArrayFalha);

										for (int i = 0; i < jArraySucesso.size(); i++) {
											JsonObject Obj = new JsonObject();
											Obj = (JsonObject) jArraySucesso.get(i);

											txtRemessa.setText(Obj.get("remessa").toString());
										}
										
										
										for (int i = 0; i < jArrayFalha.size(); i++) {
											JsonObject Obj = new JsonObject();
											Obj = (JsonObject) jArrayFalha.get(i);
											
											txtErro.setText(Obj.get("_erro").toString());
										}
									};
									
								}
								
							});
							
						}
						
						@Override
						public void onFailure(Call<JsonObject> arg0, Throwable response) {
							Display.getDefault().syncExec(new Runnable() {
								public void run() {
									txtRespostaApi.setText(txtRespostaApi.getText() + "\nFalha:");
									txtRespostaApi.setText(
									txtRespostaApi.getText() + "\nResposta:\n" + response.getMessage());
								}
							});
							
						}

					});
					
					

					

				} catch (Exception e2) {
					// TODO: handle exception

					MessageDialog.openError(shlBoletoapi, "Ero", e2.toString());
					return;
				}
			}
		});
		btnGerarRemessa.setBounds(10, 23, 89, 25);
		btnGerarRemessa.setText("Gerar Remessa");

		txtRemessa = new Text(grpRemessa, SWT.BORDER | SWT.MULTI);
		txtRemessa.setBounds(105, 23, 357, 100);

		Group grpRetorno = new Group(shlBoletoapi, SWT.NONE);
		grpRetorno.setText("Retorno");
		grpRetorno.setBounds(248, 149, 472, 189);

		Button btnSubirRetorno = new Button(grpRetorno, SWT.NONE);
		btnSubirRetorno.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				try {

					txtMensagem.setText("");
					txtRespostaApi.setText("");
					txtErro.setText("");
					
					String base64 = Base64.getEncoder().encodeToString(txtRetorno.getText().getBytes());
					
					
					Retorno jsonretorno = new Retorno(base64);
					
					InterfaceAPI interfaceBoleto = Configuracao.createService(InterfaceAPI.class);
					
					Call<JsonObject> call = interfaceBoleto.ProcessarRetorno(jsonretorno);
					
					call.enqueue(new Callback<JsonObject>() {

						@Override
						public void onResponse(Call<JsonObject> arg0, Response<JsonObject> response) {
							// TODO Auto-generated method stub
							Display.getDefault().syncExec(new Runnable() {

								@Override
								public void run() {
									if (response.isSuccessful()) {
										txtStatus.setText(response.body().get("_status").toString());
										txtRespostaApi.setText(response.body().toString());	
										
										JsonObject JsonDados = new JsonObject();
										JsonDados = (JsonObject) response.body().get("_dados");
										
										txtProtocolo.setText(JsonDados.get("protocolo").getAsString());
										txtMensagem.setText(response.body().get("_mensagem").getAsString());
									};
									
								}
								
							});
							
						}
						
						@Override
						public void onFailure(Call<JsonObject> arg0, Throwable response) {
							Display.getDefault().syncExec(new Runnable() {
								public void run() {
									txtRespostaApi.setText(txtRespostaApi.getText() + "\nFalha:");
									txtRespostaApi.setText(
									txtRespostaApi.getText() + "\nResposta:\n" + response.getMessage());
								}
							});
							
						}

					});
					
					

					

				} catch (Exception e2) {
					// TODO: handle exception

					MessageDialog.openError(shlBoletoapi, "Ero", e2.toString());
					return;
				}
				
			}
		});
		btnSubirRetorno.setBounds(10, 69, 89, 25);
		btnSubirRetorno.setText("Subir Retorno");

		txtRetorno = new Text(grpRetorno, SWT.BORDER | SWT.MULTI);
		txtRetorno.setBounds(105, 29, 357, 150);

		Label lblProtocolo_1 = new Label(grpRetorno, SWT.NONE);
		lblProtocolo_1.setBounds(10, 100, 55, 15);
		lblProtocolo_1.setText("Protocolo");

		txtProtocolo = new Text(grpRetorno, SWT.BORDER);
		txtProtocolo.setBounds(10, 122, 89, 21);

		Button btnConsultarRetorno = new Button(grpRetorno, SWT.NONE);
		btnConsultarRetorno.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				try {

					txtMensagem.setText("");
					txtRespostaApi.setText("");
					txtErro.setText("");
					
					String protocolo = txtProtocolo.getText();
					
					InterfaceAPI interfaceBoleto = Configuracao.createService(InterfaceAPI.class);

					Call<JsonObject> call = interfaceBoleto.ConsultarProcessamentoRetorno(protocolo);
					
					call.enqueue(new Callback<JsonObject>() {

						@Override
						public void onResponse(Call<JsonObject> arg0, Response<JsonObject> response) {
							// TODO Auto-generated method stub
							Display.getDefault().syncExec(new Runnable() {

								@Override
								public void run() {
									if (response.isSuccessful()) {
										txtStatus.setText(response.body().get("_status").getAsString());
										txtRespostaApi.setText(response.body().toString());	
									};
									
								}
								
							});
							
						}
						
						@Override
						public void onFailure(Call<JsonObject> arg0, Throwable response) {
							Display.getDefault().syncExec(new Runnable() {
								public void run() {
									txtRespostaApi.setText(txtRespostaApi.getText() + "\nFalha:");
									txtRespostaApi.setText(
									txtRespostaApi.getText() + "\nResposta:\n" + response.getMessage());
								}
							});
							
						}

					});
					
				} catch (Exception e2) {
					// TODO: handle exception

					MessageDialog.openError(shlBoletoapi, "Ero", e2.toString());
					return;
				}
			}
		});
		btnConsultarRetorno.setBounds(10, 154, 89, 25);
		btnConsultarRetorno.setText("Consultar");

		Group grpRespostaApi = new Group(shlBoletoapi, SWT.NONE);
		grpRespostaApi.setText("Resposta API");
		grpRespostaApi.setBounds(248, 344, 472, 239);

		txtRespostaApi = new Text(grpRespostaApi, SWT.BORDER | SWT.MULTI);
		txtRespostaApi.setText("Resposta API");
		txtRespostaApi.setBounds(264, 22, 198, 207);

		txtStatus = new Text(grpRespostaApi, SWT.BORDER);
		txtStatus.setBounds(10, 43, 76, 21);

		txtSituacao = new Text(grpRespostaApi, SWT.BORDER);
		txtSituacao.setBounds(10, 90, 76, 21);

		Label lblStatus = new Label(grpRespostaApi, SWT.NONE);
		lblStatus.setBounds(11, 22, 55, 15);
		lblStatus.setText("Status");

		Label lblSituacao_1 = new Label(grpRespostaApi, SWT.NONE);
		lblSituacao_1.setBounds(10, 69, 55, 15);
		lblSituacao_1.setText("Situacao");

		Label lblErro = new Label(grpRespostaApi, SWT.NONE);
		lblErro.setBounds(10, 164, 55, 15);
		lblErro.setText("Erro");

		txtErro = new Text(grpRespostaApi, SWT.BORDER);
		txtErro.setBounds(10, 185, 186, 21);

		Label lblMensagem = new Label(grpRespostaApi, SWT.NONE);
		lblMensagem.setBounds(10, 114, 76, 15);
		lblMensagem.setText("Mensagem");

		txtMensagem = new Text(grpRespostaApi, SWT.BORDER);
		txtMensagem.setBounds(10, 135, 186, 21);

	}
}
