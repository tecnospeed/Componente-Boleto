package models;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SolicitarPDF {
	@SerializedName("tipoImpressao")
	@Expose
	private String tipoImpressao;
	@SerializedName("boletos")
	@Expose
	private List<String> boletos = null;

	/**
	* No args constructor for use in serialization
	* 
	*/
	public SolicitarPDF() {
	}

	/**
	* 
	* @param boletos
	* @param tipoImpressao
	*/
	public SolicitarPDF(String tipoImpressao, List<String> boletos) {
	super();
	this.tipoImpressao = tipoImpressao;
	this.boletos = boletos;
	}

	public String getTipoImpressao() {
	return tipoImpressao;
	}

	public void setTipoImpressao(String tipoImpressao) {
	this.tipoImpressao = tipoImpressao;
	}

	public List<String> getBoletos() {
	return boletos;
	}

	public void setBoletos(List<String> boletos) {
	this.boletos = boletos;
	}
}
