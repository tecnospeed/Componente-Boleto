package models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Retorno {
	@SerializedName("arquivo")
	@Expose
	private String arquivo;

	/**
	* No args constructor for use in serialization
	* 
	*/
	public Retorno() {
	}

	/**
	* 
	* @param boletos
	* @param tipoImpressao
	*/
	public Retorno(String arquivo) {
	super();
	this.arquivo = arquivo;
	}

	public String getTipoImpressao() {
	return arquivo;
	}

	public void setTipoImpressao(String tipoImpressao) {
	this.arquivo = tipoImpressao;
	}
}
