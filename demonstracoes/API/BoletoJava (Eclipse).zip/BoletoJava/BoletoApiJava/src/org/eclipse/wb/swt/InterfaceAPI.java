package org.eclipse.wb.swt;

import java.nio.Buffer;
import java.util.List;

import javax.xml.ws.Response;

import com.google.gson.JsonObject;

import models.IncluirBoleto;
import models.Retorno;
import models.SolicitarPDF;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;



public interface InterfaceAPI {
	
	@POST("boletos/lote")
	Call<JsonObject> Incluir(@Body List<IncluirBoleto> body);
	
	@GET("boletos")
	Call<JsonObject> Consultar(@Query("idintegracao") String idintegracao);
	
	@POST("boletos/impressao/lote")
	Call<JsonObject> SolicitarImpressao(@Body SolicitarPDF jsonPdf);
	
	@GET("boletos/impressao/lote/{protocolo}")
	Call<ResponseBody> ConsultarImpressao(@Path("protocolo") String protocolo);
	
	@POST("remessas/lote")
	Call<JsonObject> GerarRemessa(@Body List<String> boletos);
	
	@POST("retornos")
	Call<JsonObject> ProcessarRetorno(@Body Retorno jsonretorno);
	
	@GET("retornos/{protocolo}")
	Call<JsonObject> ConsultarProcessamentoRetorno(@Path("protocolo") String protocolo);
}
