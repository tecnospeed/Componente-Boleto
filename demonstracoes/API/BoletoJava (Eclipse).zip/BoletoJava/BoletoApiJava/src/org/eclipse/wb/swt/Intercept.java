package org.eclipse.wb.swt;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

public class Intercept implements Interceptor {

	@Override
	public Response intercept(Chain chain) throws IOException {

		Request.Builder builder = chain.request().newBuilder();
		builder.addHeader("cnpj-sh", "01001001000113");
		builder.addHeader("token-sh", "f22b97c0c9a3d41ac0a3875aba69e5aa");
		builder.addHeader("cnpj-cedente", "73572946000104");
		builder.addHeader("Content-Type", "application/json");
		
		return chain.proceed(builder.build());
	}
	
}
