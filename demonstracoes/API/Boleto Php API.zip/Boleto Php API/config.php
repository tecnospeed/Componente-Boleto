<?php
$url = "http://localhost/PhpApi/"; //caminho da URL
$DirArq = 'Portable-Files/'; //caminho da pasta principal

error_reporting(E_ERROR | E_PARSE); //Remove os notices do php
