require 'net/http'
require 'uri'
require 'json'

########## Autenticação ##########
def autenticaSH
uri = URI.parse("https://pix.tecnospeed.com.br/oauth2/token")

header = {
  'Authorization' => 'Basic Y29udGF0by5zcGVlZGxhYkB0ZWNub3NwZWVkLmNvbS5icjpmMjVkMTYzZTQwOWI4YWI0', #Informar aqui o conjunto de credenciais E-MAIL + SENHA em base 64
  'Content-Type' => 'application/x-www-form-urlencoded'
}

http = Net::HTTP.new(uri.host, uri.port)
http.use_ssl = true

request = Net::HTTP::Post.new(uri.request_uri, header)
request.body = "grant_type=client_credentials&role=software_house"

response = http.request(request)

access_token = JSON.parse(response.body)['access_token']

end 

def autenticaCompany
  uri = URI.parse("https://pix.tecnospeed.com.br/oauth2/token")

  header = {
    'Authorization' => 'Basic ZzIyODcxdW5pbGN1Y2Y5NDB1YmMydG9vYzo4anNscGI0aTBvdnFhdjE4bmlwOWtnaWdzbTczN2c3djB1Z2lxc3BpYnFicG1xZzY1OTE=',  #Informar aqui o conjunto de credenciais clientID + Secret em base 64
    'Content-Type' => 'application/x-www-form-urlencoded'
  }

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Post.new(uri.request_uri, header)
  request.body = "grant_type=client_credentials&role=company"

  response = http.request(request)

  access_token = JSON.parse(response.body)['access_token']

  return access_token

end

########## Company ##########

def criaCompany
  access_token = autenticaSH

  uri = URI('https://pix.tecnospeed.com.br/api/v1/companies')

  puts "Por favor, insira os dados no formato JSON:"
  ARGV.clear
  json_data = gets.chomp

  begin
    data = JSON.parse(json_data)
  rescue JSON::ParserError => e
    puts "Erro ao analisar o JSON: #{e.message}"
    return
  end

  header = {
    'Authorization' => "Bearer #{access_token}",
    'Content-Type' => 'application/json'
  }

  puts "Json da requisição: #{data}"

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Post.new(uri.request_uri, header)
  request.body = data.to_json

  response = http.request(request)

  puts "Response #{response.code} #{response.message}: #{response.body}"
end 


def listaCompany

  access_token = autenticaSH

  uri = URI.parse("https://pix.tecnospeed.com.br/api/v1/companies")

  header = {
    'Authorization' => "Bearer #{access_token}",
    'Content-Type' => 'application/json'
  }

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Get.new(uri.request_uri, header)

  response = http.request(request)

  puts "Resposta da requisição:", response.body
end 
  

def updateCompany

  access_token = autenticaSH

  puts "Por favor, informe o companyID:"
  ARGV.clear
  companyId = gets.chomp

  uri = URI.parse("https://pix.tecnospeed.com.br/api/v1/companies/#{companyId}")
  
  puts "Por favor, insira os dados no formato JSON:"
  ARGV.clear
  json_data = gets.chomp

  begin
    data = JSON.parse(json_data)
  rescue JSON::ParserError => e
    puts "Erro ao analisar o JSON: #{e.message}"
    return
  end

  header = {
    'Authorization' => "Bearer #{access_token}",
    'Content-Type' => 'application/json'
  }

  puts "Json da requisição: #{data}"

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Post.new(uri.request_uri, header)
  request.body = data.to_json

  response = http.request(request)

  puts "Response #{response.code} #{response.message}: #{response.body}"
end 


def disableCompany

  access_token = autenticaSH
  
  puts "Por favor, informe o companyID:"
  ARGV.clear
  companyId = gets.chomp
  
  uri = URI.parse("https://pix.tecnospeed.com.br/api/v1/companies/#{companyId}")

  header = {
    'Authorization' => "Bearer #{access_token}",
    'Content-Type' => 'application/json'
  }

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Delete.new(uri.request_uri, header)

  response = http.request(request)

  puts "Resposta da requisição:", response.body
end 


def newCredentials

  puts "Por favor, informe o companyID:"
  ARGV.clear
  companyId = gets.chomp

  access_token = autenticaSH

  uri = URI.parse("https://pix.tecnospeed.com.br/api/v1/companies/#{companyId}/credentials")

  header = {
    'Authorization' => "Bearer #{access_token}",
    'Content-Type' => 'application/json'
  }
  
  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Post.new(uri.request_uri, header)

  response = http.request(request)

  puts "Resposta da requisição:", response.body
end 

########## Account ##########


def creatAccount
  
  access_token = autenticaCompany

  uri = URI.parse("https://pix.tecnospeed.com.br/api/v1/accounts")

  puts "Por favor, insira os dados no formato JSON:"
  ARGV.clear
  json_data = gets.chomp

  begin
    data = JSON.parse(json_data)
  rescue JSON::ParserError => e
    puts "Erro ao analisar o JSON: #{e.message}"
    return
  end

  header = {
    'Authorization' => "Bearer #{access_token}",
    'Content-Type' => 'application/json'
  }

  puts "Json da requisição: #{data}"

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Post.new(uri.request_uri, header)
  request.body = data.to_json

  response = http.request(request)

  puts "Response #{response.code} #{response.message}: #{response.body}"
end 


def listAccount
  access_token = autenticaCompany


  uri = URI.parse("https://pix.tecnospeed.com.br/api/v1/accounts")

  header = {
    'Authorization' => "Bearer #{access_token}",
    'Content-Type' => 'application/json'
  }

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Get.new(uri.request_uri, header)

  response = http.request(request)

  puts "Resposta da requisição:", response.body
end 


def updateAccount
  access_token = autenticaCompany

  puts "Por favor, informe o accountID:"
  ARGV.clear
  accountID = gets.chomp

  uri = URI.parse("https://pix.tecnospeed.com.br/api/v1/accounts/#{accountID}")

  puts "Por favor, insira os dados no formato JSON:"
  ARGV.clear
  json_data = gets.chomp

  begin
    data = JSON.parse(json_data)
  rescue JSON::ParserError => e
    puts "Erro ao analisar o JSON: #{e.message}"
    return
  end

  header = {
    'Authorization' => "Bearer #{access_token}",
    'Content-Type' => 'application/json'
  }

  puts "Json da requisição: #{data}"

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Post.new(uri.request_uri, header)
  request.body = data.to_json

  response = http.request(request)

  puts "Response #{response.code} #{response.message}: #{response.body}"
end 


def inactiveAccount
  access_token = autenticaCompany

  puts "Por favor, informe o accountID:"
  ARGV.clear
  accountID = gets.chomp

  uri = URI.parse("https://pix.tecnospeed.com.br/api/v1/accounts/#{accountID}")

  header = {
    'Authorization' => "Bearer #{access_token}",
    'Content-Type' => 'application/json'
  }

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Delete.new(uri.request_uri, header)

  response = http.request(request)

  puts "Resposta da requisição:", response.body
end 


########## Certificate ##########

def uploadCertificate
  access_token = autenticaCompany

  ARGV.clear
  puts "Insira o caminho para o arquivo:"
  ARGV.clear
  file_path = STDIN.gets.chomp

  puts "Insira a descrição:"
  ARGV.clear
  description = STDIN.gets.chomp

  puts "Insira a senha:"
  ARGV.clear
  password = STDIN.gets.chomp

  puts "Insira a extensão:"
  ARGV.clear
  extension = STDIN.gets.chomp

  puts "Insira o accountID:"
  ARGV.clear
  account_id = STDIN.gets.chomp

  uri = URI.parse("https://pix.tecnospeed.com.br/api/v1/certificate/upload")

  header = {
    'Authorization' => "Bearer #{access_token}",
    'Content-Type' => 'application/json'
  }

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Post.new(uri.request_uri, header)
  form_data = [
    ['description', description],
    ['password', password],
    ['extension', extension],
    ['accountId', account_id],
    ['file', File.open(file_path)]
  ]

  request.set_form form_data, 'multipart/form-data'

  response = http.request(request)

  puts "Resposta da requisição:", response.body
end


def listCertificate
  access_token = autenticaCompany

  uri = URI.parse("https://pix.tecnospeed.com.br/api/v1/certificate/")

  header = {
    'Authorization' => "Bearer #{access_token}",
    'Content-Type' => 'application/json'
  }

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Get.new(uri.request_uri, header)

  response = http.request(request)

  puts "Resposta da requisição:", response.body
end 


def uploadCertificate
  access_token = autenticaCompany

  ARGV.clear
  puts "Insira o caminho para o arquivo:"
  ARGV.clear
  file_path = STDIN.gets.chomp

  puts "Insira a descrição:"
  ARGV.clear
  description = STDIN.gets.chomp

  puts "Insira a senha:"
  ARGV.clear
  password = STDIN.gets.chomp

  puts "Insira a extensão:"
  ARGV.clear
  extension = STDIN.gets.chomp

  puts "Insira o accountID:"
  ARGV.clear
  account_id = STDIN.gets.chomp

  uri = URI.parse("https://pix.tecnospeed.com.br/api/v1/certificate/upload")

  header = {
    'Authorization' => "Bearer #{access_token}",
    'Content-Type' => 'application/json'
  }

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Patch.new(uri.request_uri, header)
  form_data = [
    ['description', description],
    ['password', password],
    ['extension', extension],
    ['accountId', account_id],
    ['file', File.open(file_path)]
  ]

  request.set_form form_data, 'multipart/form-data'

  response = http.request(request)

  puts "Resposta da requisição:", response.body
end 


def deleteCertificate
  access_token = autenticaCompany
    ARGV.clear
    puts "Insira o caminho para o arquivo:"
    ARGV.clear
    file_path = STDIN.gets.chomp
  
    puts "Insira a descrição:"
    ARGV.clear
    description = STDIN.gets.chomp
  
    puts "Insira a senha:"
    ARGV.clear
    password = STDIN.gets.chomp
  
    puts "Insira a extensão:"
    ARGV.clear
    extension = STDIN.gets.chomp
  
    puts "Insira o accountID:"
    ARGV.clear
    accountID = STDIN.gets.chomp
  
    uri = URI.parse("https://pix.tecnospeed.com.br/api/v1/certificate/upload")
  
    header = {
      'Authorization' => "Bearer #{access_token}",
      'Content-Type' => 'application/json'
    }
  
    http = Net::HTTP.new(uri.host, uri.port)
    http.use_ssl = true
  
    request = Net::HTTP::Post.new(uri.request_uri, header)
    form_data = [
      ['description', description],
      ['password', password],
      ['extension', extension],
      ['accountId', account_id],
      ['file', File.open(file_path)]
    ]
  
    request.set_form form_data, 'multipart/form-data'
  
    response = http.request(request)
  
    puts "Resposta da requisição:", response.body

  uri = URI.parse("https://pix.tecnospeed.com.br/api/v1/certificate/#{accountID}")

  header = {
    'Authorization' => "Bearer #{access_token}",
    'Content-Type' => 'application/json'
  }

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Delete.new(uri.request_uri, header)

  response = http.request(request)

  puts "Resposta da requisição:", response.body
end 


########## User ##########

def creatUser
  access_token = autenticaCompany

  uri = URI.parse("https://pix.tecnospeed.com.br/api/v1/users")

  puts "Por favor, insira os dados no formato JSON:"
  ARGV.clear
  json_data = gets.chomp

  begin
    data = JSON.parse(json_data)
  rescue JSON::ParserError => e
    puts "Erro ao analisar o JSON: #{e.message}"
    return
  end

  header = {
    'Authorization' => "Bearer #{access_token}",
    'Content-Type' => 'application/json'
  }

  puts "Json da requisição: #{data}"

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Post.new(uri.request_uri, header)
  request.body = data.to_json

  response = http.request(request)

  puts "Response #{response.code} #{response.message}: #{response.body}"
end 


def listUsers
  access_token = autenticaCompany

  uri = URI.parse("https://pix.tecnospeed.com.br/api/v1/users")

  header = {
    'Authorization' => "Bearer #{access_token}",
    'Content-Type' => 'application/json'
  }

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Get.new(uri.request_uri, header)

  response = http.request(request)

  puts "Resposta da requisição:", response.body
end 


def updateUsers
  access_token = autenticaCompany

  puts "Por favor, informe o userID:"
  ARGV.clear
  userID = gets.chomp

  uri = URI.parse("https://pix.tecnospeed.com.br/api/v1/users/#{userID}")

  puts "Por favor, insira os dados no formato JSON:"
  ARGV.clear
  json_data = gets.chomp

  begin
    data = JSON.parse(json_data)
  rescue JSON::ParserError => e
    puts "Erro ao analisar o JSON: #{e.message}"
    return
  end

  header = {
    'Authorization' => "Bearer #{access_token}",
    'Content-Type' => 'application/json'
  }

  puts "Json da requisição: #{data}"

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Post.new(uri.request_uri, header)
  request.body = data.to_json

  response = http.request(request)

  puts "Response #{response.code} #{response.message}: #{response.body}"
end 


def disableUsers
  access_token = autenticaCompany

  uri = URI.parse("https://pix.tecnospeed.com.br/api/v1/users/#{userID}")

 header = {
    'Authorization' => "Bearer #{access_token}",
    'Content-Type' => 'application/json'
  }

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Delete.new(uri.request_uri, header)

  response = http.request(request)

  puts "Resposta da requisição:", response.body
end 

########## WebHook ##########

def creatWebhook
  access_token = autenticaCompany

  uri = URI.parse("https://pix.tecnospeed.com.br/api/v1/webhook")
  
  puts "Por favor, insira os dados no formato JSON:"
  ARGV.clear
  json_data = gets.chomp

  begin
    data = JSON.parse(json_data)
  rescue JSON::ParserError => e
    puts "Erro ao analisar o JSON: #{e.message}"
    return
  end

  header = {
    'Authorization' => "Bearer #{access_token}",
    'Content-Type' => 'application/json'
  }

  puts "Json da requisição: #{data}"

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Post.new(uri.request_uri, header)
  request.body = data.to_json

  response = http.request(request)

  puts "Response #{response.code} #{response.message}: #{response.body}"
end 


def listWebhook
  access_token = autenticaCompany

  uri = URI.parse("https://pix.tecnospeed.com.br/api/v1/webhook")

  header = {
    'Authorization' => "Bearer #{access_token}",
    'Content-Type' => 'application/json'
  }

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Get.new(uri.request_uri, header)

  response = http.request(request)

  puts "Resposta da requisição:", response.body
end 


def updateWebhook
  access_token = autenticaCompany

  uri = URI.parse("https://pix.tecnospeed.com.br/api/v1/webhook")

  puts "Por favor, insira os dados no formato JSON:"
  ARGV.clear
  json_data = gets.chomp

  begin
    data = JSON.parse(json_data)
  rescue JSON::ParserError => e
    puts "Erro ao analisar o JSON: #{e.message}"
    return
  end

  header = {
    'Authorization' => "Bearer #{access_token}",
    'Content-Type' => 'application/json'
  }

  puts "Json da requisição: #{data}"

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Post.new(uri.request_uri, header)
  request.body = data.to_json

  response = http.request(request)

  puts "Response #{response.code} #{response.message}: #{response.body}"
end 


def disableWebhook
  access_token = autenticaCompany

  uri = URI.parse("https://pix.tecnospeed.com.br/api/v1/webhook")

  header = {
    'Authorization' => "Bearer #{access_token}",
    'Content-Type' => 'application/json'
  }

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Delete.new(uri.request_uri, header)

  response = http.request(request)

  puts "Resposta da requisição:", response.body
end 

########## Refund ##########

def refund
  access_token = autenticaCompany

  puts "Por favor, informe o idPix:"
  ARGV.clear
  idPix = gets.chomp

  uri = URI.parse("https://pix.tecnospeed.com.br/api/v1/pix/refund/#{idPix}")
  
  puts "Por favor, insira os dados no formato JSON:"
  ARGV.clear
  json_data = gets.chomp

  begin
    data = JSON.parse(json_data)
  rescue JSON::ParserError => e
    puts "Erro ao analisar o JSON: #{e.message}"
    return
  end

  header = {
    'Authorization' => "Bearer #{access_token}",
    'Content-Type' => 'application/json'
  }

  puts "Json da requisição: #{data}"

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Post.new(uri.request_uri, header)
  request.body = data.to_json

  response = http.request(request)

  puts "Response #{response.code} #{response.message}: #{response.body}"
end 

########## PIX ##########


def createPix
  access_token = autenticaCompany

  uri = URI.parse("https://pix.tecnospeed.com.br/sandbox/v1/pix/dynamic")
  
  puts "Por favor, insira os dados no formato JSON:"
  ARGV.clear
  json_data = gets.chomp

  begin
    data = JSON.parse(json_data)
  rescue JSON::ParserError => e
    puts "Erro ao analisar o JSON: #{e.message}"
    return
  end

  header = {
    'Authorization' => "Bearer #{access_token}",
    'Content-Type' => 'application/json'
  }

  puts "Json da requisição: #{data}"

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Post.new(uri.request_uri, header)
  request.body = data.to_json

  response = http.request(request)

  puts "Response #{response.code} #{response.message}: #{response.body}"
end 


def listPix
  access_token = autenticaCompany

  puts "Por favor, informe o pixID:"
  ARGV.clear
  pixID = gets.chomp

  uri = URI.parse("https://pix.tecnospeed.com.br/api/v1/pix/#{pixID}")

  header = {
    'Authorization' => "Bearer #{access_token}",
    'Content-Type' => 'application/json'
  }

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Get.new(uri.request_uri, header)

  response = http.request(request)

  puts "Resposta da requisição:", response.body
end 


def queryPix
  access_token = autenticaCompany

  uri = URI.parse("https://pix.tecnospeed.com.br/api/v1/pix/query")

  header = {
    'Authorization' => "Bearer #{access_token}",
    'Content-Type' => 'application/json'
  }

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Get.new(uri.request_uri, header)

  response = http.request(request)

  puts "Resposta da requisição:", response.body
end 


########## PIX Cobrança ##########


def createPix
  access_token = autenticaCompany

  uri = URI.parse("https://pix.tecnospeed.com.br/api/v1/pix/charge")
  
  puts "Por favor, insira os dados no formato JSON:"
  ARGV.clear
  json_data = gets.chomp

  begin
    data = JSON.parse(json_data)
  rescue JSON::ParserError => e
    puts "Erro ao analisar o JSON: #{e.message}"
    return
  end

  header = {
    'Authorization' => "Bearer #{access_token}",
    'Content-Type' => 'application/json'
  }

  puts "Json da requisição: #{data}"

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Post.new(uri.request_uri, header)
  request.body = data.to_json

  response = http.request(request)

  puts "Response #{response.code} #{response.message}: #{response.body}"
end 


def listPix
  access_token = autenticaCompany

  puts "Por favor, informe o pixID:"
  ARGV.clear
  pixID = gets.chomp

  uri = URI.parse("https://pix.tecnospeed.com.br/api/v1/pix/charge/#{pixID}")

  header = {
    'Authorization' => "Bearer #{access_token}",
    'Content-Type' => 'application/json'
  }

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Get.new(uri.request_uri, header)

  response = http.request(request)

  puts "Resposta da requisição:", response.body
end 


def queryPix
  access_token = autenticaCompany

  uri = URI.parse("https://pix.tecnospeed.com.br/api/v1/pix/charge/query")

  header = {
    'Authorization' => "Bearer #{access_token}",
    'Content-Type' => 'application/json'
  }

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Get.new(uri.request_uri, header)

  response = http.request(request)

  puts "Resposta da requisição:", response.body
end 



########## Bilhetagem ##########


def report
  access_token = autenticaCompany

uri = URI.parse("https://pix.tecnospeed.com.br/api/v1/pix/report")

header = {
  'Authorization' => "Bearer #{access_token}",
  'Content-Type' => 'application/json'
}

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Get.new(uri.request_uri, header)

  response = http.request(request)

  puts "Resposta da requisição:", response.body
end 


########## QrCode ########## 


def qrCode
  access_token = autenticaCompany

  puts "Por favor, informe o pixID:"
  ARGV.clear
  pixID = gets.chomp

  uri = URI.parse("https://pix.tecnospeed.com.br/api/v1/qr/#{idPix}")

  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  request = Net::HTTP::Get.new(uri.request_uri)

  response = http.request(request)

  puts "Resposta da requisição (base64):", response.body
end 





if ARGV.length > 0
  command = ARGV[0]
  case command
  when 'autenticaSH'
    autenticaSH
  when 'autenticaCompany'
    autenticaCompany
  when 'criaCompany'
    criaCompany
  when 'listaCompany'
    listaCompany
  when 'updateCompany'
    updateCompany
  when 'disableCompany'
     disableCompany 
  when 'newCredentials'
     newCredentials 
  when 'creatAccount'
     creatAccount 
  when 'listAccount'
     listAccount 
  when 'updateAccount'
     updateAccount 
  when 'inactiveAccount'
     inactiveAccount 
  when 'creatUser'
     creatUser 
  when 'listUsers'
     listUsers 
  when 'updateUsers'
     updateUsers 
  when 'disableUsers'
     disableUsers 
  when 'creatWebhook'
     creatWebhook 
  when 'listWebhook'
     listWebhook 
  when 'updateWebhook'
     updateWebhook 
  when 'disableWebhook'
     disableWebhook 
  when 'refund'
     refund 
  when 'createPix'
     createPix 
  when 'listPix'
     listPix 
  when 'queryPix'
     queryPix 
  when 'createPixCharge'
     createPixCharge 
  when 'listPixCharge'
     listPixCharge 
  when 'queryPixCharge'
     queryPixCharge 
  when 'report'
     report 
  when 'qrCode'
     qrCode 
  when 'uploadCertificate'
     uploadCertificate 
  when 'listCertificate'
     listCertificate 
  when 'updateCertificate'
     updateCertificate 
  when 'deleteCertificate'
     deleteCertificate
  else
    puts "Comando desconhecido: #{command}"
  end
else
  puts "Por favor, forneça um comando: autenticaSH ou autenticaCompany"
end

