﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using RestSharp;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Runtime.Serialization.Json;
using System.Web.Script.Serialization;
// instalado dependecia RestSharp, Json, Serialization; 

namespace Boleto
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        public void btnCadastrarCedente_Clique(object sender, EventArgs ea)
        {
            string cnpjSH = tBoxCNPJSoftwareHouse.Text;
            string tokenSH = tBoxTokenSoftwareHouse.Text;
            string cnpjCedente = tBoxCNPJCedente.Text;
            string url = URLApi.Text; ;
            //Criando o json com os campos do Json:
            var objCamposCedente = new
            {
                CedenteRazaoSocial = "Empresa Ltda",
                CedenteNomeFantasia = "Empresa",
                CedenteCPFCNPJ = "20841251000106",
                CedenteEnderecoLogradouro = "Av. Analista Jucá de Souza",
                CedenteEnderecoNumero = "123",
                CedenteEnderecoComplemento = "sala 987",
                CedenteEnderecoBairro = "Centro",
                CedenteEnderecoCEP = "87012345",
                CedenteEnderecoCidadeIBGE = "4115200",
                CedenteTelefone = "(44) 3033-1234",
                CedenteEmail = "cobranca@boleto.com.br"
            };
            JavaScriptSerializer js = new JavaScriptSerializer();
            string strJsonCedente = js.Serialize(objCamposCedente);

            //Inicia a configuração da requisicao:
            var client = new RestClient(url + "/api/v1/cedentes");
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("token-sh", tokenSH);
            request.AddHeader("cnpj-sh", cnpjSH);
            request.AddParameter("application/json", strJsonCedente, ParameterType.RequestBody);

            dynamic json = JObject.Parse(client.Execute(request).Content);
            rtRetorno.Text = JsonConvert.SerializeObject(json, Formatting.Indented);

        }
        public void btnCadastrarConta_Clique(object sender, EventArgs ea)
        {
            string cnpjSH = tBoxCNPJSoftwareHouse.Text;
            string tokenSH = tBoxTokenSoftwareHouse.Text;
            string cnpjCedente = tBoxCNPJCedente.Text;
            string url = URLApi.Text; ;
            //Criando o json com os campos do Json:
            var objCamposBoleto = new
            {
                ContaCodigoBanco = "341",
                ContaAgencia = "4233",
                ContaAgenciaDV = "",
                ContaNumero = "54321",
                ContaNumeroDV = "0",
                ContaTipo = "CORRENTE",
                ContaCodigoBeneficiario = "54321"
            };
            JavaScriptSerializer js = new JavaScriptSerializer();
            string strJsonCedente = js.Serialize(objCamposBoleto);

            //Inicia a configuração da requisicao:
            var client = new RestClient(url + "/api/v1/cedentes/contas");
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("token-sh", tokenSH);
            request.AddHeader("cnpj-sh", cnpjSH);
            request.AddHeader("cnpj-cedente", cnpjCedente);
            request.AddParameter("application/json", strJsonCedente, ParameterType.RequestBody);

            dynamic json = JObject.Parse(client.Execute(request).Content);
            rtRetorno.Text = JsonConvert.SerializeObject(json, Formatting.Indented);

        }
        public void btnCadastrarConvenio_Clique(object sender, EventArgs ea)
        {
            string cnpjSH = tBoxCNPJSoftwareHouse.Text;
            string tokenSH = tBoxTokenSoftwareHouse.Text;
            string cnpjCedente = tBoxCNPJCedente.Text;
            string url = URLApi.Text; ;

            var objCamposConvenio = new
            {
                ConvenioNumero = "321",
                ConvenioDescricao = "Carteira de exemplo",
                ConvenioCarteira = "109",
                ConvenioEspecie = "Boleto",
                ConvenioPadraoCNAB = "240",
                ConvenioAtualizaVan = "0",
                Conta = "954"
            };
            JavaScriptSerializer js = new JavaScriptSerializer();
            string strJsonCedente = js.Serialize(objCamposConvenio);

            //Inicia a configuração da requisicao:
            var client = new RestClient(url + "/api/v1/cedentes/contas/convenios");
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("token-sh", tokenSH);
            request.AddHeader("cnpj-sh", cnpjSH);
            request.AddHeader("cnpj-cedente", cnpjCedente);
            request.AddParameter("application/json", strJsonCedente, ParameterType.RequestBody);

            dynamic json = JObject.Parse(client.Execute(request).Content);
            rtRetorno.Text = JsonConvert.SerializeObject(json, Formatting.Indented);

        }
        public void btnConsultar_Clique(object sender, EventArgs ea)

        {
            //Método que recebe um  idIntegracao (ou uma lista) e dispara uma consulta em nossa API para saber o resultado do processamento deste boleto.
            //O retorno desta requisição é um json que trará os campos do boleto em caso de sucesso, ou a mensagem de erro/validação em caso de falha.

            string cnpjSH = tBoxCNPJSoftwareHouse.Text;
            string tokenSH = tBoxTokenSoftwareHouse.Text;
            string cnpjCedente = tBoxCNPJCedente.Text;
            string url = URLApi.Text; ;

            if (tBoxCNPJSoftwareHouse.Text == "" | tBoxTokenSoftwareHouse.Text == "" | tBoxCNPJCedente.Text == "")
            {
                rtRetorno.Text = "Dados obrigatórios não preenchidos!";
            }
            

            var client = new RestClient(url + "/api/v1/boletos?" + "idintegracao="+ idintegracao.Text); // + TrocaVirgulaPorE(txtIdIntegracao.Text));
            var request = new RestRequest(Method.GET);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("token-sh", tokenSH);
            request.AddHeader("cnpj-sh", cnpjSH);
            request.AddHeader("cnpj-cedente", cnpjCedente);

            dynamic json = JObject.Parse(client.Execute(request).Content);
            rtRetorno.Text = JsonConvert.SerializeObject(json, Formatting.Indented);
        }
        public void btnIncluir_Clique(object sender, EventArgs ea)
        {
            string cnpjSH = tBoxCNPJSoftwareHouse.Text;
            string tokenSH = tBoxTokenSoftwareHouse.Text;
            string cnpjCedente = tBoxCNPJCedente.Text;
            string url = URLApi.Text; ;
            //Criando o json com os campos do tx2:
            var objCamposBoleto = new object[] { new {CedenteContaNumero = "12345",
                                                      CedenteContaNumeroDV = "6",
                                                      CedenteConvenioNumero = "6543231",
                                                      CedenteContaCodigoBanco = "341",
                                                      SacadoCPFCNPJ = "28436161661",
                                                      SacadoEmail = "email@sacado.com",
                                                      SacadoEnderecoNumero = "987",
                                                      SacadoEnderecoBairro = "Centro",
                                                      SacadoEnderecoCEP = "87098765",
                                                      SacadoEnderecoCidade = "Maringá",
                                                      SacadoEnderecoComplemento = "Fundos",
                                                      SacadoEnderecoLogradouro = "Rua teste, 987",
                                                      SacadoEnderecoPais = "Brasil",
                                                      SacadoEnderecoUF = "PR",
                                                      SacadoNome = "Teste de Souza",
                                                      SacadoTelefone = "4499999999",
                                                      SacadoCelular = "44999999999",
                                                      TituloDataDesconto = "05/01/2020",
                                                      TituloValorDesconto = "0,01",
                                                      TituloDataEmissao = "01/01/2020",
                                                      TituloDataVencimento = "01/01/2020",
                                                      TituloValorJuros = "0,01",
                                                      TituloPrazoProtesto = "30",
                                                      TituloMensagem01 = "Juros de 0,01 ao dia",
                                                      TituloMensagem02 = "Nao receber apos 30 dias de atraso",
                                                      TituloMensagem03 = "Titulo sujeito a protesto apos 30 dias",
                                                      TituloNossoNumero ="1254",
                                                      TituloNumeroDocumento = "01012020",
                                                      TituloValor = "0,02",
                                                      TituloLocalPagamento = "Pagável em qualquer banco até o vencimento." }
                                                      //Demais campos disponíveis em: http://docs.tecnospeed.com.br/boleto/Campos/
                                               };
            JavaScriptSerializer js = new JavaScriptSerializer();
            string strJson = js.Serialize(objCamposBoleto);



            //Inicia a configuração da requisicao:
            var client = new RestClient(url + "/api/v1/boletos/lote");
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("token-sh", tokenSH);
            request.AddHeader("cnpj-sh", cnpjSH);
            request.AddHeader("cnpj-cedente", cnpjCedente);
            request.AddParameter("application/json", strJson, ParameterType.RequestBody);

            dynamic json = JObject.Parse(client.Execute(request).Content);
            rtRetorno.Text = JsonConvert.SerializeObject(json, Formatting.Indented);

        }
        public void btnSolicitarImpressao_Clique(object sender, EventArgs ea)
        {
            string cnpjSH = tBoxCNPJSoftwareHouse.Text;
            string tokenSH = tBoxTokenSoftwareHouse.Text;
            string cnpjCedente = tBoxCNPJCedente.Text;
            string url = URLApi.Text; ;

            string[] idIntegracaoArray;
            idIntegracaoArray = idintegracao.Text.Split(',');


            //Define qual o tipo de impressão a ser usada: 
            string JsonCompletoImpressaoLote = "";

            string FormatoImpressao = "2";    //Carnê triplo
            var jsonImpressaoLote = new
            {
                tipoImpressao = FormatoImpressao,
                boletos = idIntegracaoArray
            };

            JavaScriptSerializer js = new JavaScriptSerializer();
            JsonCompletoImpressaoLote = js.Serialize(jsonImpressaoLote);

            rtRetorno.Text = JsonCompletoImpressaoLote;

            //Inicia a configuração da requisicao:
            var client = new RestClient(url + "/api/v1/boletos/impressao/lote");
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("token-sh", tokenSH);
            request.AddHeader("cnpj-sh", cnpjSH);
            request.AddHeader("cnpj-cedente", cnpjCedente);
            request.AddParameter("application/json", JsonCompletoImpressaoLote, ParameterType.RequestBody);



            dynamic json = JObject.Parse(client.Execute(request).Content);
            rtRetorno.Text = JsonConvert.SerializeObject(json, Formatting.Indented);


        }
        public void btnImprirLote_Clique(object sender, EventArgs ea)
        {
            string cnpjSH = tBoxCNPJSoftwareHouse.Text;
            string tokenSH = tBoxTokenSoftwareHouse.Text;
            string cnpjCedente = tBoxCNPJCedente.Text;
            string url = URLApi.Text; 

            // Método que recebe um o número de protocolo gerado no retorno do pedido de envio da impressão
            //O retorno é o PDF do boleto.

            
            if (tBoxCNPJSoftwareHouse.Text == "" | tBoxTokenSoftwareHouse.Text == "" | tBoxCNPJCedente.Text == "")
            {
                rtRetorno.Text = "Dados obrigatórios não preenchidos!";
            }

            
            var client = new RestClient(url + "/api/v1/boletos/impressao/lote/" + protImpressao.Text);
            var request = new RestRequest(Method.GET);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/pdf");
            request.AddHeader("token-sh", tokenSH);
            request.AddHeader("cnpj-sh", cnpjSH);
            request.AddHeader("cnpj-cedente", cnpjCedente);

            //byte[] response = client.DownloadData(request);
            //File.WriteAllBytes(@"C:\Temp\TesteImpressao.txt", response);   //Salva o conteúdo do PDF
            Byte[] arquivoBuffer = client.DownloadData(request);

            Response.ContentType = "application/pdf";
            Response.AddHeader("content-length", arquivoBuffer.Length.ToString());
            Response.BinaryWrite(arquivoBuffer);
            rtRetorno.Text = "PDF salvo em C:\\Temp\\TesteImpressao.pdf !";

        }
        public void btnSolicitarEmailLote_Clique(object sender, EventArgs ea)
        {
            string cnpjSH = tBoxCNPJSoftwareHouse.Text;
            string tokenSH = tBoxTokenSoftwareHouse.Text;
            string cnpjCedente = tBoxCNPJCedente.Text;
            string url = URLApi.Text;

            var objVet = new
            {
                idIntegracao = idintegracao.Text,
                EmailNomeRemetente = "Empresa Exemplo",
                EmailRemetente = "guilherme.ganassin@tecnospeed.com.br",
                EmailAssunto = "Boleto para pagamento",
                EmailMensagem = "Segue o link do boleto:| ${linkBoleto}|Considere não imprimir este email.",
                EmailDestinatario = "luiz.bengozi@tecnospeed.com.br"
            };

            JavaScriptSerializer js = new JavaScriptSerializer();
            string srtJson = js.Serialize(objVet);

            rtRetorno.Text = srtJson;


            //Inicia a configuração da requisicao:
            var client = new RestClient(url + "/api/v1/email/lote");
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("token-sh", tokenSH);
            request.AddHeader("cnpj-sh", cnpjSH);
            request.AddHeader("cnpj-cedente", cnpjCedente);
            request.AddParameter("application/json", (srtJson), ParameterType.RequestBody);


            dynamic json = JObject.Parse(client.Execute(request).Content);
            rtRetorno.Text = JsonConvert.SerializeObject(json, Formatting.Indented);

        }
        public void btnColsultarEmail_Clique(object sender, EventArgs ea)
        {
            string cnpjSH = tBoxCNPJSoftwareHouse.Text;
            string tokenSH = tBoxTokenSoftwareHouse.Text;
            string cnpjCedente = tBoxCNPJCedente.Text;
            string url = URLApi.Text;

            var client = new RestClient(url + "/api/v1/email/lote/" + protEmail.Text);
            var request = new RestRequest(Method.GET);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/pdf");
            request.AddHeader("token-sh", tokenSH);
            request.AddHeader("cnpj-sh", cnpjSH);
            request.AddHeader("cnpj-cedente", cnpjCedente);

            dynamic json = JObject.Parse(client.Execute(request).Content);
            rtRetorno.Text = JsonConvert.SerializeObject(json, Formatting.Indented);

        }
        public void btnGerarRemessa_Clique(object sender, EventArgs ea)
        {
            string cnpjSH = tBoxCNPJSoftwareHouse.Text;
            string tokenSH = tBoxTokenSoftwareHouse.Text;
            string cnpjCedente = tBoxCNPJCedente.Text;
            string url = URLApi.Text;

            //Cria um array com os idIntegracao (que estão separados por vírgula):
            string[] idIntegracaoArray;
            idIntegracaoArray = idintegracao.Text.Split(',');

            //Transforma o Array no formato esperado de JSON:
            var objVet = idIntegracaoArray;
            JavaScriptSerializer js = new JavaScriptSerializer();
            string strJsonRemessa = js.Serialize(objVet);

            //Inicia a configuração da requisicao:
            var client = new RestClient(url + "/api/v1/remessas/lote");
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("token-sh", tokenSH);
            request.AddHeader("cnpj-sh", cnpjSH);
            request.AddHeader("cnpj-cedente", cnpjCedente);
            request.AddParameter("application/json", strJsonRemessa, ParameterType.RequestBody);

            dynamic json = JObject.Parse(client.Execute(request).Content);
            rtRetorno.Text = JsonConvert.SerializeObject(json, Formatting.Indented);

        }
        public void btnSolicitarAlteracao_Clique(object sender, EventArgs ea)
        {
            string cnpjSH = tBoxCNPJSoftwareHouse.Text;
            string tokenSH = tBoxTokenSoftwareHouse.Text;
            string cnpjCedente = tBoxCNPJCedente.Text;
            string url = URLApi.Text;

            string JsonCompletoAlteracao = "";

                string tipoAlteracao = "0";         //Alteração de vencimento

                var jsonRemessaAlteracao = new
                {
                    tipo = tipoAlteracao,
                    boletos = new object[] { new { idintegracao = idintegracao.Text, TituloDataVencimento = "20/05/2018" } }
                };
                JavaScriptSerializer js = new JavaScriptSerializer();
                JsonCompletoAlteracao = js.Serialize(jsonRemessaAlteracao);

                rtRetorno.Text = JsonCompletoAlteracao;

            //Inicia a configuração da requisicao:
            var client = new RestClient(url + "/api/v1/boletos/altera/lote");
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("token-sh", tokenSH);
            request.AddHeader("cnpj-sh", cnpjSH);
            request.AddHeader("cnpj-cedente", cnpjCedente);
            request.AddParameter("application/json", (JsonCompletoAlteracao), ParameterType.RequestBody);


            dynamic json = JObject.Parse(client.Execute(request).Content);
            rtRetorno.Text = JsonConvert.SerializeObject(json, Formatting.Indented);

        }
        public void btnConsultarAlteracao_Clique(object sender, EventArgs ea)
        {
            string cnpjSH = tBoxCNPJSoftwareHouse.Text;
            string tokenSH = tBoxTokenSoftwareHouse.Text;
            string cnpjCedente = tBoxCNPJCedente.Text;
            string url = URLApi.Text;

            var client = new RestClient(url + "/api/v1/boletos/altera/lote/" + protAlteracao.Text);
            var request = new RestRequest(Method.GET);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/pdf");
            request.AddHeader("token-sh", tokenSH);
            request.AddHeader("cnpj-sh", cnpjSH);
            request.AddHeader("cnpj-cedente", cnpjCedente);

            dynamic json = JObject.Parse(client.Execute(request).Content);
            rtRetorno.Text = JsonConvert.SerializeObject(json, Formatting.Indented);

        }
        public void btnSolicitarBaixa_Clique(object sender, EventArgs ea)
        {
            string cnpjSH = tBoxCNPJSoftwareHouse.Text;
            string tokenSH = tBoxTokenSoftwareHouse.Text;
            string cnpjCedente = tBoxCNPJCedente.Text;
            string url = URLApi.Text;

            //Cria um array com os idIntegracao (que estão separados por vírgula)
            string[] idIntegracaoArray;
            idIntegracaoArray = idintegracao.Text.Split(',');

            //Transforma o Array no formato esperado de JSON:
            var objVet = idIntegracaoArray;
            JavaScriptSerializer js = new JavaScriptSerializer();
            string strJsonBaixa = js.Serialize(objVet);


            //Inicia a configuração da requisicao:
            var client = new RestClient(url + "/api/v1/boletos/baixa/lote");
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("token-sh", tokenSH);
            request.AddHeader("cnpj-sh", cnpjSH);
            request.AddHeader("cnpj-cedente", cnpjCedente);
            request.AddParameter("application/json", (strJsonBaixa), ParameterType.RequestBody);


            dynamic json = JObject.Parse(client.Execute(request).Content);
            rtRetorno.Text = JsonConvert.SerializeObject(json, Formatting.Indented);

        }
        public void btnConsultarBaixa_Clique(object sender, EventArgs ea)
        {
            string cnpjSH = tBoxCNPJSoftwareHouse.Text;
            string tokenSH = tBoxTokenSoftwareHouse.Text;
            string cnpjCedente = tBoxCNPJCedente.Text;
            string url = URLApi.Text;

            var client = new RestClient(url + "/api/v1/boletos/baixa/lote/" + protBaixa.Text);
            var request = new RestRequest(Method.GET);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/pdf");
            request.AddHeader("token-sh", tokenSH);
            request.AddHeader("cnpj-sh", cnpjSH);
            request.AddHeader("cnpj-cedente", cnpjCedente);

            dynamic json = JObject.Parse(client.Execute(request).Content);
            rtRetorno.Text = JsonConvert.SerializeObject(json, Formatting.Indented);

        }
        public void btnUploadRetorno_Clique(object sender, EventArgs ea)
        {
            string cnpjSH = tBoxCNPJSoftwareHouse.Text;
            string tokenSH = tBoxTokenSoftwareHouse.Text;
            string cnpjCedente = tBoxCNPJCedente.Text;
            string url = URLApi.Text;
            string jsonok;

            var RetornoOriginal = System.Text.Encoding.UTF8.GetBytes(rtRetorno.Text);
            var RetornoBase64 = System.Convert.ToBase64String(RetornoOriginal);

            jsonok = "{\"arquivo\":\"" + RetornoBase64 + "\"}";
            //Inicia a configuração da requisicao:
            var client = new RestClient(url + "/api/v1/retornos");
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("token-sh", tokenSH);
            request.AddHeader("cnpj-sh", cnpjSH);
            request.AddHeader("cnpj-cedente", cnpjCedente);
            request.AddParameter("application/x-www-form-urlencoded", jsonok, ParameterType.RequestBody);

            dynamic json = JObject.Parse(client.Execute(request).Content);
            rtRetorno.Text = JsonConvert.SerializeObject(json, Formatting.Indented);

        }
        public void btnConsultarRetorno_Clique(object sender, EventArgs ea)
        {
            string cnpjSH = tBoxCNPJSoftwareHouse.Text;
            string tokenSH = tBoxTokenSoftwareHouse.Text;
            string cnpjCedente = tBoxCNPJCedente.Text;
            string url = URLApi.Text;

            //Inicia a configuração da requisicao:
            var client = new RestClient(url + "/api/v1/retornos/" + protRetorno.Text); //Passe o protocolo obtido no envio do arquivo de retorno diretamente na URL
            var request = new RestRequest(Method.GET);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("token-sh", tokenSH);
            request.AddHeader("cnpj-sh", cnpjSH);
            request.AddHeader("cnpj-cedente", cnpjCedente);

            dynamic json = JObject.Parse(client.Execute(request).Content);
            rtRetorno.Text = JsonConvert.SerializeObject(json, Formatting.Indented);

        }
        public void btnDescartarBoleto_Clique(object sender, EventArgs ea)
        {
            string cnpjSH = tBoxCNPJSoftwareHouse.Text;
            string tokenSH = tBoxTokenSoftwareHouse.Text;
            string cnpjCedente = tBoxCNPJCedente.Text;
            string url = URLApi.Text;

            //Cria um array com os idIntegracao (que estão separados por vírgula)
            string[] idIntegracaoArray;
            idIntegracaoArray = idintegracao.Text.Split(',');


            //Monta o json com o idIntegracao:
            var JsonIDIntegracao = new object[] { idIntegracaoArray };

            JavaScriptSerializer js = new JavaScriptSerializer();
            string strJson = js.Serialize(JsonIDIntegracao);


            //Inicia a configuração da requisicao:
            var client = new RestClient(url + "/api/v1/boletos/descarta/lote/");
            var request = new RestRequest(Method.POST);
            request.AddHeader("cache-control", "no-cache");
            request.AddHeader("content-type", "application/json");
            request.AddHeader("token-sh", tokenSH);
            request.AddHeader("cnpj-sh", cnpjSH);
            request.AddHeader("cnpj-cedente", cnpjCedente);
            request.AddParameter("application/json", (strJson), ParameterType.RequestBody);


            dynamic json = JObject.Parse(client.Execute(request).Content);
            rtRetorno.Text = JsonConvert.SerializeObject(json, Formatting.Indented);

        }
    }
}