package main

import (
	"bufio"
	"bytes"
	"fmt"
	"io"
	"mime/multipart"
	"net/http"
	"net/url"
	"os"
	"strings"
)

func main() {
	var rota int
	var CNPJSH string
	var TOKENSH string
	var CNPJCEDENTE string
	var jsonBody string

	fmt.Printf(
		"▼\n" +
			"1. Criar um cedente\n" +
			"2. Listar cedentes cadastrados\n" +
			"3. Atualizar um cedente\n" +
			"4. Cadastrar conta \n" +
			"5. Listar contas\n" +
			"6. Atualizar conta\n" +
			"7. Cadastrar Convênio\n" +
			"8. Listar convênios\n" +
			"9. Atualizar Convênio\n" +
			"10. Gerar Boleto\n" +
			"11. Consultar Boleto\n" +
			"12. Gerar Remessa\n" +
			"13. Solicitar impressão do Boleto\n" +
			"14. Consultar Impressão do Boleto\n" +
			"15. Incluir Arquivo de Retorno\n" +
			"16. Consultar arquivo de Retorno\n" +
			"--------------------------\n\n",
	)

	fmt.Print("Digite o número correspondente a rota que deseja utilizar: ")
	fmt.Scanln(&rota)

	switch rota {
	case 1:
		// Criar um cedente
		urlPostCedente := "https://plugboleto.com.br/api/v1/cedentes"

		fmt.Print("Insira o cnpj-sh: ")
		fmt.Scanln(&CNPJSH)

		fmt.Print("Insira o token-sh: ")
		fmt.Scanln(&TOKENSH)

		fmt.Println("Insira o JSON (pressione Ctrl+Z e depois tecla 'Enter' para terminar a entrada):")
		scanner := bufio.NewScanner(os.Stdin)
		for scanner.Scan() {
			jsonBody += scanner.Text()
		}

		client := &http.Client{}

		req, err := http.NewRequest("POST", urlPostCedente, strings.NewReader(jsonBody))
		if err != nil {
			fmt.Println("Erro ao criar a solicitação:", err)
			return
		}

		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("cnpj-sh", CNPJSH)
		req.Header.Set("token-sh", TOKENSH)

		resp, err := client.Do(req)
		if err != nil {
			fmt.Println("Erro ao fazer a solicitação:", err)
			return
		}

		defer resp.Body.Close()

		bodyText, err := readResponseBody(resp.Body)
		fmt.Println("Response:")
		fmt.Println("► Corpo da resposta:\n", string(bodyText))
		fmt.Println("--")
		fmt.Println("► Código de status:\n", resp.Status)

	case 2:
		// Listar cedentes cadastrados
		urlGetCedentes := "https://plugboleto.com.br/api/v1/cedentes"

		fmt.Print("Insira o cnpj-sh: ")
		fmt.Scanln(&CNPJSH)

		fmt.Print("Insira o token-sh: ")
		fmt.Scanln(&TOKENSH)

		fmt.Print("Insira o cnpj-cedente: ")
		fmt.Scanln(&CNPJCEDENTE)

		params := url.Values{}
		params.Set("cnpj-cedente", CNPJCEDENTE)
		urlGetCedentes += "?" + params.Encode()

		client := &http.Client{}

		req, err := http.NewRequest("GET", urlGetCedentes, nil)
		if err != nil {
			fmt.Println("Erro ao criar a solicitação:", err)
			return
		}

		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("cnpj-sh", CNPJSH)
		req.Header.Set("token-sh", TOKENSH)

		resp, err := client.Do(req)
		if err != nil {
			fmt.Println("Erro ao fazer a solicitação:", err)
			return
		}

		defer resp.Body.Close()

		bodyText, err := readResponseBody(resp.Body)
		fmt.Println("Response:")
		fmt.Println("► Corpo da resposta:\n", string(bodyText))
		fmt.Println("--")
		fmt.Println("► Código de status:\n", resp.Status)

	case 3:
		// Atualizar um cedente
		var idCompany string

		urlPutCedente := "https://pix.tecnospeed.com.br/sandbox/companies/"

		fmt.Print("Insira o cnpj-sh: ")
		fmt.Scanln(&CNPJSH)

		fmt.Print("Insira o token-sh: ")
		fmt.Scanln(&TOKENSH)

		fmt.Print("Insira o cnpj-cedente: ")
		fmt.Scanln(&CNPJCEDENTE)

		fmt.Println("Insira o JSON (pressione Ctrl+Z e depois tecla 'Enter' para terminar a entrada):")
		scanner := bufio.NewScanner(os.Stdin)
		for scanner.Scan() {
			jsonBody += scanner.Text()
		}

		client := &http.Client{}

		req, err := http.NewRequest("PUT", urlPutCedente, strings.NewReader(jsonBody))
		if err != nil {
			fmt.Println("Erro ao criar a solicitação:", err)
			return
		}

		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("cnpj-sh", CNPJSH)
		req.Header.Set("token-sh", TOKENSH)
		req.Header.Set("cnpj-cedente", CNPJCEDENTE)

		resp, err := client.Do(req)
		if err != nil {
			fmt.Println("Erro ao fazer a solicitação:", err)
			return
		}

		defer resp.Body.Close()

		bodyText, err := readResponseBody(resp.Body)
		fmt.Println("Response:")
		fmt.Println("► Corpo da resposta:\n", string(bodyText))
		fmt.Println("--")
		fmt.Println("► Código de status:\n", resp.Status)

	case 4:
		// Cadastrar uma conta
		urlCadastrarConta := "https://plugboleto.com.br/api/v1/cedentes/contas"

		fmt.Print("Insira o cnpj-sh: ")
		fmt.Scanln(&CNPJSH)

		fmt.Print("Insira o token-sh: ")
		fmt.Scanln(&TOKENSH)

		fmt.Print("Insira o cnpj-cedente: ")
		fmt.Scanln(&CNPJCEDENTE)

		fmt.Println("Insira o JSON (pressione Ctrl+Z e depois tecla 'Enter' para terminar a entrada):")
		scanner := bufio.NewScanner(os.Stdin)
		for scanner.Scan() {
			jsonBody += scanner.Text()
		}

		client := &http.Client{}

		req, err := http.NewRequest("POST", urlCadastrarConta, strings.NewReader(jsonBody))
		if err != nil {
			fmt.Println("Erro ao criar a solicitação:", err)
			return
		}

		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("cnpj-sh", CNPJSH)
		req.Header.Set("token-sh", TOKENSH)
		req.Header.Set("cnpj-cedente", CNPJCEDENTE)

		resp, err := client.Do(req)
		if err != nil {
			fmt.Println("Erro ao fazer a solicitação:", err)
			return
		}

		defer resp.Body.Close()

		bodyText, err := readResponseBody(resp.Body)
		fmt.Println("Response:")
		fmt.Println("► Corpo da resposta:\n", string(bodyText))
		fmt.Println("--")
		fmt.Println("► Código de status:\n", resp.Status)

	case 5:
		// Listar contas
		urlListarContas := "https://plugboleto.com.br/api/v1/cedentes/contas"

		fmt.Print("Insira o cnpj-sh: ")
		fmt.Scanln(&CNPJSH)

		fmt.Print("Insira o token-sh: ")
		fmt.Scanln(&TOKENSH)

		fmt.Print("Insira o cnpj-cedente: ")
		fmt.Scanln(&CNPJCEDENTE)

		client := &http.Client{}

		req, err := http.NewRequest("GET", urlListarContas, nil)
		if err != nil {
			fmt.Println("Erro ao criar a solicitação:", err)
			return
		}

		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("cnpj-sh", CNPJSH)
		req.Header.Set("token-sh", TOKENSH)
		req.Header.Set("cnpj-cedente", CNPJCEDENTE)

		resp, err := client.Do(req)
		if err != nil {
			fmt.Println("Erro ao fazer a solicitação:", err)
			return
		}

		defer resp.Body.Close()

		bodyText, err := readResponseBody(resp.Body)
		fmt.Println("Response:")
		fmt.Println("► Corpo da resposta:\n", string(bodyText))
		fmt.Println("--")
		fmt.Println("► Código de status:\n", resp.Status)

	case 6:
		// Atualizar conta
		var idAccount string

		urlAtualizarConta := "https://plugboleto.com.br/api/v1/cedentes/contas/"

		fmt.Print("Insira o cnpj-sh: ")
		fmt.Scanln(&CNPJSH)

		fmt.Print("Insira o token-sh: ")
		fmt.Scanln(&TOKENSH)

		fmt.Print("Insira o cnpj-cedente: ")
		fmt.Scanln(&CNPJCEDENTE)

		fmt.Print("Insira o id da conta: ")
		fmt.Scanln(&idAccount)

		fmt.Println("Insira o JSON (pressione Ctrl+Z e depois tecla 'Enter' para terminar a entrada):")
		scanner := bufio.NewScanner(os.Stdin)
		for scanner.Scan() {
			jsonBody += scanner.Text()
		}

		client := &http.Client{}

		req, err := http.NewRequest("PUT", urlAtualizarConta+idAccount, strings.NewReader(jsonBody))
		if err != nil {
			fmt.Println("Erro ao criar a solicitação:", err)
			return
		}

		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("cnpj-sh", CNPJSH)
		req.Header.Set("token-sh", TOKENSH)
		req.Header.Set("cnpj-cedente", CNPJCEDENTE)

		resp, err := client.Do(req)
		if err != nil {
			fmt.Println("Erro ao fazer a solicitação:", err)
			return
		}

		defer resp.Body.Close()

		bodyText, err := readResponseBody(resp.Body)
		fmt.Println("Response:")
		fmt.Println("► Corpo da resposta:\n", string(bodyText))
		fmt.Println("--")
		fmt.Println("► Código de status:\n", resp.Status)

	case 7:
		urlCadastrarConvenio := "https://plugboleto.com.br/api/v1/cedentes/contas/convenios"

		fmt.Print("Insira o cnpj-sh: ")
		fmt.Scanln(&CNPJSH)

		fmt.Print("Insira o token-sh: ")
		fmt.Scanln(&TOKENSH)

		fmt.Print("Insira o cnpj-cedente: ")
		fmt.Scanln(&CNPJCEDENTE)

		fmt.Println("Insira o JSON (pressione Ctrl+Z e depois tecla 'Enter' para terminar a entrada):")
		scanner := bufio.NewScanner(os.Stdin)
		for scanner.Scan() {
			jsonBody += scanner.Text()
		}

		client := &http.Client{}

		req, err := http.NewRequest("POST", urlCadastrarConvenio, nil)
		if err != nil {
			fmt.Println("Erro ao criar a solicitação:", err)
			return
		}

		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("cnpj-sh", CNPJSH)
		req.Header.Set("token-sh", TOKENSH)
		req.Header.Set("cnpj-cedente", CNPJCEDENTE)

		resp, err := client.Do(req)
		if err != nil {
			fmt.Println("Erro ao fazer a solicitação:", err)
			return
		}

		defer resp.Body.Close()

		bodyText, err := readResponseBody(resp.Body)
		fmt.Println("Response:")
		fmt.Println("► Corpo da resposta:\n", string(bodyText))
		fmt.Println("--")
		fmt.Println("► Código de status:\n", resp.Status)

		// Listar convênios
	case 8:
		urlListarConvenios := "https://plugboleto.com.br/api/v1/cedentes/contas/convenios"

		fmt.Print("Insira o cnpj-sh: ")
		fmt.Scanln(&CNPJSH)

		fmt.Print("Insira o token-sh: ")
		fmt.Scanln(&TOKENSH)

		fmt.Print("Insira o cnpj-cedente: ")
		fmt.Scanln(&CNPJCEDENTE)

		client := &http.Client{}

		req, err := http.NewRequest("GET", urlListarConvenios, nil)
		if err != nil {
			fmt.Println("Erro ao criar a solicitação:", err)
			return
		}

		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("cnpj-sh", CNPJSH)
		req.Header.Set("token-sh", TOKENSH)
		req.Header.Set("cnpj-cedente", CNPJCEDENTE)

		resp, err := client.Do(req)
		if err != nil {
			fmt.Println("Erro ao fazer a solicitação:", err)
			return
		}

		defer resp.Body.Close()

		bodyText, err := readResponseBody(resp.Body)
		fmt.Println("Response:")
		fmt.Println("► Corpo da resposta:\n", string(bodyText))
		fmt.Println("--")
		fmt.Println("► Código de status:\n", resp.Status)

		// Atualizar Convênio
	case 9:
		urlAtualizarConvenio := "https://plugboleto.com.br/api/v1/cedentes/contas/convenios/"

		fmt.Print("Insira o cnpj-sh: ")
		fmt.Scanln(&CNPJSH)

		fmt.Print("Insira o token-sh: ")
		fmt.Scanln(&TOKENSH)

		fmt.Print("Insira o cnpj-cedente: ")
		fmt.Scanln(&CNPJCEDENTE)

		fmt.Print("Insira o ID do convênio: ")
		fmt.Scanln(&idConvenio)

		fmt.Println("Insira o JSON (pressione Ctrl+Z e depois tecla 'Enter' para terminar a entrada):")
		scanner := bufio.NewScanner(os.Stdin)
		for scanner.Scan() {
			jsonBody += scanner.Text()
		}

		client := &http.Client{}

		req, err := http.NewRequest("PUT", urlAtualizarConvenio+idConvenio, strings.NewReader(jsonBody))
		if err != nil {
			fmt.Println("Erro ao criar a solicitação:", err)
			return
		}

		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("cnpj-sh", CNPJSH)
		req.Header.Set("token-sh", TOKENSH)
		req.Header.Set("cnpj-cedente", CNPJCEDENTE)

		resp, err := client.Do(req)
		if err != nil {
			fmt.Println("Erro ao fazer a solicitação:", err)
			return
		}

		defer resp.Body.Close()

		bodyText, err := readResponseBody(resp.Body)
		fmt.Println("Response:")
		fmt.Println("► Corpo da resposta:\n", string(bodyText))
		fmt.Println("--")
		fmt.Println("► Código de status:\n", resp.Status)

		// Gerar Boleto
	case 10:
		urlGerarBoleto := "https://plugboleto.com.br/api/v1/boletos/lote"

		fmt.Print("Insira o cnpj-sh: ")
		fmt.Scanln(&CNPJSH)

		fmt.Print("Insira o token-sh: ")
		fmt.Scanln(&TOKENSH)

		fmt.Print("Insira o cnpj-cedente: ")
		fmt.Scanln(&CNPJCEDENTE)

		fmt.Println("Insira o JSON (pressione Ctrl+Z e depois tecla 'Enter' para terminar a entrada):")
		scanner := bufio.NewScanner(os.Stdin)
		for scanner.Scan() {
			jsonBody += scanner.Text()
		}

		client := &http.Client{}

		req, err := http.NewRequest("POST", urlGerarBoleto, nil)
		if err != nil {
			fmt.Println("Erro ao criar a solicitação:", err)
			return
		}

		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("cnpj-sh", CNPJSH)
		req.Header.Set("token-sh", TOKENSH)
		req.Header.Set("cnpj-cedente", CNPJCEDENTE)

		resp, err := client.Do(req)
		if err != nil {
			fmt.Println("Erro ao fazer a solicitação:", err)
			return
		}

		defer resp.Body.Close()

		// Consultar Boleto
	case 11:
		var idBoleto string

		urlConsultarBoleto := "https://plugboleto.com.br/api/v1/boletos/"

		fmt.Print("Insira o cnpj-sh: ")
		fmt.Scanln(&CNPJSH)

		fmt.Print("Insira o token-sh: ")
		fmt.Scanln(&TOKENSH)

		fmt.Print("Insira o cnpj-cedente: ")
		fmt.Scanln(&CNPJCEDENTE)

		fmt.Print("Insira o ID do boleto: ")
		fmt.Scanln(&idBoleto)

		client := &http.Client{}

		req, err := http.NewRequest("GET", urlConsultarBoleto+idBoleto, nil)
		if err != nil {
			fmt.Println("Erro ao criar a solicitação:", err)
			return
		}

		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("cnpj-sh", CNPJSH)
		req.Header.Set("token-sh", TOKENSH)
		req.Header.Set("cnpj-cedente", CNPJCEDENTE)

		resp, err := client.Do(req)
		if err != nil {
			fmt.Println("Erro ao fazer a solicitação:", err)
			return
		}

		defer resp.Body.Close()

		bodyText, err := readResponseBody(resp.Body)
		fmt.Println("Response:")
		fmt.Println("► Corpo da resposta:\n", string(bodyText))
		fmt.Println("--")
		fmt.Println("► Código de status:\n", resp.Status)

		// Gerar Remessa
	case 12:
		urlGerarRemessa := "https://plugboleto.com.br/api/v1/boletos/remessa"

		fmt.Print("Insira o cnpj-sh: ")
		fmt.Scanln(&CNPJSH)

		fmt.Print("Insira o token-sh: ")
		fmt.Scanln(&TOKENSH)

		fmt.Print("Insira o cnpj-cedente: ")
		fmt.Scanln(&CNPJCEDENTE)

		fmt.Println("Insira o JSON (pressione Ctrl+Z e depois tecla 'Enter' para terminar a entrada):")
		scanner := bufio.NewScanner(os.Stdin)
		for scanner.Scan() {
			jsonBody += scanner.Text()
		}

		client := &http.Client{}

		req, err := http.NewRequest("POST", urlGerarRemessa, nil)
		if err != nil {
			fmt.Println("Erro ao criar a solicitação:", err)
			return
		}

		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("cnpj-sh", CNPJSH)
		req.Header.Set("token-sh", TOKENSH)
		req.Header.Set("cnpj-cedente", CNPJCEDENTE)

		resp, err := client.Do(req)
		if err != nil {
			fmt.Println("Erro ao fazer a solicitação:", err)
			return
		}

		defer resp.Body.Close()

		bodyText, err := readResponseBody(resp.Body)
		fmt.Println("Response:")
		fmt.Println("► Corpo da resposta:\n", string(bodyText))
		fmt.Println("--")
		fmt.Println("► Código de status:\n", resp.Status)

		// Solicitar impressão do Boleto
	case 13:
		urlSolicitarImpressao := "https://plugboleto.com.br/api/v1/boletos/impressao"

		fmt.Print("Insira o cnpj-sh: ")
		fmt.Scanln(&CNPJSH)

		fmt.Print("Insira o token-sh: ")
		fmt.Scanln(&TOKENSH)

		fmt.Print("Insira o cnpj-cedente: ")
		fmt.Scanln(&CNPJCEDENTE)

		fmt.Println("Insira o JSON (pressione Ctrl+Z e depois tecla 'Enter' para terminar a entrada):")
		scanner := bufio.NewScanner(os.Stdin)
		for scanner.Scan() {
			jsonBody += scanner.Text()
		}

		client := &http.Client{}

		req, err := http.NewRequest("POST", urlSolicitarImpressao, nil)
		if err != nil {
			fmt.Println("Erro ao criar a solicitação:", err)
			return
		}

		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("cnpj-sh", CNPJSH)
		req.Header.Set("token-sh", TOKENSH)
		req.Header.Set("cnpj-cedente", CNPJCEDENTE)

		resp, err := client.Do(req)
		if err != nil {
			fmt.Println("Erro ao fazer a solicitação:", err)
			return
		}

		defer resp.Body.Close()

		bodyText, err := readResponseBody(resp.Body)
		fmt.Println("Response:")
		fmt.Println("► Corpo da resposta:\n", string(bodyText))
		fmt.Println("--")
		fmt.Println("► Código de status:\n", resp.Status)

		// Consultar Impressão do Boleto
	case 14:
		var idImpressao string

		urlConsultarImpressao := "https://plugboleto.com.br/api/v1/boletos/impressao/"

		fmt.Print("Insira o cnpj-sh: ")
		fmt.Scanln(&CNPJSH)

		fmt.Print("Insira o token-sh: ")
		fmt.Scanln(&TOKENSH)

		fmt.Print("Insira o cnpj-cedente: ")
		fmt.Scanln(&CNPJCEDENTE)

		fmt.Print("Insira o ID da impressão: ")
		fmt.Scanln(&idImpressao)

		client := &http.Client{}

		req, err := http.NewRequest("GET", urlConsultarImpressao+idImpressao, nil)
		if err != nil {
			fmt.Println("Erro ao criar a solicitação:", err)
			return
		}

		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("cnpj-sh", CNPJSH)
		req.Header.Set("token-sh", TOKENSH)
		req.Header.Set("cnpj-cedente", CNPJCEDENTE)

		resp, err := client.Do(req)
		if err != nil {
			fmt.Println("Erro ao fazer a solicitação:", err)
			return
		}

		defer resp.Body.Close()

		bodyText, err := readResponseBody(resp.Body)
		fmt.Println("Response:")
		fmt.Println("► Corpo da resposta:\n", string(bodyText))
		fmt.Println("--")
		fmt.Println("► Código de status:\n", resp.Status)

		// Incluir Arquivo de Retorno
	case 15:
		urlIncluirRetorno := "https://plugboleto.com.br/api/v1/retornos"

		fmt.Print("Insira o cnpj-sh: ")
		fmt.Scanln(&CNPJSH)

		fmt.Print("Insira o token-sh: ")
		fmt.Scanln(&TOKENSH)

		fmt.Print("Insira o cnpj-cedente: ")
		fmt.Scanln(&CNPJCEDENTE)

		var filePath string
		fmt.Print("Insira o caminho do arquivo de retorno. Exemplo: C:\\Users\\Usuario\\Downloads\\retorno.txt: ")
		fmt.Scanln(&filePath)

		file, err := os.Open(filePath)
		if err != nil {
			fmt.Println("Erro ao abrir o arquivo:", err)
			return
		}
		defer file.Close()

		fileInfo, _ := file.Stat()
		var fileSize int64 = fileInfo.Size()
		buffer := make([]byte, fileSize)

		file.Read(buffer)

		req, err := http.NewRequest("POST", urlIncluirRetorno, bytes.NewBuffer(buffer))
		if err != nil {
			fmt.Println("Erro ao criar a solicitação:", err)
			return
		}

		req.Header.Set("Content-Type", "text/plain")
		req.Header.Set("cnpj-sh", CNPJSH)
		req.Header.Set("token-sh", TOKENSH)
		req.Header.Set("cnpj-cedente", CNPJCEDENTE)

		resp, err := http.DefaultClient.Do(req)
		if err != nil {
			fmt.Println("Erro ao fazer a solicitação:", err)
			return
		}

		defer resp.Body.Close()

		bodyText, err := readResponseBody(resp.Body)
		fmt.Println("Response:")
		fmt.Println("► Corpo da resposta:\n", string(bodyText))
		fmt.Println("--")
		fmt.Println("► Código de status:\n", resp.Status)

		// Consultar Arquivo de Retorno
	case 16:
		var idRetorno string

		urlConsultarRetorno := "https://plugboleto.com.br/api/v1/retornos/"

		fmt.Print("Insira o cnpj-sh: ")
		fmt.Scanln(&CNPJSH)

		fmt.Print("Insira o token-sh: ")
		fmt.Scanln(&TOKENSH)

		fmt.Print("Insira o cnpj-cedente: ")
		fmt.Scanln(&CNPJCEDENTE)

		fmt.Print("Insira o ID do retorno: ")
		fmt.Scanln(&idRetorno)

		client := &http.Client{}

		req, err := http.NewRequest("GET", urlConsultarRetorno+idRetorno, nil)
		if err != nil {
			fmt.Println("Erro ao criar a solicitação:", err)
			return
		}

		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("cnpj-sh", CNPJSH)
		req.Header.Set("token-sh", TOKENSH)
		req.Header.Set("cnpj-cedente", CNPJCEDENTE)

		resp, err := client.Do(req)
		if err != nil {
			fmt.Println("Erro ao fazer a solicitação:", err)
			return
		}

		defer resp.Body.Close()

		bodyText, err := readResponseBody(resp.Body)
		fmt.Println("Response:")
		fmt.Println("► Corpo da resposta:\n", string(bodyText))
		fmt.Println("--")
		fmt.Println("► Código de status:\n", resp.Status)
	}